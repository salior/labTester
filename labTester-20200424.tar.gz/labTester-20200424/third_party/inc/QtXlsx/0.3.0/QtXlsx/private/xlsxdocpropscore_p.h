#include "../../../../../../QtXlsxWriter/src/xlsx/xlsxdocpropscore_p.h"
