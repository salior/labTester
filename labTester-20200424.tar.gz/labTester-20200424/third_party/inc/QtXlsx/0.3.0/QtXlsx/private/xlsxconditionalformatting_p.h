#include "../../../../../../QtXlsxWriter/src/xlsx/xlsxconditionalformatting_p.h"
