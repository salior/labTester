#ifndef _IOC_H_
#define _IOC_H_
#include<string>
#include<unordered_map>
#include<memory>
#include<functional>
#include"./utils/Any.h"
#include <./utils/NonCopyable.h>

class IocContainer : NonCopyable
{
public:
	IocContainer(void){}
	~IocContainer(void){}

	template<class T, typename Depend, typename... Args>
	typename std::enable_if<!std::is_base_of<T, Depend>::value >::type
	RegisterType(const std::string& strKey)
	{
        std::function<T* (Args...)> function = [](Args... args){ return new T(new Depend(args...)); };//
		RegisterType(strKey, function);
	}

	template<class T, typename Depend, typename... Args>
	typename std::enable_if<std::is_base_of<T, Depend>::value >::type
	RegisterType(const std::string& strKey)
	{
        std::function<T* (Args...)> function = [](Args... args){ return new Depend(args...); };//
		RegisterType(strKey, function);
	}

	template<class T, typename... Args>
	void RegisterSimpleType(const std::string& strKey)
	{
		std::function<T* (Args...)> func = [](Args... args){
			return new T(args...);
		};
		RegisterType(strKey, func);
	}

	template<class T, typename... Args>
	T* Resolve(const std::string& strKey, Args... args)
	{
		if (m_creatorMap.find(strKey) == m_creatorMap.end())
			return nullptr;
        Any resolver = m_creatorMap[strKey];
#ifdef _QNX_

        std::function<T* (Args...)> function = resolver.AnyCast<std::function<T* (Args...)>>();
#else
        std::function<T* (Args...)> function = boost::any_cast<std::function<T* (Args...)>>(resolver);
#endif

		return function(args...);
	}

	template<class T, typename... Args>
	std::shared_ptr<T> ResolveShared(const std::string& strKey, Args... args)
	{
		T* t = Resolve<T>(strKey, args...);

		return std::shared_ptr<T>(t);
	}

    std::unordered_map<std::string, Any> getList(){return m_creatorMap;}
private:

	void RegisterType(const std::string& strKey, Any constructor)
	{
		if (m_creatorMap.find(strKey) != m_creatorMap.end())
		{
			throw std::invalid_argument("this key has already exist!");
		}
		m_creatorMap.emplace(strKey, constructor);
	}

private:
	std::unordered_map<std::string, Any> m_creatorMap;
};

#endif
