#ifndef SINGLETON_H
#define SINGLETON_H
/***********************************************************************
 ***********************************************************************/
#include <mutex>
#include <memory>
template<typename T>
class Singleton
{
public:
    template<typename... Args>
    static T& instance(Args&&... args)
    {
        std::call_once(m_flag, [](Args&&... args){
            init(std::forward<Args>(args)...);
        }, std::forward<Args>(args)...);

        return *value_;
    }
    template<typename... Args>
    static std::shared_ptr<T> getInstance(Args&&... args)
    {
        std::call_once(m_flag, [](Args&&... args){
            init(std::forward<Args>(args)...);
        }, std::forward<Args>(args)...);

        return value_;
    }

private:
    Singleton();
    Singleton(const Singleton& other);
    Singleton &operator=(const Singleton& other);
    ~Singleton();

    template <typename... Args>
    static void init(Args&&... args)
    {
        value_ = std::shared_ptr<T>(new T(std::forward<Args>(args)...));        
        //::atexit(destroy);
    }

    static void destroy()
    {
        //     delete value_;
    }

private:
    static std::once_flag m_flag;//
    //  static T* value_;
    static std::shared_ptr<T> value_;
};


template<typename T>
std::shared_ptr<T> Singleton<T>::value_ = NULL;

template<typename T>
std::once_flag Singleton<T>::m_flag;


#define DECLARE_SINGLETON_0BJCE(T) static std::shared_ptr<T> getInstance() {return Singleton<T>::getInstance();}

#endif // SINGLETON_H

