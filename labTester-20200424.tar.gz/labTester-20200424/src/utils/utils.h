#ifndef UTILS_H
#define UTILS_H
//#include "types.h"
#include <list>
#include <sys/types.h>
//#include<sys/statfs.h>
#include <sys/stat.h>
#include <time.h>
#include <stdlib.h>
#include <string>
#include <stdio.h>
#include <cstring>
#include <vector>
#include "types.h"

#ifdef _QNX_
#include <pthread.h>
#include <unistd.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/mount.h>
#else

#endif
#define PATH_SEPARATOR '/'
using namespace std;


#ifdef _QNX_
template<class T>
class ThreadLock
{

public:
    ThreadLock()
    {
        pthread_mutex_init(&m_cs,NULL);
    }

    ~ThreadLock(){
        pthread_mutex_destroy(&m_cs);
    }

    inline void Lock()
    {
        pthread_mutex_lock(&m_cs);
        cnt++;

    }
    inline void Unlock()
    {
        pthread_mutex_unlock(&m_cs);

        cnt--;
        if(cnt<=0)cnt=0;
    }

    T getVal()
    {
        T p;
        Lock();
        p = mp;
        Unlock();
        return p;
    }
    T setVal(T pSet)
    {
        T p;
        Lock();	p = mp = pSet;	Unlock();
        return p;
    }
private:
    T mp;
    int cnt;
    pthread_mutex_t m_cs;
};
#endif

#define TF_DEVICE_DRV_PATH "/dev/mmcblk0p1"
#define TF_MOUNT_POINT    "/mnt/sd"
 class HBS_EXT_CLASS Utils
{
public:
    Utils();
    static std::string    generateFileName();
    static std::string itostring(int a);
    static void get_dirs(const std::string& dir, std::vector<std::string>& dirs);
    static void get_files(const std::string& dir, std::vector<std::string>& files);
    static void get_files(const std::string& dir, std::vector<std::string>& files, std::string ext);

    static int  getSpace(string root,int * f,int  * total){
        if(f ==NULL){
            return -1;
        }

        //TODO
        //        struct statfs diskInfo;
        //        statfs(root.c_str(),&diskInfo);
        //        long long blockSize =(long long ) diskInfo.f_bsize;
        //        long long freeDisk = (long long)(diskInfo.f_bfree* blockSize) / (long long) 1024/(long long) 1024;
        //        //long long freeDisk = (long long)(diskInfo.f_bfree* blockSize) / 1024;
        //        long long totalDisk = (long long)(diskInfo.f_blocks* blockSize)/ (long long) 1024/(long long) 1024;
        //        *f = freeDisk;
        //        *total = totalDisk;
        return 0;
    }

    static int   removeFile(const char* filePath){
        return remove(filePath);
    }

    static vector<string> split_ex(const string& src, string separate_character)
    {
        vector<string> strs;

        int separate_characterLen = separate_character.size();
        int lastPosition = 0;
        int index = -1;
        while (-1 != (index = src.find(separate_character,lastPosition)))
        {
            strs.push_back(src.substr(lastPosition,index - lastPosition));
            lastPosition = index + separate_characterLen;
        }
        string lastString = src.substr(lastPosition);//
        if (!lastString.empty())
            strs.push_back(lastString);//
        return strs;
    }

    static inline bool isSpace(char c) //
    {
        return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\v' || c == '\f';
    }


    static void trimLeft(std::string& s)
    {
        if (s.empty())
        {
            return;
        }
        const char* c = s.c_str();
        if (!isSpace(*c))
        {
            return;
        }
        ++c;
        while (isSpace(*c))
        {
            ++c;
        }
        s = c;
    }

    static void trimRight(std::string& s)
    {
        if (s.empty())
        {
            return;
        }
        const char* begin = s.c_str();
        const char* end = begin+s.length()-1;
        while (end >= begin && isSpace(*end))
        {
            --end;
        }
        s = s.substr(0, end+1-begin);
    }

    static void trim(std::string& s)
    {
        if (s.empty())
        {
            return;
        }
        const char* begin = s.c_str();
        const char* end = begin+s.length()-1;
        while (isSpace(*begin))
        {
            ++begin;
        }
        while (end > begin && isSpace(*end))
        {
            --end;
        }
        s = s.substr(begin-s.c_str(), end+1-begin);
    }


    //    static int mountTF(){

    //            // If already mounted,
    //            if (access(TF_DEVICE_DRV_PATH, F_OK) != 0) {
    //                return 0;
    //            }

    //            // else, mount the filesystem

    //            mkdir(TF_MOUNT_POINT, 0755);  // in case it doesn't already exist

    //            if (mount(TF_DEVICE_DRV_PATH, TF_MOUNT_POINT, "vfat",
    //                      MS_NOATIME | MS_NODEV | MS_NODIRATIME, "")!=0) {
    //                return -1;
    //            } else {
    //                return 1;
    //            }

    //    }

    //    static int unMountTF(){
    //        rmdir(TF_MOUNT_POINT);
    //        return umount(TF_DEVICE_DRV_PATH);
    //    }

    /*

         */
    //static void HAMWatchDog(const char *strName, const char *strPath);
    static  int   recursiveMkdir( const char *path );
    // /usr/tmp/ ->/usr/tmp  or /usr/tmp -> tmp
    static char* getPathPart(char* path);

    static string to_string(int value);
    static string getAppPath();
    static string getExeName();
    static std::string format(const char *fmt,...);


};

#endif // UTILS_H
