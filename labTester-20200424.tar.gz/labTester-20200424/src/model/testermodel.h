#ifndef TESTERMODEL_H
#define TESTERMODEL_H
#include <QString>
#include <QList>
#include "singleton.h"
#include "sensormodel.h"
#include <QMutex>


class TesterModel
{
public:
    TesterModel();

    DECLARE_SINGLETON_0BJCE(TesterModel)

    void addSensor(SENSOR_DATA_T* data);
    void removeSensor(SENSOR_DATA_T* data);

    void removeSensor(int index);
    void setSensorEnabledById(int id);

    void setSLItemShow(int index,bool show);
    void setSensorShow(int id,bool show);
   //
    SENSOR_DATA_T* getSensorDataById(int id);   //
    SENSOR_DATA_T* getSensorDataByIndex(int index);   //

    //const SENSOR_DATA_T* getSensorData(int index);   //

    void onSensorDataUpdated(UPDATE_DATA_T * data);
    void onSensorDataADUpdated(UPDATE_AD_DATA_T * data);

    int getSensorCount(){
        return mSensorDataList.size();
    }

    void clearCurve(int id);

    void clearValue(int index);
    void setDanWei(int index,QString danwei);
    void switchMode(bool lizhi){
        mLiZhi = lizhi;
    }
    bool getMode(){return mLiZhi;}

private:
    bool  mLiZhi; // 力值测量or 灵敏度测量
    SENSOR_DATA_T* getSensorData(int index);
    QMutex mutex;

    QMap<QString,int> mDanWeiMap;
    QList<QString> mDanWeiList;
    QList<SENSOR_DATA_T*> mSensorDataList;
};
#endif // TESTERMODEL_H
