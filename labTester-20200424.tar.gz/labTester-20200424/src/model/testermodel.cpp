#include "testermodel.h"


TesterModel::TesterModel()
{

    QMutexLocker locker(&mutex);

    mDanWeiList.push_back("N");
    mDanWeiList.push_back("kN");
    mDanWeiList.push_back("MN");
    mDanWeiList.push_back("gf");
    mDanWeiList.push_back("kgf");
    mDanWeiList.push_back("tf");

    mDanWeiMap["N"]=2;
    mDanWeiMap["kN"]=5;
    mDanWeiMap["MN"]=0;
    mDanWeiMap["gf"]=0;
    mDanWeiMap["kgf"]=3;
    mDanWeiMap["tf"]=6;

    mLiZhi = true;
}

void TesterModel::addSensor(SENSOR_DATA_T *data)
{
    mutex.lock();
        foreach (SENSOR_DATA_T* item, mSensorDataList) {
            if(item->id == data->id){
                item->assign(data);
                qDebug()<< "on update. sensor data" ;
                mutex.unlock();
                return;
            }
        }
        if(mSensorDataList.length() < MAX_SENSOR_COUNT){
            qDebug()<< "on add sensor data " << data->id ;

            mSensorDataList.append(data->clone());
            qSort(mSensorDataList.begin(), mSensorDataList.end(),
                  [](const SENSOR_DATA_T* a, const SENSOR_DATA_T* b) -> bool {
                  return a->id < b->id;
            });
        }else{
             qDebug()<< "ERROR: add sensor data has MAXSIZE " << data->id ;
        }
    mutex.unlock();
}

void TesterModel::removeSensor(SENSOR_DATA_T* data)
{
    for(int i=0;i<mSensorDataList.size();i++) {
        if(mSensorDataList.at(i)->BianHao == data->BianHao){
            removeSensor(i);
        }
    }


}

void TesterModel::removeSensor(int index)
{
    mutex.lock();
    if(index >=0 && index < mSensorDataList.size()){
        mSensorDataList.removeAt(index);
    }
    mutex.unlock();

}

void TesterModel::setSensorEnabledById(int id)
{
    mutex.lock();
        foreach (SENSOR_DATA_T* item, mSensorDataList) {
            if(item->id == id){
                item->reset();
                item->id = id;
                qDebug()<< " reset sensor data" ;
                mutex.unlock();
                return;
            }
        }
    mutex.unlock();
}

void TesterModel::setSLItemShow(int index, bool show)
{
    if(index >=0 && index < mSensorDataList.size()){
        if(getSensorData(index)){
            SENSOR_DATA_T* item = mSensorDataList.at(index);
            item->show = show;
        }
    }

}

void TesterModel::setSensorShow(int id, bool show)
{
    SENSOR_DATA_T* item = getSensorDataById(id);
    if(item)
        item->show = show;
}

SENSOR_DATA_T *TesterModel::getSensorData(int index)
{
    if(index >=0 && index < mSensorDataList.size()){
        //return mSensorDataList.at(index);

        return mSensorDataList[index];
    }

    return NULL;
}

SENSOR_DATA_T *TesterModel::getSensorDataById(int id)
{
    mutex.lock();
    for(SENSOR_DATA_T* item: mSensorDataList){
        if(item->id==id){
            mutex.unlock();
            return item;
        }
    }
    mutex.unlock();
    return NULL;
}

SENSOR_DATA_T *TesterModel::getSensorDataByIndex(int index)
{
    if(index >=0 && index < mSensorDataList.size()){
        //return mSensorDataList.at(index);

        return mSensorDataList[index];
    }

    return NULL;
}


void TesterModel::onSensorDataUpdated(UPDATE_DATA_T *data)
{
    mutex.lock();
    foreach (SENSOR_DATA_T *item, mSensorDataList) {
        if(item->id == data->id){
            item->LiZhi = data->LiZhi;
            item->FengZhi = std::max(std::abs(item->FengZhi),std::abs(item->LiZhi));
            UPDATE_DATA_T t;
            memcpy(&t,data,sizeof(UPDATE_DATA_T));
            t.LiZhi = data->LiZhi;
//            t.LiZhi = data->LiZhi/std::pow(10,item->XiaoShu);

            item->CurveList.append(t);
            if(item->CurveList.size()> MAX_CURVE_POINT){
                item->CurveList.removeFirst();
            }

            break;
        }
    }
    mutex.unlock();

}

void TesterModel::onSensorDataADUpdated(UPDATE_AD_DATA_T *data)
{
    mutex.lock();
    foreach (SENSOR_DATA_T *item, mSensorDataList) {
        if(item->id == data->id){
            item->AD = data->AD;
//            item->enabled = true;
            break;
        }
    }
    mutex.unlock();
}

void TesterModel::clearCurve(int id)
{
    mutex.lock();
    foreach (SENSOR_DATA_T *item, mSensorDataList) {
        if(item->id == id){
            item->CurveList.clear();
            break;
        }
    }
    mutex.unlock();
}

void TesterModel::clearValue(int index)
{
    if(index >=0 && index < mSensorDataList.size()){
        mSensorDataList.at(index)->setZero();
    }
}

void TesterModel::setDanWei(int index, QString danwei)
{
    if(index >=0 && index < mSensorDataList.size()){
        mSensorDataList.at(index)->DanWei = danwei;
    }
}
