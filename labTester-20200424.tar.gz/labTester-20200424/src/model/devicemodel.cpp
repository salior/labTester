#include "devicemodel.h"

DeviceModel::DeviceModel()
{

}


