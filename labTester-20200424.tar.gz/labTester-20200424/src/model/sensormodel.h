#ifndef SENSORMODEL_H
#define SENSORMODEL_H

#include <QString>
#include <QTableWidgetItem>
#include <QTextCodec>
#ifdef CHANNEL6
#define MAX_SENSOR_COUNT 6
#else
#define MAX_SENSOR_COUNT 12
#endif
#define MAX_RECORD_COUNT 11
#define MAX_CURVE_POINT  150
#define CELIANG_MOBAN   "jianding_tmp.xlsx"
#define BIAODING_MOBAN    "biaoding_tmp.xlsx"


enum{HEAD_SONSOR_WIDGET_LEFT,HEAD_SONSOR_WIDGET_RIGHT,SONSOR_WIDGET_BOARD};


#include<QDebug>
#include <QDateTime>
#include <QList>
#define LIZHI_TYPE float

typedef struct  stDanWei
{
    QString text;
    int     unit;

}DANWEI_T;



typedef struct stUpdateData
{
    int  id; //编号
    LIZHI_TYPE  LiZhi;    // 力值
    qint64 time;
}UPDATE_DATA_T;

typedef struct stUpdateADData
{
    int  id; //编号
    LIZHI_TYPE  AD;    // AD值
}UPDATE_AD_DATA_T;

typedef struct stJianDingData
{
     bool  valid;
     float SHIYANLI;
     float LILUNZHI;
     float JINCHENG1;
     float JINCHENG2;
     float JINCHENG3;
     float JINCHENG_AVERAGE;
     float HUICHENG;
     float XIANDUIWUCHAI;
     float CHONGFUXING;
}JIANDING_DATA_T;


typedef struct stBiaoDingData
{
    float BIAODINGDIAN;
    float BIAODINGZHI1;
    float BIAODINGZHI2;
    float BIAODINGZHI3;
    float BIAODINGZHI_AVERAGE;
    float XIANDUIWUCHAI;
    float CHONGFUXING;
}BIAODING_DATA_T;



// older

#ifdef OLD_OPERATOR
typedef struct stOperator{
    QString JiaoZhunYuan;
    QString JianYanYuan;
    QString YouXiaoRiQi;
    QString JiaoZhunriQi;

    int DianShu;
    bool JianDing; // jianding huo jiaozhun
    int BaoLiuXiaoShu;
    bool YaXiang; // 压向或拉向

    QString WeiTuoDanJuHao;
    QString YuanShiJilu;
    QString ShouJianDanWei;
    QString YiQiMingCheng;




}OPERATOR_T;

#else
typedef struct stOperator{
    QString WeiTuoDanJuHao;
    QString YiQiMingCheng;

    QString JiLuHao;
    QString ZhengShuBiaoHao;
    QString ZhengShuDanWei;

    QString GuangLiHao;
    QString JiaoZunHuangJing;
    float NiuJuFangDaBeiShu;

    QString BianHao;
    QString YouXiaoQi;
    QString ZhunQueDuDengJi;


    // 检定用

    QString BiaoZhunQiMingCheng;
    QString BiaoZhunQiXingHao;
    QString BiaoZhunQiBianHao;
    QString CeLiangFanWei;
    QString ZhengShuYouXiaoRiQi;
    QString BiaoZhengQiXingHao;
    QString JiShuZhiBiao;


    QString JiaoZhuZhuangZhi;
    QString JiaoZhuDiDian;
    QString JiaoZhunriQi;
    QString JiaoZhunYuan;
    QString JianYanYuan;
    QString YouXiaoRiQi;

    QString DanJuHao;
    QString DanWei;

    int DianShu;
    bool JianDing; // jianding huo jiaozhun
    int BaoLiuXiaoShu;
    bool YaXiang; // 压向或拉向

    int TableRow;


}OPERATOR_T;

#endif


typedef struct stSensorData{
    int  id;
    LIZHI_TYPE    LiZhi;    // 力值
    LIZHI_TYPE    FengZhi;    // 峰值
    float    CurrentValue;

    float    AD;
    QString  BianHao; //编号
    QString  XingHao; //型号

    float      CeLiangFanWei; // 测量范围
    QString  JiShuZhiBiao;  // 技术指标
    int      LingMinDu;     // 灵敏度

    QString ChuChangBiaoHao;//出厂编号
    QString SCChangJia;  //生产厂家
    QString ZhengShuHao; //证书号
    QString ZhengShuYouXiaoRiQi; //证书有效日期
    QString BiaoDingRiQi; //本次标定日期
    float ZhongLiJiaShuDu; //重力加速度

    // N  KN  MN
    QString DanWei;  //单位
    // 1 ,2,3,4
    short XiaoShu;  // 单位小数

    int   WenDu;  // 温度
    int   ShiDu;   //湿度
    QString JianDingYiJu; // 鉴定依据(法规)
    QString JianDingDiDian; // 检定地点
//    int   JianDingDian;  // 检定点
    QString BiaoZhunQiMingCheng; // 标准器名称
    bool show;

    bool enabled; // 是否激活或链接了


    JIANDING_DATA_T JianDingList[MAX_RECORD_COUNT];

//    QList<JIANDING_DATA_T> JianDingList;
//    QList<BIAODING_DATA_T> BiaoDingList;
    BIAODING_DATA_T BiaoDingList[MAX_RECORD_COUNT];

    OPERATOR_T Operator;

    QList<UPDATE_DATA_T> CurveList;


    stSensorData(){
        show =false;
        FengZhi = 0;
        LiZhi = 0;
    }
public:
    void setZero(){
        LiZhi = 0;
        FengZhi = 0;
    }

    void reset(){
        this->enabled = false;
        this->BianHao = "--";
        this->BiaoDingRiQi="";
        this->BiaoZhunQiMingCheng = "--";
        this->CeLiangFanWei = 100;
        this->ChuChangBiaoHao= "--";
        this->DanWei ="N";
        this->FengZhi =0;
        this->AD = 0;
        this->id = 0;
        this->show = true;
        //    this->JianDingDian = "guangdonghaobangshou";
        this->JianDingDiDian = "";
        this->JianDingYiJu = "";
        this->JiShuZhiBiao = "";
        this->LingMinDu = 0.2;
        this->LiZhi =0;
        this->SCChangJia = "";
        this->ShiDu = 0;
        this->WenDu = 0;
        this->XiaoShu = 4;
        this->XingHao = "--";
        this->ZhengShuHao="";
        this->ZhengShuYouXiaoRiQi = "";
        this->ZhongLiJiaShuDu=9.7883;
#ifdef OLD_OPERATOR

        this->Operator.JianYanYuan = "";
        this->Operator.JiaoZhunriQi = QDate::currentDate().toString("yyyy.MM.dd");
        this->Operator.JiaoZhunYuan = "";
        this->Operator.YouXiaoRiQi = "";
#else

#endif
    }

    void dumpmy(){

        qDebug() << "id:" << this->id;
        qDebug() << "LiZhi:" << this->LiZhi;
        qDebug() << "FengZhi:" << this->FengZhi;
        qDebug() << "BianHao:" << this->BianHao;
        qDebug() << "XingHao:" << this->XingHao;
        qDebug() << "xiaoshu:" << this->XiaoShu;

        qDebug() << "CeLiangFanWei:" << this->CeLiangFanWei;
        qDebug() << "JiShuZhiBiao:" << this->JiShuZhiBiao;
        qDebug() << "LingMinDu:" << this->LingMinDu;
        qDebug() << "ChuChangBiaoHao:" << this->ChuChangBiaoHao;
        qDebug() << "SCChangJia:" << this->SCChangJia;

        qDebug() << "ZhengShuHao:" << this->ZhengShuHao;
        qDebug() << "ZhengShuYouXiaoRiQi:" << this->ZhengShuYouXiaoRiQi;
        qDebug() << "BiaoDingRiQi:" << this->BiaoDingRiQi;
        qDebug() << "ZhongLiJiaShuDu:" << this->ZhongLiJiaShuDu;


//        return  QString("id-%1 '\n' lizhi-%2 '\n' biaohao-%3 '\n' xinghao-%4 '\n' celiang-fanwei-%5"
//                        "'\n' jishuzhibiao-%6 '\n' lingmingdu-%7 '\n' chuchangbiaohao-%8 '\n'"
//                        "schangjia-%9  '\n' zhengshuhao-%10 '\n' zhengshuyouxiaoriqi-%11 '\n' "
//                        "biaodingriqi-%12 '\n' biaodingriqi-%13 '\n' zhonglijiashudu-%14 ").arg(this->id).arg(
//                this->LiZhi)
//                .arg(this->FengZhi)
//                .arg(this->BianHao)
//                .arg(this->XingHao)
//                .arg(this->CeLiangFanWei)
//                .arg(this->JiShuZhiBiao)
//                .arg(this->LingMinDu)
//                .arg(this->ChuChangBiaoHao)
//                .arg(this->SCChangJia)
//                .arg(this->ZhengShuHao)
//                .arg(this->ZhengShuYouXiaoRiQi)
//                .arg(this->BiaoDingRiQi)
//                .arg(this->ZhongLiJiaShuDu
//                );
    }

    void assign(stSensorData *t){
        this ->id = t->id;
        this->CurrentValue = t->CurrentValue;
        this->AD = t->AD;
        this ->LiZhi = t->LiZhi;
        this ->XiaoShu = t->XiaoShu;
        this->DanWei  = t->DanWei;
        this ->FengZhi = t->FengZhi;
        this ->BianHao = t->BianHao;
        this ->XingHao = t->XingHao;
        this ->CeLiangFanWei = t->CeLiangFanWei;
        this ->JiShuZhiBiao = t->JiShuZhiBiao;
        this ->LingMinDu = t->LingMinDu;
        this ->ChuChangBiaoHao = t->ChuChangBiaoHao;
        this ->SCChangJia = t->SCChangJia;
        this ->ZhengShuHao = t->ZhengShuHao;
        this ->ZhengShuYouXiaoRiQi = t->ZhengShuYouXiaoRiQi;
        this ->BiaoDingRiQi = t->BiaoDingRiQi;
        this ->ZhongLiJiaShuDu = t->ZhongLiJiaShuDu;
        this->BiaoZhunQiMingCheng = t->BiaoZhunQiMingCheng;
        this->ChuChangBiaoHao = t->ChuChangBiaoHao;
        this->JianDingDiDian = t->JianDingDiDian;
        this->JianDingYiJu = t->JianDingYiJu;
        this->WenDu = t->WenDu;
        this->ShiDu = t->ShiDu;
        this->enabled = t->enabled;
        this->show = t->show;

        this->CurveList = t->CurveList;
//        this->JianDingList = t->JianDingList;
//        this->BiaoDingList = t->BiaoDingList;
        memcpy(this->JianDingList,t->JianDingList,sizeof(JIANDING_DATA_T)*MAX_RECORD_COUNT);
        memcpy(this->BiaoDingList,t->BiaoDingList,sizeof(BIAODING_DATA_T)*MAX_RECORD_COUNT);
        this->Operator = this->Operator;
    }
   stSensorData* clone(){
        stSensorData *t = new stSensorData;
        t ->id = this->id;
        t->CurrentValue = this->CurrentValue;
        t->AD = this->AD;
        t ->LiZhi = this->LiZhi;
        t ->XiaoShu = this->XiaoShu;
        t->DanWei  = this->DanWei;
        t ->FengZhi = this->FengZhi;
        t ->BianHao = this->BianHao;
        t ->XingHao = this->XingHao;
        t ->CeLiangFanWei = this->CeLiangFanWei;
        t ->JiShuZhiBiao = this->JiShuZhiBiao;
        t ->LingMinDu = this->LingMinDu;
        t ->ChuChangBiaoHao = this->ChuChangBiaoHao;
        t ->SCChangJia = this->SCChangJia;
        t ->ZhengShuHao = this->ZhengShuHao;
        t ->ZhengShuYouXiaoRiQi = this->ZhengShuYouXiaoRiQi;
        t ->BiaoDingRiQi = this->BiaoDingRiQi;
        t ->ZhongLiJiaShuDu = this->ZhongLiJiaShuDu;
        t->BiaoZhunQiMingCheng = this->BiaoZhunQiMingCheng;
        t->ChuChangBiaoHao = this->ChuChangBiaoHao;
        t->JianDingDiDian = this->JianDingDiDian;
        t->JianDingYiJu = this->JianDingYiJu;
        t->WenDu = this->WenDu;
        t->enabled = this->enabled;
        t->show = this->show;

        t->CurveList = this->CurveList;
//        t->JianDingList = this->JianDingList;
//        t->BiaoDingList = this->BiaoDingList;

        memcpy(t->JianDingList,this->JianDingList,sizeof(JIANDING_DATA_T)*MAX_RECORD_COUNT);
        memcpy(t->BiaoDingList,this->BiaoDingList,sizeof(BIAODING_DATA_T)*MAX_RECORD_COUNT);
        t->Operator = this->Operator;
        return t;
    }

}SENSOR_DATA_T;



enum COMMAND_E{
    COM_STOP=1,
    CMD_INFO=2,
    CMD_DELETE,
    CMD_SELECT,
    CMD_READ_XI_SHU,
    CMD_BIAODING=7, // biaoding
    CMD_SAVE_XI_SHU,
    CMD_SAVE_INFOMATION,
    CMD_JIAN_DING=12, // jiangding
    CMD_QINGLING=18,
    CMD_GAI_LING_MING_DU,

};




class SensorModel
{
public:
    SensorModel();
private:
   int  Lizhi;
   int  FengZhi;
   int  BianHao;
   int  XingHao;
   QString SCChangJia;
   // N  KN  MN
   short DanWei;
   // 1 ,2,3,4
   short XiaoShu;

};

class AddRecorder{
    struct ListItem
    {
        QTableWidgetItem* item;
        bool focus;
        int index;
        bool valid;
        ListItem() {}
    };
 public:
    AddRecorder(){
        LastFocusItem =NULL;
        ItemList.clear();
    }
    void pushItem(QTableWidgetItem* item){
        ListItem it;
        it.item = item;
        it.focus = false;
        it.valid = false;
        it.index = ItemList.size();
        ItemList.append(it);
        if(it.index==0)
            setItemFocus(item);

    }

    void clearList(){
        ItemList.clear();
        LastFocusItem =NULL;
    }

    void setItemFocus(QTableWidgetItem* item){
        for(int i=0;i<ItemList.size();i++){
            if(ItemList[i].item==item){
                ItemList[i].focus = true;
                if(LastFocusItem!= NULL){
                    LastFocusItem->focus =false;
                    LastFocusItem->item->setSelected(false);
                }
                LastFocusItem = &ItemList[i];
                LastFocusItem->item->setSelected(true);
            }
        }
    }

    void onAddRecord(QString text){
        if(LastFocusItem!=NULL){
            LastFocusItem->item->setText(text);
            LastFocusItem->valid = true;
            if(LastFocusItem->index< ItemList.size()-1)
            {
                QTableWidgetItem *item = ItemList[LastFocusItem->index+1].item;
                setItemFocus(item);
            }else{
                QTableWidgetItem *item = ItemList[0].item;
                setItemFocus(item);
            }
        }
    }

    bool isValid(QTableWidgetItem* item){
        for(int i=0;i<ItemList.size();i++){
            if(ItemList[i].item==item){
                return ItemList[i].valid;
            }
        }
        return false;
    }
    void clearValid(QTableWidgetItem* item){
        for(int i=0;i<ItemList.size();i++){
            if(ItemList[i].item==item){
                ItemList[i].valid =false;
                break;
            }
        }
    }

    void setValidAll(){
        for(int i=0;i<ItemList.size();i++){
                ItemList[i].valid =true;
        }
    }

private:
    QList<ListItem> ItemList;
    ListItem *LastFocusItem;

};


inline QString GBK2UTF8(const QString &inStr)
{
    QTextCodec *gbk = QTextCodec::codecForName("GB18030");
    QTextCodec *utf8 = QTextCodec::codecForName("utf-8");

//    QString g2u = utf8->toUnicode(gbk->fromUnicode(inStr));              // gbk  convert utf8
        QString g2u = utf8->fromUnicode(inStr);              // gbk  convert utf8
    return g2u;
}

inline QString UTF82GBK(const QString &inStr)
{
    QTextCodec *gbk = QTextCodec::codecForName("GB18030");
    //QTextCodec *utf8 = QTextCodec::codecForName("UTF-8");

    QString utf2gbk = gbk->toUnicode(inStr.toLatin1());
//    QString utf2gbk = gbk->toUnicode(inStr.toLocal8Bit());
    return utf2gbk;
}

inline std::string gbk2utf8(const QString &inStr)
{
    return GBK2UTF8(inStr).toStdString();
}

inline QString utf82gbk(const std::string &inStr)
{
    QString str = QString::fromStdString(inStr);

    return UTF82GBK(str);
}


#endif // SENSORMODEL_H
