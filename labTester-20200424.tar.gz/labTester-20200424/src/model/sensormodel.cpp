#include "sensormodel.h"

SensorModel::SensorModel()
{

}
