#ifndef DEVICEMODEL_H
#define DEVICEMODEL_H
#include <QString>
#include "singleton.h"




class DeviceModel
{
public:
    DeviceModel();
    DECLARE_SINGLETON_0BJCE(DeviceModel)





};

#endif // DEVICEMODEL_H
