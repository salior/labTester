/****************************************************************************
**
** Copyright (C) 2012 Denis Shienkov <denis.shienkov@gmail.com>
** Copyright (C) 2012 Laszlo Papp <lpapp@kde.org>
** Contact: https://www.qt.io/licensing/
**
** This file is part of the QtSerialPort module of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "ui_mainwindow.h"
#include <QtCore/QtGlobal>

#include <QMainWindow>

#include <QtSerialPort/QSerialPort>

#include <sensorwidget.h>
#include "dashboarddialog.h"
#include "biaodingdialog.h"
#include <QMap>
#include <QChart>
#include <QChartView>
#include <QtCharts/QDateTimeAxis>
#include <QLineSeries>
#include "QValueAxis"
#include <QPushButton>
#include <QGuiApplication>
#include <QScreen>
#include <QFileDialog>


QT_BEGIN_NAMESPACE

class QLabel;

namespace Ui {
class MainWindow;
}

QT_END_NAMESPACE

QT_CHARTS_USE_NAMESPACE

class Console;
class SettingsDialog;


class MyChartView : public QObject{
    Q_OBJECT
  public:
    explicit MyChartView(Ui::MainWindow * ui,QPushButton* saveButton,QPushButton* clearButton, QWidget *parent = nullptr){
        mUI = ui;

        mParent  = parent;
        int maxSize = 5000;
        chart = new QChart();
        chartView = new QChartView(chart,parent);
       // chartView->setRubberBand(QChartView::RectangleRubberBand);

        series = new QLineSeries;
        chart->addSeries(series);

        for(int i=0;i<maxSize;++i){
            series->append(i,0);
        }
        series->setUseOpenGL(true);//openGl 加速
        qDebug()<<series->useOpenGL();

        QDateTimeAxis *axisX = new QDateTimeAxis;
        axisX->setTickCount(10);
        axisX->setFormat("MMM yyyy");
        axisX->setTitleText("时间");
        chart->addAxis(axisX, Qt::AlignBottom);
        series->attachAxis(axisX);

        QValueAxis *axisY = new QValueAxis;
        axisY->setLabelFormat("%i");
        axisY->setTitleText("力值");
        chart->addAxis(axisY, Qt::AlignLeft);
        series->attachAxis(axisY);

        chartView->setMinimumSize(640, 480);

        chartView->resize(parent->size());


        QObject::connect(saveButton,&QPushButton::clicked,[this](){
            emit onSaveClicked();


        });
        QObject::connect(clearButton,&QPushButton::clicked,[=](){
            emit onClearClicked();
        });
    }

    void changedId(QList<UPDATE_DATA_T> list){
        series->clear();
        foreach (UPDATE_DATA_T item, list) {
            series->append(item.time,item.LiZhi);
        }
    }

    void onUpatedData(UPDATE_DATA_T item){
        series->append(item.time,item.LiZhi);
    }


private:
    QWidget*mParent;
    Ui::MainWindow *mUI;
    QChart* chart;
    QChartView *chartView;
    QLineSeries *series;
Q_SIGNALS:
    void onSaveClicked();
    void onClearClicked();
public:
    QChartView* getChartView(){
        return chartView;
    }
};


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void about();
//    void handleError(QSerialPort::SerialPortError error);

    void onChangedId(bool left,int id);
    void onCellChanged(int row,int col);
    void onCellChanged2(int row,int col);
    void onUpdatedLiZhi(int id);
    void onUpdatedAD(int id);


private:
    void initMenus();
    void initActionsConnections();
    void initDashboard();
    void initJianDingTableWidget();
    void initBiaoDingTableWidget();
    void initChart();
    void exportTableData(int id,bool jianDing);
    void fillJianDingTableData(int id,bool jianDing,int dianshu);
    void calculateJianDingTable(int id);
    void updateJianDingInfo(int id);

    void updateBiaoDingInfo(int id);
    void calculateBiaoDingTable(int id);
    void fillBiaoDingTableData(int id,int dianshu);

    void onTableWidgetStandby(int dianshu,QTableWidget *tw);
    void onStartBiaoDing(int id);

private:
    void showStatusMessage(const QString &message);
    QMap<int,SensorWidget*> sensorWidgetMap;
    QMap<int,SensorWidget*> sensorWidgetHeaderMap;
    QMap<int,MyChartView*>  myChartViewMap;

    Ui::MainWindow *ui;
    DashboardDialog* dashboardDlg;
    BiaoDingDialog *biaoDingDlg;

    AddRecorder addRecorder;

//    QChart* chart2;
//    QChartView *chartView2;
//    QLineSeries *series2;

    QLabel *status;
    Console *console;
    SettingsDialog *settings;
    int selected_1_id;
    int selected_2_id;
//    int jianding_id;
};

#endif // MAINWINDOW_H
