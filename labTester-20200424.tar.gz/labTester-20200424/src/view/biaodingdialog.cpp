#include "biaodingdialog.h"
#include "ui_biaodingdialog.h"
#include "testermodel.h"
#include "masterthread.h"
#include <QDate>
#include <QFileDialog>
#include "xlsl.h"
#include <QMessageBox>
#include <QTimer>
#include <thread>
#include <QtWidgets/QGraphicsDropShadowEffect>
#include <QInputDialog>-2


static QString getCellText(float v,int d=6){
//    QString r =QString("%1").arg(v);
//    QString r = v==0?"":QString("%1").arg(v,0,'f',d);
        QString r = QString("%1").arg(v,0,'f',d);
    return r;
}
static float getCellValue(QString text){
    float r =  text.length()==0?0:text.toFloat();
    return r;
}
static int addValid(QString text){
    int count = text.length()==0?0:1;
    return count;
}
bool checkPassword(QDialog* parent){
    bool ok;
    QString text = QInputDialog::getText(parent, "输入密码",
                                         "请输入密码", QLineEdit::Normal,
                                         "", &ok);
    if (!ok)
        return false;
    else if(text !="123456"){
        QMessageBox::information(parent,"密码错误","密码错误!");
        return false;
    }

    return true;
}
BiaoDingDialog::BiaoDingDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::BiaoDingDialog)
{
    ui->setupUi(this);
    initDialog();
    select_id =1;

}

BiaoDingDialog::~BiaoDingDialog()
{
    delete ui;
}

void BiaoDingDialog::onCellChanged2(int row, int col)
{
    qDebug()<<__FUNCTION__;
    if(row>1 && col>0 && row < 13 && col < 5){
        qDebug() << "on CellChanged" << row << " " << col;
        if(ui->tableWidget_2->item(row,col)->text().length()==0){
           addRecorder.clearValid(ui->tableWidget_2->item(row,col));
        }
        calculateBiaoDingTable(select_id);
    }else{
        qDebug() << "out of table edited.";
    }
}

void BiaoDingDialog::onChangedIndex(int index)
{
    // int id = ui->comboBox->currentData().toInt();
    select_id = index+1;
    const SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(select_id);
    if(!model){
        ui->lineEdit_xinghao->setText("");
        ui->lineEdit_celiangfanwei->setText("");
        ui->lineEdit_chuchangbianhao->setText("");
        ui->lineEdit_changjia->setText("");
        ui->lineEdit_zhengshuhao->setText("");
        ui->lineEdit_jishuzhibiao->setText("");
        ui->lineEdit_jiashudu->setText("");
        ui->lineEdit_youxiaoriqi->setText("");
        ui->pushButton_shanchu->setVisible(false);
        return ;
    }

    ui->pushButton_shanchu->setVisible(model->enabled);
    ui->lineEdit_xinghao->setText(model->XingHao);
    ui->lineEdit_celiangfanwei->setText(QString("%1").arg(model->CeLiangFanWei));
    ui->lineEdit_chuchangbianhao->setText(model->BianHao);
    ui->lineEdit_changjia->setText(model->SCChangJia);
    ui->lineEdit_zhengshuhao->setText(model->ZhengShuHao);
    ui->lineEdit_jishuzhibiao->setText(model->JiShuZhiBiao);
    ui->lineEdit_jiashudu->setText(QString("%1").arg(model->ZhongLiJiaShuDu));
    ui->lineEdit_youxiaoriqi->setText(model->ZhengShuYouXiaoRiQi);
    if(model->XiaoShu==1){
        ui->radioButton_1wei->setChecked(true);
    }
    else if(model->XiaoShu==2){
        ui->radioButton_2wei->setChecked(true);
    }
    else if(model->XiaoShu==3){
        ui->radioButton_3wei->setChecked(true);
    }
    else if(model->XiaoShu==4){
        ui->radioButton_4wei->setChecked(true);
    }

    if(model->DanWei=="N"){
        ui->radioButton_n->setChecked(true);
    }
    else if(model->DanWei=="kN"){
        ui->radioButton_kn->setChecked(true);
    }
    else if(model->DanWei=="MN"){
        ui->radioButton_mn->setChecked(true);
    }
    else if(model->DanWei=="N.m"){
        ui->radioButton_nm->setChecked(true);
    }

    select_id = model->id;

    //    this->index = index;
}

bool BiaoDingDialog::validInputs()
{
    bool r = ui->lineEdit_xinghao->text().length()>0 &&
            ui->lineEdit_chuchangbianhao->text().length()>0 &&
            ui->lineEdit_celiangfanwei->text().length()>0 &&
            ui->lineEdit_jiashudu->text().length()>0;

    if(!r)
        ui->lineEdit_xinghao->setFocus();

    return r;
}

void BiaoDingDialog::refreshCombobox()
{
    ui->comboBox->clear();
    for(int i=0;i< MAX_SENSOR_COUNT;i++){
        int id = i +1;
        SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);
        if(!model){
            ui->comboBox->addItem(QString("%1路(%2)").arg(i+1).arg("空"),i+1);
        }else
            ui->comboBox->addItem(QString("%1路(%2)").arg(model->id).arg(model->BianHao),model->id);
    }
}

void BiaoDingDialog::showBiaoDing(bool f)
{
    if(f){
        ui->widget_biaoding->show();
        onChangedIndex(ui->comboBox->currentIndex());
        this->setFixedSize(QSize(898,660));
    }else{
        ui->widget_biaoding->hide();
        this->setFixedSize(QSize(898,150));
    }


    onTableWidgetStandby(0,ui->tableWidget_2);

}

void BiaoDingDialog::updateBiaoDingInfo(int id)
{

}
// 读取表格里面的数据 ，然后计算平均值 ，再写到表格
void BiaoDingDialog::calculateBiaoDingTable(int id)
{
    qDebug()<<__FUNCTION__;
    readBiaoDingTable(id);
    calculateXiShu(id);
    fillBiaoDingTableData(id);
}

void BiaoDingDialog::calculateXiShu(int id)
{
    qDebug()<<__FUNCTION__;
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);
    if(!model){
        qDebug()<<"error: id data not found";
        return;
    }

    int dianshu = std::min(MAX_RECORD_COUNT,model->Operator.DianShu);
    xishuRecorder.clear();
    for(int i=0;i<dianshu+1;i++){
//        if(model->BiaoDingList.size()>i)
        {
            xishuRecorder.addAD(model->BiaoDingList[i].BIAODINGDIAN,model->BiaoDingList[i].BIAODINGZHI_AVERAGE);
        }
    }
}
// 读取表格里面的数据到公共变量
void BiaoDingDialog::readBiaoDingTable(int id)
{
    qDebug()<<__FUNCTION__;
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);
    if(!model){
        qDebug()<<"error: id data not found";
        return;
    }

    int dianshu = 0;

    if(ui->radioButton_5dian_2->isChecked()){
        dianshu =5;
    }else if(ui->radioButton_8dian_2->isChecked()){
        dianshu =8;
    }else if(ui->radioButton_10dian_2->isChecked()){
        dianshu = 10;
    }else if(ui->radioButton_qita_2->isChecked()){
        dianshu = ui->lineEdit_qita->text().toInt();
    }else{
        dianshu = 10;
    }

    model->Operator.DianShu = dianshu;


    for(int i=0;i<model->Operator.DianShu+1;i++){
//        if(model->BiaoDingList.size()>i)
        {
            model->BiaoDingList[i].BIAODINGDIAN = getCellValue(ui->tableWidget_2->item(i+2,0)->text());
            model->BiaoDingList[i].BIAODINGZHI1 = getCellValue(ui->tableWidget_2->item(i+2,1)->text());
            model->BiaoDingList[i].BIAODINGZHI2 = getCellValue(ui->tableWidget_2->item(i+2,2)->text());
            model->BiaoDingList[i].BIAODINGZHI3 = getCellValue(ui->tableWidget_2->item(i+2,3)->text());

            int validCount = 0;
            validCount += addValid(ui->tableWidget_2->item(i+2,1)->text());
            validCount += addValid(ui->tableWidget_2->item(i+2,2)->text());
            validCount += addValid(ui->tableWidget_2->item(i+2,3)->text());
            validCount = std::max(validCount,1);
            model->BiaoDingList[i].BIAODINGZHI_AVERAGE = (model->BiaoDingList[i].BIAODINGZHI1+model->BiaoDingList[i].BIAODINGZHI2+
                                                          model->BiaoDingList[i].BIAODINGZHI3)/validCount;
        }

    }
}

// 把变量数据写入到表格里面

void BiaoDingDialog::fillBiaoDingTableData(int id)
{
    qDebug()<<__FUNCTION__;
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);
    if(!model){
        qDebug()<<"error: id data not found";
        return;
    }


    int dianshu = model->Operator.DianShu;
    qDebug()<<" model " << model << "dianshu :" << dianshu;
    for(int i=0;i<MAX_RECORD_COUNT;i++){
        if(i>dianshu){
            ui->tableWidget_2->item(i+2,0)->setText("");
            ui->tableWidget_2->item(i+2,1)->setText("");
            ui->tableWidget_2->item(i+2,2)->setText("");
            ui->tableWidget_2->item(i+2,3)->setText("");
            ui->tableWidget_2->item(i+2,4)->setText("");

        }else{
            ui->tableWidget_2->item(i+2,0)->setText(QString("%1").arg(model->BiaoDingList[i].BIAODINGDIAN));
            if(addRecorder.isValid(ui->tableWidget_2->item(i+2,1)))
                ui->tableWidget_2->item(i+2,1)->setText(getCellText(model->BiaoDingList[i].BIAODINGZHI1));
            if(addRecorder.isValid(ui->tableWidget_2->item(i+2,2)))
                ui->tableWidget_2->item(i+2,2)->setText(getCellText(model->BiaoDingList[i].BIAODINGZHI2));
            if(addRecorder.isValid(ui->tableWidget_2->item(i+2,3)))
                ui->tableWidget_2->item(i+2,3)->setText(getCellText(model->BiaoDingList[i].BIAODINGZHI3));
            ui->tableWidget_2->item(i+2,4)->setText(getCellText(model->BiaoDingList[i].BIAODINGZHI_AVERAGE));
        }
    }
}

void BiaoDingDialog::clearTable()
{
    for(int i=0;i<MAX_RECORD_COUNT;i++){
            ui->tableWidget_2->item(i+2,0)->setText("");
            ui->tableWidget_2->item(i+2,1)->setText("");
            ui->tableWidget_2->item(i+2,2)->setText("");
            ui->tableWidget_2->item(i+2,3)->setText("");
            ui->tableWidget_2->item(i+2,4)->setText("");

    }
}
// 开始标定 后准备好把小格子加入到跳转列表

void BiaoDingDialog::onTableWidgetStandby(int d, QTableWidget *tw)
{

    int dianshu = 0;

    if(ui->radioButton_5dian_2->isChecked()){
        dianshu =5;
    }else if(ui->radioButton_8dian_2->isChecked()){
        dianshu =8;
    }else if(ui->radioButton_10dian_2->isChecked()){
        dianshu = 10;
    }else if(ui->radioButton_qita_2->isChecked()){
        dianshu = ui->lineEdit_qita->text().toInt();
    }else{
        dianshu = 10;
    }
    //清空要记录的格子,并加入列表
    addRecorder.clearList();
    for(int i=0;i<dianshu+1;i++){
        addRecorder.pushItem(tw->item(i+2,1));
    }
    for(int i=0;i<dianshu+1;i++){
        addRecorder.pushItem(tw->item(i+2,2));
    }
    for(int i=0;i<dianshu+1;i++){
        addRecorder.pushItem(tw->item(i+2,3));
    }

    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(select_id);
    if(!model){
        qDebug()<<"error: id data not found";
        return;
    }



    model->Operator.DianShu = dianshu;

    for(int i=0;i<dianshu+1;i++){
//        if(model->BiaoDingList.size()>i)
        {
            model->BiaoDingList[i].BIAODINGDIAN =DIAN[dianshu-1][i];
        }
    }

    fillBiaoDingTableData(select_id);

}

void BiaoDingDialog::showEvent(QShowEvent *event)
{
    showBiaoDing(ui->pushButton_kaishibiaoding->isChecked());
    ui->widget_group->setEnabled(!ui->pushButton_kaishibiaoding->isChecked());
    ui->pushButton_biaoding->setChecked(false);
}

void BiaoDingDialog::initDialog()
{

    setWindowTitle("标定");
    ui->pushButton_tianjia->setVisible(false);
    ui->pushButton_shanchu->setVisible(false);


    refreshCombobox();

    onChangedIndex(0);

    connect(MasterThread::getInstance().get(),&MasterThread::addSensorEvent,[this](int id){
        refreshCombobox();
    });


    connect(ui->comboBox,SIGNAL(currentIndexChanged(int)),this,SLOT(onChangedIndex(int)));
    ui->pushButton_biaoding->setCheckable(true);
    connect(ui->pushButton_biaoding,&QPushButton::clicked,[=](){

        if(ui->pushButton_biaoding->isChecked()){
            if(!checkPassword(this)){
                ui->pushButton_biaoding->setChecked(false);
                return;
            }
            clearTable();
            showBiaoDing(true);
        }else{
            showBiaoDing(false);
        }
    });


    connect(ui->pushButton_shanchu,&QPushButton::clicked,[=](){
        int id = ui->comboBox->currentData().toInt();
        QMessageBox msgBox;
        msgBox.setText(QString("您确定要删除(id:%1) 吗？").arg(id));
        // msgBox.setInformativeText("Do you want to save your changes?");
        msgBox.setStandardButtons( QMessageBox::Yes | QMessageBox::Cancel);
        msgBox.setDefaultButton(QMessageBox::Yes);
        int ret = msgBox.exec();
        if(ret == QMessageBox::Yes){
            TesterModel::getInstance()->setSensorEnabledById(id);
            MasterThread::getInstance()->cmdSelectSensorById(id);
            MasterThread::getInstance()->cmdSaveInfomation(0,"");
            QTimer::singleShot(2000,[=](){
                refreshCombobox();
            });
        }


    });

    connect(ui->pushButton_tianjia,&QPushButton::clicked,[=](){
        MasterThread::getInstance()->cmdNewSensor();
        ui->lineEdit_xinghao->setText("");
        ui->lineEdit_celiangfanwei->setText("");
        ui->lineEdit_chuchangbianhao->setText("");
        ui->lineEdit_changjia->setText("");
        ui->lineEdit_zhengshuhao->setText("");
        ui->lineEdit_jishuzhibiao->setText("");
        ui->lineEdit_jiashudu->setText("");
        ui->lineEdit_youxiaoriqi->setText("");
    });

    // 按下保存按钮后
    connect(ui->pushButton_baocun,&QPushButton::clicked,[=](){

        if(!validInputs()){

            return ;
        }

        if(!checkPassword(this)){
            return;
        }

        //命令格式：9: 传感器id值+传感器型号+传感器编号+传感器检定时的当地重力系数+传感器量程+单位+传感器小数位+本次标定日期+生产厂家+技术指标+证书号+证书有效日期\n
        QString danwei = "N";
        QString xiaoshu = "1";
        if(ui->radioButton_1wei->isChecked()){
            xiaoshu ="1";
        }
        else if(ui->radioButton_2wei->isChecked()){
            xiaoshu ="2";
        }
        else if(ui->radioButton_3wei->isChecked()){
            xiaoshu ="3";
        }
        else if(ui->radioButton_4wei->isChecked()){
            xiaoshu ="4";
        }

        if(ui->radioButton_n->isChecked()){
            danwei ="N";
        }
        else if(ui->radioButton_kn->isChecked()){
            danwei ="kN";
        }
        else if(ui->radioButton_mn->isChecked()){
            danwei ="MN";
        }
        else if(ui->radioButton_nm->isChecked()){
            danwei ="N.m";
        }

        QString str = QString("%1+%2+%3+%4+%5+%6+%7+%8+%9+%10+%11").arg(
                    ui->lineEdit_xinghao->text())
                .arg(ui->lineEdit_chuchangbianhao->text())
                .arg(ui->lineEdit_jiashudu->text())
                .arg(ui->lineEdit_celiangfanwei->text())
                .arg(danwei)
                .arg(xiaoshu)
                .arg(QDate::currentDate().toString("yyyy.MM.dd"))
                .arg(ui->lineEdit_changjia->text())
                .arg(ui->lineEdit_jishuzhibiao->text())
                .arg(ui->lineEdit_zhengshuhao->text())
                .arg(ui->lineEdit_youxiaoriqi->text());
        //        MasterThread::getInstance()->cmdNewSensor();

        MasterThread::getInstance()->cmdSelectSensorById(select_id);
//        MasterThread::getInstance()->cmdSaveXiShu(select_id,"");
        QThread::sleep(1);
        MasterThread::getInstance()->cmdSaveInfomation(select_id,str);




    });

    connect(MasterThread::getInstance().get(),&MasterThread::saveInfoEvent,[=](bool f){
        if(f){
            QMessageBox::information(this,"保存","保存信息成功");

            QTimer::singleShot(2000,[=](){
                MasterThread::getInstance()->cmdSelectSensorById(select_id);
                QThread::sleep(1);
                MasterThread::getInstance()->cmdGetInfomation();
            });

        }else{
            QMessageBox::information(this,"保存","保存信息失败");
        }
    });


    initBiaoDingDlg();
}

void BiaoDingDialog::initBiaoDingDlg()
{
    connect(ui->pushButton_qingling,&QPushButton::clicked,[=](){
        MasterThread::getInstance()->cmdQingLing();
        ui->label_lizhi->setText("--");

    });


    connect(MasterThread::getInstance().get(),&MasterThread::updatedADEvent,[=](int id){
        if(select_id== id){
            const SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);
            if(!model){
                qDebug()<<"error: id data not found";
                return ;
            }
            ui->label_lizhi->setText(QString("%1").arg(model->AD,0,'r',5));
        }
    });
    connect(MasterThread::getInstance().get(),&MasterThread::saveXiShuEvent,[=](bool f){
        if(f){
            QMessageBox::information(this,"保存","保存系数成功");
        }else{
            QMessageBox::information(this,"保存","保存系数失败");
        }

    });

    // 从传感器读取标定系数
    connect(MasterThread::getInstance().get(),&MasterThread::readXiShuEvent,[=](QString str){
        QStringList sections = str.split(QRegExp("[+]"));
        if (sections.size() >1 )
        {
            int size = sections.size();
            int index =0;
            xishuRecorder.clear();
            for(int i=0;i<size;i+=2){
                QString biaodingzhi = sections[i];
                QString xishu = sections[i+1];
                xishuRecorder.fillResultData(size/2,biaodingzhi.toFloat(),xishu.toFloat());
                index++;
            }

            SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(select_id);
            if(!model){
                qDebug()<<"error: id data not found";
                return;
            }

            QList<XiShuRecord::stResult> list = xishuRecorder.getResult();
            model->Operator.DianShu = list.size()-1;
            for(int i=0;i<model->Operator.DianShu+1;i++) {
//                if(model->BiaoDingList.size()>i)
                {
                    model->BiaoDingList[i].BIAODINGDIAN = list[i].A;
                    model->BiaoDingList[i].BIAODINGZHI1 = list[i].L;
                }
            };

            switch (model->Operator.DianShu) {
            case 5:
                ui->radioButton_5dian_2->blockSignals(true);
                ui->radioButton_5dian_2->setChecked(true);
                ui->radioButton_5dian_2->blockSignals(false);
                break;
            case 8:
                ui->radioButton_8dian_2->blockSignals(true);
                ui->radioButton_8dian_2->setChecked(true);
                ui->radioButton_8dian_2->blockSignals(false);
                break;
            case 10:
                ui->radioButton_10dian_2->blockSignals(true);
                ui->radioButton_10dian_2->setChecked(true);
                ui->radioButton_10dian_2->blockSignals(false);
                break;
            default:
                ui->radioButton_qita_2->blockSignals(true);
                ui->lineEdit_qita->blockSignals(true);
                ui->radioButton_qita_2->setChecked(true);
                ui->lineEdit_qita->setText(QString("%1").arg(model->Operator.DianShu));
                ui->lineEdit_qita->blockSignals(false);
                ui->radioButton_qita_2->blockSignals(false);
                break;
            }


            ui->tableWidget_2->blockSignals(true);
            addRecorder.setValidAll();
            onTableWidgetStandby(model->Operator.DianShu,ui->tableWidget_2);
            fillBiaoDingTableData(select_id);
            readBiaoDingTable(select_id);
            fillBiaoDingTableData(select_id);

            ui->tableWidget_2->blockSignals(false);
        }
    });



    ui->tableWidget_2->setShowGrid(true);

    ui->tableWidget_2->verticalHeader()->setVisible(false);
    ui->tableWidget_2->horizontalHeader()->setVisible(false);
    ui->tableWidget_2->setRowCount(13);
    ui->tableWidget_2->setColumnCount(5);



    ui->tableWidget_2->setSpan(0,0,2,1);
    ui->tableWidget_2->setItem(0, 0, new QTableWidgetItem("标定点(N)"));
    ui->tableWidget_2->setSpan(0,1,1,3);
    ui->tableWidget_2->setItem(0, 1, new QTableWidgetItem("标定结果(N)"));
    ui->tableWidget_2->setItem(1, 1, new QTableWidgetItem("1"));
    ui->tableWidget_2->setItem(1, 2, new QTableWidgetItem("2"));
    ui->tableWidget_2->setItem(1, 3, new QTableWidgetItem("3"));
    ui->tableWidget_2->setSpan(0,4,2,1);
    ui->tableWidget_2->setItem(0, 4, new QTableWidgetItem(" 平均值 "));

    for(int i=0;i<13;i++){
        ui->tableWidget_2->setRowHeight(i,16);
        ui->tableWidget_2->setColumnWidth(i,126);
    }


    for(int i=0;i<MAX_RECORD_COUNT;i++){
        for(int j=0;j<5;j++)
            ui->tableWidget_2->setItem(i+2, j, new QTableWidgetItem(""));
    }

    connect(ui->tableWidget_2, SIGNAL(cellChanged(int,int)), this, SLOT(onCellChanged2(int,int)));
    connect(ui->tableWidget_2, &QTableWidget::cellClicked, [this](int r,int c){
        addRecorder.setItemFocus(ui->tableWidget_2->currentItem());
    });

    //开始标定按钮事件
    ui->pushButton_kaishibiaoding->setCheckable(true);
    connect(ui->pushButton_kaishibiaoding,&QPushButton::clicked,[=](){
        //发送检定命令到设备
        if(!ui->pushButton_kaishibiaoding->isChecked()){
            ui->pushButton_kaishibiaoding->setText(" 开始标定 ");
            MasterThread::getInstance()->cmdStop();

            ui->widget_group->setEnabled(true);
        }else{
            ui->widget_group->setEnabled(false);
            int d = 0;
            if(ui->radioButton_5dian_2->isChecked()){
                d = 5;
            }
            else if(ui->radioButton_8dian_2->isChecked()){
                d = 8;
            }
            else if(ui->radioButton_10dian_2->isChecked()){
                d=10;
            }else{

            }
            MasterThread::getInstance()->cmdBiaoDing();
            onTableWidgetStandby(d,ui->tableWidget_2);
            addRecorder.setItemFocus(ui->tableWidget_2->item(2,1));
            ui->pushButton_kaishibiaoding->setText("停止标定");
        }
    });

    // 保存系数数据到传感器
    connect(ui->pushButton_cunru,&QPushButton::clicked,[=](){
        saveXiShu2MCU(select_id);

    });

    // 从excel 表导入数据到表格
    connect(ui->pushButton_daoruwenjian,&QPushButton::clicked,[=](){
        QFileDialog::Options options;

        options |= QFileDialog::DontUseNativeDialog;
        QString selectedFilter;

        QString filepath = QFileDialog::getOpenFileName(this,
                                                        tr("Open"),
                                                        "*.xls",
                                                        tr("Excel (*.xls)"),
                                                        &selectedFilter,
                                                        options);
        if (filepath.length() > 0)
        {
            SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(select_id);
            if(!model){
                qDebug()<<"error: id data not found";
                return;
            }
            if(XLSL::getInstance()->loadBiaoDing(model,filepath)){


                ;

                switch (model->Operator.DianShu) {
                case 5:
                    ui->radioButton_5dian_2->blockSignals(true);
                    ui->radioButton_5dian_2->setChecked(true);
                    ui->radioButton_5dian_2->blockSignals(false);
                    break;
                case 8:
                    ui->radioButton_8dian_2->blockSignals(true);
                    ui->radioButton_8dian_2->setChecked(true);
                    ui->radioButton_8dian_2->blockSignals(false);
                    break;
                case 10:
                    ui->radioButton_10dian_2->blockSignals(true);
                    ui->radioButton_10dian_2->setChecked(true);
                    ui->radioButton_10dian_2->blockSignals(false);
                    break;
                default:
                    ui->radioButton_qita_2->blockSignals(true);
                    ui->lineEdit_qita->blockSignals(true);
                    ui->radioButton_qita_2->setChecked(true);
                    ui->lineEdit_qita->setText(QString("%1").arg(model->Operator.DianShu));
                    ui->lineEdit_qita->blockSignals(false);
                    ui->radioButton_qita_2->blockSignals(false);
                    break;
                }



                onTableWidgetStandby(model->Operator.DianShu,ui->tableWidget_2);

                //屏蔽信号 不至于写入数据时候导致 时发生表格数据改变时候，触发信号

                ui->tableWidget_2->blockSignals(true);
                calculateXiShu(select_id);
                fillBiaoDingTableData(select_id);
                saveXiShu2MCU(select_id);
                ui->tableWidget_2->blockSignals(false);

            }else{
                QMessageBox::information(this, "load", "导入失败");
            }
        }
    });

    connect(ui->pushButton_duquyibaoxishu,&QPushButton::clicked,[=](){
        MasterThread::getInstance()->cmdReadXiShu(select_id);
    });


    connect(ui->pushButton_jilu_2,&QPushButton::clicked,[=](){
        if(!ui->pushButton_kaishibiaoding->isChecked())
        {
            return;
        }
        SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(select_id);
        if(!model){
            qDebug()<<"error: id data not found";
            return;
        }
        addRecorder.onAddRecord(QString("%1").arg(model->AD,0,'f',6));
    });
    connect(ui->pushButton_daochu_2,&QPushButton::clicked,[=](){
        readBiaoDingTable(select_id);

        QString str = QString("%1-%2-%3.xls").arg(ui->lineEdit_xinghao->text()).arg(ui->lineEdit_celiangfanwei->text()).arg(QDateTime::currentDateTime().toString("yyyyMMdd"));
#ifndef DEVELOPMENT
        QString filepath = QFileDialog::getSaveFileName(this,"保存",str,"Excel(*.xls)");
        if (filepath.length() > 0)
        {
            SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(select_id);
            if(!model){
                qDebug()<<"error: id data not found";
                return;
            }
            if(XLSL::getInstance()->exportBiaoDing2(model,filepath)){

                QMessageBox::information(this, "保存", "导出成功");
            }
            else
                QMessageBox::information(this, "保存", "导出失败");
        }

# else
        SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(select_id);
        if(!model){
            qDebug()<<"error: id data not found";
            return;
        }
        if(XLSL::getInstance()->exportBiaoDing2(model,"")){

            QMessageBox::information(this, "保存", "导出成功");
        }
        else
            QMessageBox::information(this, "保存", "导出失败");

#endif

    });

    connect(ui->radioButton_5dian_2,&QPushButton::clicked,[=](){
        clearTable();
        onTableWidgetStandby(5,ui->tableWidget_2);
        addRecorder.setItemFocus(ui->tableWidget_2->item(2,1));
        calculateBiaoDingTable(select_id);
    }
    );
    connect(ui->radioButton_8dian_2,&QPushButton::clicked,[=](){
        clearTable();
        onTableWidgetStandby(8,ui->tableWidget_2);
        addRecorder.setItemFocus(ui->tableWidget_2->item(2,1));
        calculateBiaoDingTable(select_id);
    }
    );
    connect(ui->radioButton_10dian_2,&QPushButton::clicked,[=](){
        clearTable();
        onTableWidgetStandby(10,ui->tableWidget_2);
        addRecorder.setItemFocus(ui->tableWidget_2->item(2,1));
        calculateBiaoDingTable(select_id);
    }
    );


    connect(ui->pushButton_duquyibaoxishu,&QPushButton::clicked,[=](){
        //        MasterThread::getInstance()->cmd
    }
    );

    connect(ui->radioButton_qita_2,&QPushButton::clicked,[=](){
        int d = ui->lineEdit_qita->text().toInt();
        if(d< MAX_RECORD_COUNT && d >0){
            clearTable();
            onTableWidgetStandby(d,ui->tableWidget_2);
        }
    }
    );

    ui->lineEdit_qita->setMaxLength(1);
    connect(ui->lineEdit_qita,&QLineEdit::textChanged,[=](const QString t){
        int d = t.toInt();
        if(d< MAX_RECORD_COUNT && d >0 && ui->radioButton_qita_2->isChecked()){
            clearTable();
            onTableWidgetStandby(d,ui->tableWidget_2);
            addRecorder.setItemFocus(ui->tableWidget_2->item(2,1));
            calculateBiaoDingTable(select_id);
        }
    }
    );
}

void BiaoDingDialog::saveXiShu2MCU(int id)
{
    qDebug()<<__FUNCTION__;
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);
    if(!model){
        qDebug()<<"error: id data not found";
        return;
    }
    QString xishu = QString("");
    int dianshu = model->Operator.DianShu;

    QList<XiShuRecord::stResult> list = xishuRecorder.getResult();

//    foreach (XiShuRecord::stResult item, list) {
//        xishu +=QString("%1+%2+").arg(item.B).arg(item.K);
//    }

    // 20200408 只保留整数

    for(int i=1;i<list.size();i++){
        xishu +=QString("%1+%2+").arg(list[i].B,0,'f',0).arg(list[i].K,0,'f',12);
    }


    if(xishu.endsWith("+")){
        xishu = xishu.left(xishu.length()-1);
    }
    MasterThread::getInstance()->cmdSelectSensorById(id);
    qDebug() << "save xishu value "<< xishu;
    MasterThread::getInstance()->cmdSaveXiShu(id,xishu);
}
