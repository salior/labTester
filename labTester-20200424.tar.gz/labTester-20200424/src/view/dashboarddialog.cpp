#include "dashboarddialog.h"
#include "ui_dashboarddialog.h"


DashboardDialog::DashboardDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DashboardDialog)
{
    ui->setupUi(this);
    initDashboard();
}

DashboardDialog::~DashboardDialog()
{
    delete ui;
}

void DashboardDialog::initDashboard()
{
    int colSpacing = 2;
    int rowSpacing = 2;
    int col = 4;
    int row = 3;
    int viewHeight=1,viewWidth=1;


    for(int i=0;i<MAX_SENSOR_COUNT;i++){

        sensorWidgetMap[i] = new SensorWidget(ui->widget);
        sensorWidgetMap[i]->setModelId(false,i+1);
        viewHeight = sensorWidgetMap[i]->geometry().height();
        viewWidth = sensorWidgetMap[i]->geometry().width();

        int posY = (i/col)*viewHeight+rowSpacing;
        int posX = i%col*viewWidth+colSpacing;
        sensorWidgetMap[i]->setGeometry(posX,posY,viewWidth,viewHeight);

        qDebug()<< " " <<i <<  " x: "<< posX << " y:" <<posY;
    }


    this->setGeometry(0,0,viewWidth*col+col*4*colSpacing,viewHeight*MAX_SENSOR_COUNT/col+row*rowSpacing*8);
    this->move(parentWidget()->geometry().center() - this->rect().center());
}
