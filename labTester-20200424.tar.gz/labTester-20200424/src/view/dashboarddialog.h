#ifndef DASHBOARDDIALOG_H
#define DASHBOARDDIALOG_H

#include <QDialog>
#include <sensorwidget.h>
#include <QMap>

namespace Ui {
class DashboardDialog;
}

class DashboardDialog : public QDialog
{
    Q_OBJECT

public:
    explicit DashboardDialog(QWidget *parent = 0);
    ~DashboardDialog();

private:
    Ui::DashboardDialog *ui;
    void initDashboard();
    QMap<int,SensorWidget*> sensorWidgetMap;
};

#endif // DASHBOARDDIALOG_H
