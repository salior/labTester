#ifndef BIAODINGDIALOG_H
#define BIAODINGDIALOG_H

#include <QDialog>
#include "sensormodel.h"
namespace Ui {
class BiaoDingDialog;
}

//const int DIAN_1[]={100};
//const int DIAN_2[]={50,100};
//const int DIAN_3[]={30,60,100};
//const int DIAN_4[]={25,50,75,100};
//const int DIAN_5[]={20,40,60,80,100};
//const int DIAN_6[]={10,20,40,60,80,100};
//const int DIAN_7[]={10,20,30,40,60,80,100};
//const int DIAN_8[]={10,20,30,40,50,60,80,100};
//const int DIAN_9[]={10,20,30,40,50,60,70,80,100};
//const int DIAN_10[]={10,20,30,40,50,60,70,80,90,100};

const int DIAN[11][11]={
    {0,100},
    {0,50,100},
    {0,30,60,100},
    {0,25,50,75,100},
    {0,20,40,60,80,100},
    {0,10,20,40,60,80,100},
    {0,10,20,30,40,60,80,100},
    {0,10,20,30,40,50,60,80,100},
    {0,10,20,30,40,50,60,70,80,100},
    {0,10,20,30,40,50,60,70,80,90,100}
};


class XiShuRecord
{
public:
    struct stResult
    {
        float A;
        float L;
        float B;
        float K;
    };

    void clear(){
        mResult.clear();
    }
    XiShuRecord() {
        mResult.clear();
    }
    void addAD(float a,float l){
        stResult r = calculate(a,l);
        addResult(r);
    }

    void updateAD(int index,float a,float l){
        stResult r = calculate(a,l);
        mResult.replace(index,r);
    }

    QList<stResult> getResult(){
        return mResult;
    }

    void fillResultData(int dianshu,float b,float k){
        stResult r;
        r.B = b;
        r.K = k;
        r.L = b*2.956/1000000;
        if(dianshu>0 && dianshu< MAX_RECORD_COUNT)
            r.A = DIAN[dianshu-1][mResult.size()];
        else r.A =0;

        if(mResult.size()==0){
            r.A = DIAN[dianshu-1][1];
            stResult first ;
            first.A = 0;
            first.K = -1;
            if(r.K!=0)
                first.B =r.B - r.A/r.K;
            else
                first.B = 0;
            first.L = first.B*2.956/1000000;

            mResult.append(first);
            qDebug()<< "fill data A:"<<first.A << " L:"<< first.L << " B:"<< first.B << " K:"<< first.K;

        }

        qDebug()<< "fill data A:"<<r.A << " L:"<< r.L << " B:"<< r.B << " K:"<< r.K;

        mResult.append(r);
    }
private:
    void addResult(stResult t){
        if(mResult.size()>MAX_RECORD_COUNT){
            qDebug() << "error:max size is 11";
            return;
        }
        mResult.append(t);
    }

    stResult calculate(float a,float l){

        stResult r;
        r.L = l;
        r.A = a;
        r.B = float(r.L/2.956)*1000000;;
        if(mResult.size()==0){
           r.K = -1;
        }else{
            stResult& last = mResult.last();
            if(r.B-last.B==0)
                r.K =0;
            else
                r.K = (r.A -last.A) / (r.B-last.B);

        }

        qDebug()<< "calculate data: A:"<<r.A << " L:"<< r.L << " B:"<< r.B << " K:"<< r.K;

        return r;

    }

    stResult mFirst;
    QList<stResult> mResult;

};
class BiaoDingDialog : public QDialog
{
    Q_OBJECT

public:
    explicit BiaoDingDialog(QWidget *parent = 0);
    ~BiaoDingDialog();
private slots:
     void onCellChanged2(int row,int col);

     void onChangedIndex(int index);
private:

    bool validInputs();
    void refreshCombobox();
    void showBiaoDing(bool f);
    void updateBiaoDingInfo(int id);
    void calculateBiaoDingTable(int id);
    void calculateXiShu(int id);
    void readBiaoDingTable(int id);
    void fillBiaoDingTableData(int id);

    void clearTable();
    void onTableWidgetStandby(int d,QTableWidget *tw);
    void initDialog();

    void initBiaoDingDlg();

    void saveXiShu2MCU(int id);
protected:
   void showEvent(QShowEvent *event);
private:
    Ui::BiaoDingDialog *ui;
    AddRecorder addRecorder;
    XiShuRecord xishuRecorder;

//    int index;
    int select_id;

};

#endif // BIAODINGDIALOG_H
