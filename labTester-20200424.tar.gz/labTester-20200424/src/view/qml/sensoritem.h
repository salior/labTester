#ifndef SENSORITEM_H
#define SENSORITEM_H

#include <QtQuick/QQuickItem>
#include "sensormodel.h"
#include "masterthread.h"
#include "testermodel.h"
#include "testcontrol.h"
class SensorItem:  public  QQuickItem
{
    Q_OBJECT
    Q_PROPERTY( QString LIZHI READ name NOTIFY itemChanged)
    Q_PROPERTY( int sid READ getId WRITE setId)
//    Q_PROPERTY( UPDATE_DATA_T  aa  READ up NOTIFY itemChanged)

public:
    SensorItem(QQuickItem *parent = 0);
    ~SensorItem();
    QString name() const{
        return mLiZhi;
    }

    int getId(){
        return mId;
    }

    void setId(int id){

        qDebug()<<"set id " << id << "thread "  <<MasterThread::getInstance().get();
        this->mId = id;
    }

private:
    int mId ;
    QString mLiZhi;
 //   UPDATE_DATA_T updateData;
signals:
    void itemChanged();

public slots:
    void onItemUpated(int id){
        qDebug()<<"on item update..";
    }

};

#endif // SENSORITEM_H
