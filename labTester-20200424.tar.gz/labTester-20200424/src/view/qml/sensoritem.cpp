#include "sensoritem.h"
#include <QThread>
#include <thread>
#include "testermodel.h"

#include "masterthread.h"
SensorItem::SensorItem(QQuickItem *parent): QQuickItem(parent)
{
    this->mLiZhi = "0.0000";
    connect(MasterThread::getInstance().get(),&MasterThread::updatedEvent,[=](int id) {
       if(this->getId() == id)
        {
            SENSOR_DATA_T* model =  TesterModel::getInstance()->getSensorDataById(id);
            if(model){
                this->mLiZhi = QString("%1").arg(model->LiZhi,0,'r',6);
               emit itemChanged();
            }
        }

    });


}

SensorItem::~SensorItem()
{
    disconnect(MasterThread::getInstance().get(),0);
}
