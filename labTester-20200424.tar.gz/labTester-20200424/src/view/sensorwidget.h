#ifndef SENSORWIDGET_H
#define SENSORWIDGET_H
#include <sensormodel.h>
#include <QWidget>
#include <QStateMachine>
#include <QStackedLayout>
namespace Ui {
class SensorWidget;
}


//enum QtMaterialStateTransitionType {
//    // Snackbar
//    SnackbarShowTransition = 1,
//    SnackbarHideTransition,
//    SnackbarWaitTransition,
//    SnackbarNextTransition,
//    // FlatButton
//    FlatButtonPressedTransition,
//    FlatButtonCheckedTransition,
//    FlatButtonUncheckedTransition,
//    // CollapsibleMenu
//    CollapsibleMenuExpand,
//    CollapsibleMenuCollapse,
//    // Slider
//    SliderChangedToMinimum,
//    SliderChangedFromMinimum,
//    SliderNoFocusMouseEnter,
//    SliderNoFocusMouseLeave,
//    // Dialog
//    DialogShowTransition,
//    DialogHideTransition,
//    //
//    MaxTransitionType = 65535
//};

//struct QtMaterialStateTransitionEvent : public QEvent
//{
//    QtMaterialStateTransitionEvent(QtMaterialStateTransitionType type)
//        : QEvent(QEvent::Type(QEvent::User + 1)),
//          type(type)
//    {
//    }

//    QtMaterialStateTransitionType type;
//};

//#include <QAbstractTransition>

//class QtMaterialStateTransition : public QAbstractTransition
//{
//    Q_OBJECT

//public:
//    QtMaterialStateTransition(QtMaterialStateTransitionType type){
//        m_type = type;
//    }

//protected:
//    virtual bool eventTest(QEvent *event){
//        if (event->type() != QEvent::Type(QEvent::User + 1)) {
//            return false;
//        }
//        QtMaterialStateTransitionEvent *transition = static_cast<QtMaterialStateTransitionEvent *>(event);
//        return (m_type == transition->type);
//    }
//    virtual void onTransition(QEvent *){

//    }

//private:
//    QtMaterialStateTransitionType m_type;
//};



class SensorWidget : public QWidget
{
    Q_OBJECT

public:
   explicit SensorWidget(QWidget *parent = 0,int headerType=SONSOR_WIDGET_BOARD);
    ~SensorWidget();
   void setModelId(int headerType,int id);
   int getId(){
       return id;
   }

  QString getCurrentValue();
  void doRefresh();
  void refreshCombobox();



private slots:
  void onChangedIndex(int index);
  void onDataUpdated(int id);


Q_SIGNALS:
  void onChangedId(int headerType,int id);
  void onChangedDanWei(QString danwei);
  void onChangedShow(bool f);
private:
      enum TransparencyMode {
          Transparent,
          SemiTransparent,
          Opaque,
      };
    QStateMachine          *stateMachine;
    QStackedLayout         *stackLayout;

    qreal                         m_opacity;
    TransparencyMode              m_mode;
    void initAnimation();


    QStackedLayout         *proxyStack;


    Ui::SensorWidget *ui;
    int id;
    int headerType;
//    bool isHeader;
    QString mCurrentDanWei;




    QString danWeiZhi(LIZHI_TYPE lizhi,int id);
    void onChangedId2DanWei(int id);
    void onQingLing();
    void onReset();


protected:
   void showEvent(QShowEvent *event);

protected:
    void paintEvent(QPaintEvent *event) Q_DECL_OVERRIDE;

};



#endif // SENSORWIDGET_H
