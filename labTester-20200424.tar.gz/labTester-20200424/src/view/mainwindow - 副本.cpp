/****************************************************************************
**
** Copyright (C) 2012 Denis Shienkov <denis.shienkov@gmail.com>
** Copyright (C) 2012 Laszlo Papp <lpapp@kde.org>
** Contact: https://www.qt.io/licensing/
**
** This file is part of the QtSerialPort module of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include "mainwindow.h"

#include "console.h"
#include "settingsdialog.h"

#include <QMessageBox>
#include <QLabel>
#include <QtSerialPort/QSerialPort>
#include "masterthread.h"
#include "xlsl.h"
#include "sensorwidget.h"
#include "testcontrol.h"
#include "testermodel.h"

#include <QTextCodec>
#include <QtSerialPort/QSerialPortInfo>
#include <QIntValidator>
//! [0]
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    status = new QLabel;
    ui->statusBar->addWidget(status);
  //  selected_1_id = 1;
    selected_1_id = 1;
    selected_2_id = 2;

    dashboardDlg = NULL;
    biaoDingDlg = NULL;

    initMenus();
    initDashboard();
    updateJianDingInfo(selected_1_id);
    initJianDingTableWidget();
    initChart();
    initActionsConnections();

    updateBiaoDingInfo(selected_1_id);
    initBiaoDingTableWidget();



    connect(MasterThread::getInstance().get(),SIGNAL(updated(int)),this,SLOT(onUpdatedLiZhi(int)));
    connect(MasterThread::getInstance().get(),SIGNAL(updatedAD(int)),this,SLOT(onUpdatedAD(int)));
}

MainWindow::~MainWindow()
{
    delete settings;
    delete ui;
}
void MainWindow::about()
{

    return;
    MasterThread::getInstance()->cmdGetInfomation();

    // QMessageBox::about(this, tr("About labTester"),tr("power by topgun studio 2020"));

}
//选择id变化后的动作
void MainWindow::onChangedId(bool left, int id)
{
    if(left){
        selected_1_id = id;
        updateJianDingInfo(id);
        updateBiaoDingInfo(id);
        SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorData(id-1);
        if(!model){
            qDebug()<<"error: id data not found";
            return;
        }

        myChartViewMap[0]->changedId(model->CurveList);
    }else{
        selected_2_id = id;
        SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorData(id-1);
        if(!model){
            qDebug()<<"error: id data not found";
            return;
        }
        myChartViewMap[1]->changedId(model->CurveList);
    }
}
//表格数据有变化后再数据处理
void MainWindow::onCellChanged(int row, int col)
{
    if(row>1 && col>0 && row < 13 && col < 7){
        calculateJianDingTable(selected_1_id);
    }else{
        qDebug() << "out of table edited.";
    }
}

void MainWindow::onCellChanged2(int row, int col)
{
    if(row>1 && col>0 && row < 13 && col < 7){
        calculateBiaoDingTable(selected_1_id);
    }else{
        qDebug() << "out of table edited.";
    }
}
//检定更新过来的数据
void MainWindow::onUpdatedLiZhi(int id)
{
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorData(id-1);
    if(!model){
        qDebug()<<"error: id data not found";
        return;
    }

    if(id==selected_1_id){
        myChartViewMap[0]->onUpatedData(model->CurveList.back());
    }else{
        myChartViewMap[1]->onUpatedData(model->CurveList.back());
    }
}
//标定过来的AD值
void MainWindow::onUpdatedAD(int id)
{

}

void MainWindow::initMenus()
{
    QString description;
    QString manufacturer;
    QString serialNumber;
    const auto infos = QSerialPortInfo::availablePorts();
    for (const QSerialPortInfo &info : infos) {
        QStringList list;
        description = info.description();
        manufacturer = info.manufacturer();
        serialNumber = info.serialNumber();

        QString portName = info.portName();

        QAction *action;

        action = new QAction(info.portName(), this);

        action->setCheckable(true);
        connect(action, &QAction::triggered, [=,portName](){

        });
        ui->menuCalls->addAction(action);

    }


}
static float getCellValue(QString text){
   float r =  text.length()==0?0:text.toFloat();
   return r;
}

static int addValid(QString text){
    int count = text.length()==0?0:1;
    return count;
}
void MainWindow::calculateJianDingTable(int id)
{
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorData(id-1);
    if(!model){
        qDebug()<<"error: id data not found";
        return;
    }

    int colCount = 7;
    int col =0;
    bool jianDing = ui->radioButton_jianding->isChecked();

    int dianshu = 0;

    if(ui->radioButton_5dian->isChecked()){

        dianshu =5;
    }else if(ui->radioButton_8dian->isChecked()){
        dianshu =8;
    }else if(ui->radioButton_10dian->isChecked()){
        dianshu = 10;
    }else{
        dianshu = 0;
    }

    for(int i=0;i<dianshu;i++){
       model->JianDingList[i].SHIYANLI = model->CeLiangFanWei/dianshu*(i+1);
    }

    for(int i=0;i<MAX_RECORD_COUNT;i++){
//            model->JianDingList[i].SHIYANLI = getCellValue(ui->tableWidget->item(i+2,0)->text());
        model->JianDingList[i].JINCHENG1 = getCellValue(ui->tableWidget->item(i+2,1)->text());
        model->JianDingList[i].JINCHENG2 = getCellValue(ui->tableWidget->item(i+2,2)->text());
        model->JianDingList[i].JINCHENG3 = getCellValue(ui->tableWidget->item(i+2,3)->text());

        int validCount = 0;
        validCount += addValid(ui->tableWidget->item(i+2,1)->text());
        validCount += addValid(ui->tableWidget->item(i+2,2)->text());
        validCount += addValid(ui->tableWidget->item(i+2,3)->text());
        validCount = std::max(validCount,1);
        model->JianDingList[i].JINCHENG_AVERAGE = (model->JianDingList[i].JINCHENG1+model->JianDingList[i].JINCHENG2+
                                                   model->JianDingList[i].JINCHENG3)/validCount;
        float maxf = std::max(model->JianDingList[i].JINCHENG1,model->JianDingList[i].JINCHENG2);
        maxf = std::max(maxf,model->JianDingList[i].JINCHENG3);

        float minf = std::min(model->JianDingList[i].JINCHENG1,float(999999.99));
        minf = std::min(minf,model->JianDingList[i].JINCHENG2==0?9999999:model->JianDingList[i].JINCHENG2);
        minf = std::min(minf,model->JianDingList[i].JINCHENG3==0?9999999:model->JianDingList[i].JINCHENG3);

        if(model->JianDingList[i].JINCHENG_AVERAGE==0){
            model->JianDingList[i].XIANDUIWUCHAI = 0;
            model->JianDingList[i].CHONGFUXING = 0;
        }else{
            model->JianDingList[i].XIANDUIWUCHAI = (model->JianDingList[i].SHIYANLI-model->JianDingList[i].JINCHENG_AVERAGE)*100/model->JianDingList[i].JINCHENG_AVERAGE;
            model->JianDingList[i].CHONGFUXING = (maxf -minf)*100/model->JianDingList[i].JINCHENG_AVERAGE;;
        }
      }

    fillJianDingTableData(id,jianDing,dianshu);

}

void MainWindow::initActionsConnections()
{

    connect(ui->actionDisconnect, &QAction::triggered, [=](){

        if(dashboardDlg==NULL)
            dashboardDlg = new DashboardDialog(this);
        dashboardDlg->show();
    });

    connect(ui->actionConnect, &QAction::triggered, [=](){
        ui->tabWidget_changui->setCurrentIndex(0);
    });

    connect(ui->actionConfigure, &QAction::triggered, [=](){
        ui->tabWidget_changui->setCurrentIndex(1);

    });
    connect(ui->actionClear, &QAction::triggered, [=](){
        if(biaoDingDlg==NULL){
            biaoDingDlg = new BiaoDingDialog();
        }
        biaoDingDlg->show();
    });
    connect(ui->actionQuit, &QAction::triggered, [=](){
       QApplication::quit();
    });
    connect(ui->actionAbout, &QAction::triggered, this, &MainWindow::about);
    connect(ui->actionAboutQt, &QAction::triggered, qApp, &QApplication::aboutQt);
}
//初始化看板列表
void MainWindow::initDashboard()
{
    sensorWidgetHeaderMap[0] = new SensorWidget(ui->widget_6,true);
    sensorWidgetHeaderMap[0]->setModelId(true,selected_1_id);

    connect(sensorWidgetHeaderMap[0],SIGNAL(onChangedId(bool,int)),this,SLOT(onChangedId(bool,int)));

//    sensorWidgetHeaderMap[0]->set
//    ui->widget_header_1->->setAlignment(sensorWidgetHeaderMap[0],Qt::AlignCenter);
    sensorWidgetHeaderMap[0]->setGeometry(0,0,sensorWidgetHeaderMap[0]->geometry().width(),sensorWidgetHeaderMap[0]->geometry().height());
    sensorWidgetHeaderMap[1] = new SensorWidget(ui->widget_7,true);
    sensorWidgetHeaderMap[1]->setModelId(false,selected_2_id);
    sensorWidgetHeaderMap[1]->setGeometry(0,0,sensorWidgetHeaderMap[1]->geometry().width(),sensorWidgetHeaderMap[1]->geometry().height());

    connect(sensorWidgetHeaderMap[1],SIGNAL(onChangedId(bool,int)),this,SLOT(onChangedId(bool ,int)));
}
//初始化表格界面
void MainWindow::initJianDingTableWidget()
{
    ui->tableWidget->setShowGrid(true);

    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->horizontalHeader()->setVisible(false);
    ui->tableWidget->setRowCount(13);
    ui->tableWidget->setColumnCount(7);

    ui->tableWidget->setSpan(0,0,2,1);
    ui->tableWidget->setItem(0, 0, new QTableWidgetItem("检定/校准点(N)"));
    ui->tableWidget->setSpan(0,1,1,3);
    ui->tableWidget->setItem(0, 1, new QTableWidgetItem("检定/校准结果(N)"));
    ui->tableWidget->setItem(1, 1, new QTableWidgetItem("1"));
    ui->tableWidget->setItem(1, 2, new QTableWidgetItem("2"));
    ui->tableWidget->setItem(1, 3, new QTableWidgetItem("3"));
    ui->tableWidget->setSpan(0,4,2,1);
    ui->tableWidget->setItem(0, 4, new QTableWidgetItem("平均值"));

    ui->tableWidget->setSpan(0,5,2,1);
    ui->tableWidget->setItem(0, 5, new QTableWidgetItem("示值误差%"));

    ui->tableWidget->setSpan(0,6,2,1);
    ui->tableWidget->setItem(0, 6, new QTableWidgetItem("重复性%"));

    ui->tableWidget->setItem(12, 0, new QTableWidgetItem("零点相对误差"));
    ui->tableWidget->setSpan(12,1,1,3);

    ui->tableWidget->setItem(12, 4, new QTableWidgetItem("零点漂移"));

    for(int i=0;i<MAX_RECORD_COUNT;i++){
        for(int j=0;j<7;j++)
          ui->tableWidget->setItem(i+2, j, new QTableWidgetItem(""));
    }

    connect(ui->tableWidget, SIGNAL(cellChanged(int,int)), this, SLOT(onCellChanged(int,int)));
    //connect(ui->tableWidget, SIGNAL(cell(int,int)), this, SLOT(onCellChanged(int,int)));

    ui->pushButton_kaishijianding->setCheckable(true);
    //开始检定按钮事件
    connect(ui->pushButton_kaishijianding,&QPushButton::clicked,[=](){
        //发送检定命令到设备
        if(!ui->pushButton_kaishijianding->isChecked()){
            ui->pushButton_kaishijianding->setText("开始检定");
            MasterThread::getInstance()->cmdJianDing();
            showStatusMessage("停止检定");
        }else{
            int d = 0;
            if(ui->radioButton_5dian->isChecked()){
                d = 5;
            }
            else if(ui->radioButton_8dian->isChecked()){
                d = 8;
            }
            else if(ui->radioButton_10dian->isChecked()){
                d=10;
            }else{

            }
            ui->pushButton_kaishijianding->setText("停止检定");
             MasterThread::getInstance()->cmdJianDing();
            onTableWidgetStandby(d,ui->tableWidget_2);

            addRecorder.setItemFocus(ui->tableWidget->item(2,1));
            showStatusMessage("开始检定");
        }
    });
    connect(ui->pushButton_jilu,&QPushButton::clicked,[=](){
        if(!ui->pushButton_kaishijianding->isChecked())
        {
            showStatusMessage("未开始检定，请按开始检定按钮开始");
            return;
        }
        SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorData(selected_1_id-1);
        if(!model){
            qDebug()<<"error: id data not found";
            return;
        }
        addRecorder.onAddRecord(QString("%1").arg(model->LiZhi));
    });
    connect(ui->pushButton_daochu,&QPushButton::clicked,[=](){
        QString filepath = QFileDialog::getSaveFileName(this,"保存","*.xlsx","文本文档(*.txt)");
        if (filepath.length() > 0)
        {
            if(ui->radioButton_jiaozhun)
                XLSL::getInstance()->exportCeLiang2(NULL,filepath);

            else
                XLSL::getInstance()->exportBiaoDing2(NULL,filepath);
        }
    });

    connect(ui->radioButton_5dian,&QPushButton::clicked,[=](){
        calculateJianDingTable(selected_1_id);
    }
    );
    connect(ui->radioButton_8dian,&QPushButton::clicked,[=](){
        calculateJianDingTable(selected_1_id);
    }
    );
    connect(ui->radioButton_10dian,&QPushButton::clicked,[=](){
        calculateJianDingTable(selected_1_id);
    }
    );

}

void MainWindow::initBiaoDingTableWidget()
{
    ui->tableWidget_2->setShowGrid(true);

    ui->tableWidget_2->verticalHeader()->setVisible(false);
    ui->tableWidget_2->horizontalHeader()->setVisible(false);
    ui->tableWidget_2->setRowCount(13);
    ui->tableWidget_2->setColumnCount(5);

    ui->tableWidget_2->setSpan(0,0,2,1);
    ui->tableWidget_2->setItem(0, 0, new QTableWidgetItem("标定点(N)"));
    ui->tableWidget_2->setSpan(0,1,1,3);
    ui->tableWidget_2->setItem(0, 1, new QTableWidgetItem("标定结果(N)"));
    ui->tableWidget_2->setItem(1, 1, new QTableWidgetItem("1"));
    ui->tableWidget_2->setItem(1, 2, new QTableWidgetItem("2"));
    ui->tableWidget_2->setItem(1, 3, new QTableWidgetItem("3"));
    ui->tableWidget_2->setSpan(0,4,2,1);
    ui->tableWidget_2->setItem(0, 4, new QTableWidgetItem("平均值"));


    for(int i=0;i<MAX_RECORD_COUNT;i++){
        for(int j=0;j<5;j++)
          ui->tableWidget_2->setItem(i+2, j, new QTableWidgetItem(""));
    }

    connect(ui->tableWidget_2, SIGNAL(cellChanged(int,int)), this, SLOT(onCellChanged2(int,int)));

    ui->pushButton_kaishibiaoding->setCheckable(true);
    //开始标定按钮事件
    connect(ui->pushButton_kaishibiaoding,&QPushButton::clicked,[=](){
        //发送检定命令到设备
        if(!ui->pushButton_kaishibiaoding->isChecked()){
            ui->pushButton_kaishibiaoding->setText("开始标定");

            showStatusMessage("停止标定");
        }else{
            int d = 0;
            if(ui->radioButton_5dian_2->isChecked()){
                d = 5;
            }
            else if(ui->radioButton_8dian_2->isChecked()){
                d = 8;
            }
            else if(ui->radioButton_10dian_2->isChecked()){
                d=10;
            }else{

            }
             MasterThread::getInstance()->cmdBiaoDing();
            onTableWidgetStandby(d,ui->tableWidget_2);
            addRecorder.setItemFocus(ui->tableWidget_2->item(2,1));
            ui->pushButton_kaishijianding->setText("停止标定");
            showStatusMessage("开始标定");
        }
    });
    connect(ui->pushButton_jilu_2,&QPushButton::clicked,[=](){
        if(!ui->pushButton_kaishibiaoding->isChecked())
        {
            showStatusMessage("未开始标定，请按开始标定按钮开始");
            return;
        }
        SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorData(selected_1_id-1);
        if(!model){
            qDebug()<<"error: id data not found";
            return;
        }
        addRecorder.onAddRecord(QString("%1").arg(model->LiZhi));
    });
    connect(ui->pushButton_daochu_2,&QPushButton::clicked,[=](){
        QString filepath = QFileDialog::getSaveFileName(this,"保存","*.xlsx","文本文档(*.txt)");
        if (filepath.length() > 0)
        {
             XLSL::getInstance()->exportBiaoDing2(NULL,filepath);
        }
    });

    connect(ui->radioButton_5dian_2,&QPushButton::clicked,[=](){
        calculateBiaoDingTable(selected_1_id);
    }
    );
    connect(ui->radioButton_8dian_2,&QPushButton::clicked,[=](){
        calculateBiaoDingTable(selected_1_id);
    }
    );
    connect(ui->radioButton_10dian_2,&QPushButton::clicked,[=](){
        calculateBiaoDingTable(selected_1_id);
    }
    );
    connect(ui->pushButton_shanchuxishu,&QPushButton::clicked,[=](){
//        MasterThread::getInstance()->cmd
    }
    );

}
//初始化曲线图表界面
void MainWindow::initChart()
{

     myChartViewMap[0] = new MyChartView(ui,ui->pushButton_baocun1,ui->pushButton_qingchu1,ui->widget_curve_1);
     myChartViewMap[1] = new MyChartView(ui,ui->pushButton_baocun2,ui->pushButton_qingchu2,ui->widget_curve_2);

     connect(myChartViewMap[0],&MyChartView::onSaveClicked,[=](){
         QString filepath = QFileDialog::getSaveFileName(this,"保存","*.png","输出曲线(*.png)");
         if (filepath.length() > 0)
         {
             QPixmap p = QPixmap::grabWidget(myChartViewMap[0]->getChartView());
             QImage image = p.toImage();
             image.save(filepath);
             qDebug()<<"export out png successed.";
             showStatusMessage("输出曲线图成功！");
         }
      }
     );
     connect(myChartViewMap[1],&MyChartView::onSaveClicked,[=](){
         QString filepath = QFileDialog::getSaveFileName(this,"保存","*.png","输出曲线(*.png)");
         if (filepath.length() > 0)
         {
             QPixmap p = QPixmap::grabWidget(myChartViewMap[1]->getChartView());
             QImage image = p.toImage();
             image.save(filepath);
             qDebug()<<"export out png successed.";
             showStatusMessage("输出曲线图成功！");
         }
     }
     );
     connect(myChartViewMap[0],&MyChartView::onClearClicked,[=](){
         TesterModel::getInstance()->clearCurve(selected_1_id);
        showStatusMessage("清除曲线1数据成功！");
     }
     );
     connect(myChartViewMap[1],&MyChartView::onClearClicked,[=](){
         TesterModel::getInstance()->clearCurve(selected_2_id);
        showStatusMessage("清除曲线2数据成功！");
     }
     );

}
//把表格里面的数据输出到变量列表
void MainWindow::exportTableData(int id,bool jianDing)
{
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorData(id-1);
    if(!model){
        qDebug()<<"error: id data not found";
        return;
    }
    if(ui->radioButton_1wei->isChecked()){
        model->XiaoShu = 1;
    }else {
        model->XiaoShu = 2;
    }

    if(ui->radioButton_laxiang){

    }else {

    }    
    calculateJianDingTable(id);

}

static QString getCellText(float v,int d=3){
    QString r = v==0?"":QString("%1").arg(v);
    return r;
}

//把数据填入数据表格
void MainWindow::fillJianDingTableData(int id, bool jianDing,int dianshu)
{
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorData(id-1);
    if(!model){
        qDebug()<<"error: id data not found";
        return;
    }
    for(int i=0;i<MAX_RECORD_COUNT;i++){
         if(i>=dianshu){
             ui->tableWidget->item(i+2,0)->setText("");
             ui->tableWidget->item(i+2,1)->setText("");
             ui->tableWidget->item(i+2,2)->setText("");
             ui->tableWidget->item(i+2,3)->setText("");
             ui->tableWidget->item(i+2,4)->setText("");
             ui->tableWidget->item(i+2,5)->setText("");
             ui->tableWidget->item(i+2,6)->setText("");

         }else{
            ui->tableWidget->item(i+2,0)->setText(getCellText(model->JianDingList[i].SHIYANLI));
            ui->tableWidget->item(i+2,1)->setText(getCellText(model->JianDingList[i].JINCHENG1));
            ui->tableWidget->item(i+2,2)->setText(getCellText(model->JianDingList[i].JINCHENG2));
            ui->tableWidget->item(i+2,3)->setText(getCellText(model->JianDingList[i].JINCHENG3));
            ui->tableWidget->item(i+2,4)->setText(getCellText(model->JianDingList[i].JINCHENG_AVERAGE));
            ui->tableWidget->item(i+2,5)->setText(QString("%1%").arg(model->JianDingList[i].XIANDUIWUCHAI));
            ui->tableWidget->item(i+2,6)->setText(QString("%1%").arg(model->JianDingList[i].CHONGFUXING));

        }
    }

}
//更新数据到检定表输入框
void MainWindow::updateJianDingInfo(int id)
{
    const SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorData(id-1);
    if(!model){
        qDebug()<<"error: id data not found";
        return;
    }

    ui->lineEdit_biaozhunqimingcheng->setText(model->BiaoZhunQiMingCheng);
    ui->lineEdit_celiangfanwei->setText(QString("%1").arg(model->CeLiangFanWei));
    ui->lineEdit_chuchangbianhao->setText(model->ChuChangBiaoHao);
    //    ui->lineEdit_danjuhao->setText(model->);
    ui->lineEdit_jiandingdidian->setText(model->JianDingDiDian);
    ui->lineEdit_jiandingriqi->setText(model->Operator.JiaoZhunriQi);
    ui->lineEdit_jiandingyuan->setText(model->Operator.JiaoZhunYuan);
    ui->lineEdit_jiaoyanyuan->setText(model->Operator.JianYanYuan);
    ui->lineEdit_jishuzhibiao->setText(model->JiShuZhiBiao);
    ui->lineEdit_kehumingcheng->setText("");
    ui->lineEdit_liangcheng->setText(QString("%1").arg(model->CeLiangFanWei));
    ui->lineEdit_shengchangchuangjia->setText(model->SCChangJia);
    ui->lineEdit_shidu->setText(QString("%1").arg(model->ShiDu));
    ui->lineEdit_wendu-> setText(QString("%1").arg(model->WenDu));
    ui->lineEdit_xinghao->setText(model->XingHao);
    ui->lineEdit_yiqimingcheng->setText(model->BiaoZhunQiMingCheng);
    ui->lineEdit_zhengshuyouxiaoqi->setText(model->ZhengShuYouXiaoRiQi);
}
//更新数据到标定表输入框
void MainWindow::updateBiaoDingInfo(int id)
{
    const SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorData(id-1);
    if(!model){
        qDebug()<<"error: id data not found";
        return;
    }

    ui->lineEdit_celiangfanwei_2->setText(QString("%1").arg(model->CeLiangFanWei));
    ui->lineEdit_chuchangbianhao_2->setText(model->ChuChangBiaoHao);
    //    ui->lineEdit_danjuhao->setText(model->);
    ui->lineEdit_jiashudu->setText(QString("%1").arg(model->ZhongLiJiaShuDu));
    ui->lineEdit_chuchangbianhao_2->setText(model->BianHao);
    if(model->DanWei=="N"){
        ui->radioButton_n->setChecked(true);
    }
    else if(model->DanWei=="kN"){
        ui->radioButton_kn->setChecked(true);
    }
    else if(model->DanWei=="MN"){
        ui->radioButton_mn->setChecked(true);
    }
    else{
        qDebug()<< "unknown danwei";
    }
    if(model->XiaoShu==1){
        ui->radioButton_1wei_2->setChecked(true);
    }
    else if(model->XiaoShu==2){
        ui->radioButton_2wei_2->setChecked(true);
    }
    else if(model->XiaoShu ==3){
        ui->radioButton_3wei_2->setChecked(true);
    }
    else if(model->XiaoShu ==4){
        ui->radioButton_4wei_2->setChecked(true);
    }else{
        qDebug()<< "unknown diaoshu.";
    }


    ui->lineEdit_xinghao_2->setText(model->XingHao);
}

void MainWindow::calculateBiaoDingTable(int id)
{
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorData(id-1);
    if(!model){
        qDebug()<<"error: id data not found";
        return;
    }

    int colCount = 5;
    int col =0;

    int dianshu = 0;

    if(ui->radioButton_5dian_2->isChecked()){

        dianshu =5;
    }else if(ui->radioButton_8dian_2->isChecked()){
        dianshu =8;
    }else if(ui->radioButton_10dian_2->isChecked()){
        dianshu = 10;
    }else{
        dianshu = 0;
    }

    for(int i=0;i<dianshu;i++){
       model->BiaoDingList[i].BIAODINGDIAN = model->CeLiangFanWei/dianshu*(i+1);
    }

    for(int i=0;i<MAX_RECORD_COUNT;i++){
        model->BiaoDingList[i].BIAODINGZHI1 = getCellValue(ui->tableWidget_2->item(i+2,1)->text());
        model->BiaoDingList[i].BIAODINGZHI2 = getCellValue(ui->tableWidget_2->item(i+2,2)->text());
        model->BiaoDingList[i].BIAODINGZHI3 = getCellValue(ui->tableWidget_2->item(i+2,3)->text());

        int validCount = 0;
        validCount += addValid(ui->tableWidget_2->item(i+2,1)->text());
        validCount += addValid(ui->tableWidget_2->item(i+2,2)->text());
        validCount += addValid(ui->tableWidget_2->item(i+2,3)->text());
        validCount = std::max(validCount,1);
        model->BiaoDingList[i].BIAODINGZHI_AVERAGE = (model->BiaoDingList[i].BIAODINGZHI1+model->BiaoDingList[i].BIAODINGZHI2+
                                                   model->BiaoDingList[i].BIAODINGZHI3)/validCount;


      }

    fillBiaoDingTableData(id,dianshu);
}

void MainWindow::fillBiaoDingTableData(int id, int dianshu)
{
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorData(id-1);
    if(!model){
        qDebug()<<"error: id data not found";
        return;
    }
    for(int i=0;i<MAX_RECORD_COUNT;i++){
         if(i>=dianshu){
             ui->tableWidget_2->item(i+2,0)->setText("");
             ui->tableWidget_2->item(i+2,1)->setText("");
             ui->tableWidget_2->item(i+2,2)->setText("");
             ui->tableWidget_2->item(i+2,3)->setText("");
             ui->tableWidget_2->item(i+2,4)->setText("");

         }else{
            ui->tableWidget_2->item(i+2,0)->setText(getCellText(model->BiaoDingList[i].BIAODINGDIAN));
            ui->tableWidget_2->item(i+2,1)->setText(getCellText(model->BiaoDingList[i].BIAODINGZHI1));
            ui->tableWidget_2->item(i+2,2)->setText(getCellText(model->BiaoDingList[i].BIAODINGZHI2));
            ui->tableWidget_2->item(i+2,3)->setText(getCellText(model->BiaoDingList[i].BIAODINGZHI3));
            ui->tableWidget_2->item(i+2,4)->setText(getCellText(model->BiaoDingList[i].BIAODINGZHI_AVERAGE));
        }
    }
}
// 开始检定

void MainWindow::onTableWidgetStandby(int d,QTableWidget *tw)
{

    //清空要记录的格子,并加入列表
    addRecorder.clearList();
    for(int i=0;i<d;i++){
        addRecorder.pushItem(tw->item(i+2,1));
    }
    for(int i=0;i<d;i++){
        addRecorder.pushItem(tw->item(i+2,2));
    }
    for(int i=0;i<d;i++){
         addRecorder.pushItem(tw->item(i+2,3));
    }
}

void MainWindow::onStartBiaoDing(int id)
{

}

void MainWindow::showStatusMessage(const QString &message)
{
    status->setText(message);
}
