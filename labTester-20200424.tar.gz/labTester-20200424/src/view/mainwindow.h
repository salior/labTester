/****************************************************************************
**
** Copyright (C) 2012 Denis Shienkov <denis.shienkov@gmail.com>
** Copyright (C) 2012 Laszlo Papp <lpapp@kde.org>
** Contact: https://www.qt.io/licensing/
**
** This file is part of the QtSerialPort module of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "ui_mainwindow.h"
#include <QtCore/QtGlobal>

#include <QMainWindow>

#include <QtSerialPort/QSerialPort>

#include <sensorwidget.h>
#include "dashboarddialog.h"
#include "biaodingdialog.h"
#include <QMap>
#include <QChart>
#include <QChartView>
#include <QtCharts/QDateTimeAxis>
#include <QLineSeries>
#include <QSplineSeries>
#include "QValueAxis"
#include <QPushButton>
#include <QGuiApplication>
#include <QScreen>
#include <QFileDialog>
#include <QDateTime>
#include <QTimer>
#include <QPointF>
#include <QFontDatabase>
#include <QIODevice>
#include <QFile>
#include <QGraphicsEffect>

#define MAX_SERIES  100
QT_BEGIN_NAMESPACE

class QLabel;

namespace Ui {
class MainWindow;
}

QT_END_NAMESPACE

QT_CHARTS_USE_NAMESPACE

class Console;
class SettingsDialog;



class FontManager
{
public:
    FontManager() {}

    static void setFont(QApplication*app){

        QString fontPath = QCoreApplication::applicationDirPath()+"/font/msyh.ttf";

        QString strFont =  loadFontFamilyFromFiles(fontPath);
        if(!strFont.isEmpty())
        {
            QFont font(strFont);
            font.setPointSize(9);//字体大小
            app->setFont(font);
            qDebug() <<"application set font ok ";

        }
        else
        {
            qDebug() <<"application set font Error";
        }
    }

    static QString loadFontFamilyFromFiles(const QString &fontFile)
    {
        QString font = "";

        QFile File(fontFile);
        if(!File.open(QIODevice::ReadOnly))
        {
            qDebug()<<"Open font file error";
            return font;
        }

        int loadedFontID = QFontDatabase::addApplicationFontFromData(File.readAll());
        QStringList loadedFontFamilies = QFontDatabase::applicationFontFamilies(loadedFontID);
        if(!loadedFontFamilies.empty())
        {
            font = loadedFontFamilies.at(0);
        }
        File.close();
        return font;

        }

};


class MyChartView : public QObject{
    Q_OBJECT
  public:
    explicit MyChartView(Ui::MainWindow * ui,QPushButton* saveButton,QPushButton* clearButton, QWidget *parent = nullptr){
        mUI = ui;

        mParent  = parent;

        tickCount = 10;

        mTimeRangeSeconds = 120;
        mTimeLeaveSeconds = 2;

        QDateTime pass = QDateTime::currentDateTime().addSecs(-tickCount/2);
        QDateTime noww = QDateTime::currentDateTime().addSecs(tickCount/2);


        maxY = 0;
        minY = 9999999;

        lastTime = noww.toMSecsSinceEpoch();
        chart = new QChart();

       // chartView->setRubberBand(QChartView::RectangleRubberBand);

        chart->setAnimationOptions(QChart::AllAnimations);
        series = new QSplineSeries;

        QPen green(Qt::blue);
        green.setWidth(3);
        series->setPen(green);

        series->setUseOpenGL(true);//openGl 加速
        qDebug()<<series->useOpenGL();

        QDateTimeAxis *axisX = new QDateTimeAxis;
        axisX->setTickCount(tickCount);
        axisX->setFormat("mm:ss");
        axisX->setTitleText("时间");
        axisX->setMin(pass);
        axisX->setMax(noww);
        chart->addAxis(axisX, Qt::AlignBottom);


        QValueAxis *axisY = new QValueAxis;
        axisY->setLabelFormat("%.2f");
        axisY->setTitleText(" 力值 ");
        axisY->setRange(-200,6000);
        chart->addAxis(axisY, Qt::AlignLeft);
    //    series->append(pass.toMSecsSinceEpoch(),236);
    //    series->append(noww.toMSecsSinceEpoch(),3222);

        chart->addSeries(series);
        series->attachAxis(axisX);
        series->attachAxis(axisY);

        chartView = new QChartView(chart,parent);

        chartView->setRenderHint(QPainter::Antialiasing);
        chartView->setMinimumSize(494, 358);
    //    chartView->resize(parent->size());

        timer = new QTimer(this);
          connect(timer,&QTimer::timeout,[=](){
//            QDateTime pass = QDateTime::currentDateTime().addSecs(-2*60);
//            QDateTime noww = QDateTime::currentDateTime();
//            chart->axisX()->setMin(pass);
//            chart->axisX()->setMax(noww);
            if(series->count()==0) return;

//            qreal x =chart->plotArea().width() / tickCount;
//            chart->scroll(x,0);
        });

       // timer->start();

//        timerAction(true);

        QObject::connect(saveButton,&QPushButton::clicked,[this](){
            emit onSaveClicked();


        });
        QObject::connect(clearButton,&QPushButton::clicked,[=](){
            emit onClearClicked();
        });
    }

    void changedId(QList<UPDATE_DATA_T> list,float range){

        maxY = 0;
        minY = 9999999;
        mRange = range;
        series->clear();
        foreach (UPDATE_DATA_T item, list) {
            series->append(item.time,item.LiZhi); 
        }


        if(series->count()>0){
            qreal t = series->points().last().x() - series->points().first().x();
            if(t/1000 > mTimeRangeSeconds){
                chart->axisX()->setMin(QDateTime::currentDateTime().addSecs(-(mTimeRangeSeconds-mTimeLeaveSeconds)));
                chart->axisX()->setMax(QDateTime::currentDateTime().addSecs(mTimeLeaveSeconds));
            }
        }else{
            chart->axisX()->setMin(QDateTime::currentDateTime());
            chart->axisX()->setMax(QDateTime::currentDateTime().addSecs(mTimeRangeSeconds));
        }

        onOutRange();

//        qDebug() << "min: "<< minv << " max:" << maxv;
//        if(maxv!=0 && minv!=0){
//            maxY = maxv;
//            minY = minv;
//           chart->axisY()->setMax(maxv);
//           chart->axisY()->setMin(minv);
//        }
//        qDebug() << "changed id: count " << series->count();
    }

    void onUpatedData(UPDATE_DATA_T item){
        series->append(item.time,item.LiZhi);
        qreal dx = chart->plotArea().width()/mTimeRangeSeconds;

        qreal t = series->points().last().x() - series->points().first().x();
        if(t/1000 > mTimeRangeSeconds-mTimeLeaveSeconds){
       // if(series->count()>mTimeRangeSeconds){
            float d = (float)(item.time - lastTime)/1000*dx;
          //  qDebug() << "scroll : " << d;
            chart->scroll(d,0);
        }

        if(series->count() > MAX_CURVE_POINT){
           series->removePoints(0,series->count()-MAX_CURVE_POINT);
        }

        onOutRange();

        lastTime = item.time;
    }
private:
    void onOutRange(){
        qreal maxv = 0;
        qreal minv = 99999999;
        foreach (QPointF item, series->points()) {
            maxv = std::max(maxv,item.y());
            minv = std::min(minv,item.y());
        }


        if(maxv> maxY || minv < minY){

           qDebug() << "min: "<< minv << " max:" << maxv;
           maxY = maxv+mRange/2;
           minY = minv-mRange/2;
           if(maxY > minY){
           chart->axisY()->setMax(maxY);
           chart->axisY()->setMin(minY);
           }
        }

    }

private:
    int mTimeRangeSeconds;
    int mTimeLeaveSeconds;
    qint64 lastTime;
    QWidget*mParent;
    Ui::MainWindow *mUI;
    QChart* chart;
    QChartView *chartView;
    QSplineSeries *series;
    QTimer* timer;

    qreal maxY;
    qreal minY;

    float mRange;

    int tickCount;
Q_SIGNALS:
    void onSaveClicked();
    void onClearClicked();
public:

    void timerAction(bool f){
        if(f)
          timer->start();
        else
            timer->stop();
    }
    QChartView* getChartView(){
        return chartView;
    }
};


struct FramelessWindowPrivate {
    FramelessWindowPrivate(QWidget *contentWidget) : contentWidget(contentWidget) {}

    QWidget *contentWidget;
    QPoint mousePressedPosition; // 鼠标按下时的坐标
    QPoint windowPositionAsDrag; // 鼠标按小时窗口左上角的坐标
};

//struct FramelessWindowPrivate;

class FramelessWindow : public QWidget {
    Q_OBJECT
public:
    explicit FramelessWindow(QWidget *contentWidget, QWidget *parent = 0){
        setWindowFlags(Qt::FramelessWindowHint);    // 去掉边框
            setAttribute(Qt::WA_TranslucentBackground); // 背景透明

        //    d = new FramelessWindowPrivate(contentWidget);
            // 添加阴影
              QGraphicsDropShadowEffect *shadowEffect = new QGraphicsDropShadowEffect(contentWidget);
              shadowEffect->setColor(Qt::lightGray);
              shadowEffect->setBlurRadius(64); // 阴影的大小
              shadowEffect->setOffset(0, 13);
              contentWidget->setGraphicsEffect(shadowEffect);

              // 添加到窗口中
              QGridLayout *lo = new QGridLayout();
              lo->addWidget(contentWidget, 0, 0);
              lo->setContentsMargins(4, 4, 4, 4); // 注意和阴影大小的协调
              setLayout(lo);
    }
    ~FramelessWindow(){
          //  delete d;
    }

protected:

private:
//    FramelessWindowPrivate *d;
};


class QtMaterialAppBar;
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void about();
//    void handleError(QSerialPort::SerialPortError error);

    void onChangedId(int  header_num,int id);
    void onCellChanged(int row,int col);
//    void onCellChanged2(int row,int col);
    void onUpdatedLiZhi(int id);
    void onUpdatedAD(int id);

    void onTestChangedIndex(int index);


private:
    void initMenus();
    void initActionsConnections();

    void initDashboard();
    void refreshSensorWidgets();
#ifdef USEQML
    void refreshSensorQMLItems();
#endif

    QtMaterialAppBar       * m_appBar;
    void initAppBar();
    void refreshButtonList();
    void initDualHeader();
    void initJianDingTableWidget();
    void initChart();
    void exportTableData(int id,bool jianDing);
    void fillJianDingTableData(int id);
    void readJianDingTableData(int id);
    void calculateJianDingTable(int id);
    void calculateDianShu(int row);
    void updateJianDingInfo(int id);
    void clearJianDingTable(int dianshu);

    void onTableWidgetStandby(int dianshu,QTableWidget *tw);
    void onStartBiaoDing(int id);

    void onJianDingAction(bool f);

protected:
    void doStart();
    void showEvent(QShowEvent *event);
private:
    FramelessWindowPrivate *d;
protected:
    void mousePressEvent(QMouseEvent *e) Q_DECL_OVERRIDE{
        d->mousePressedPosition = e->globalPos();
           d->windowPositionAsDrag = pos();
    }
    void mouseReleaseEvent(QMouseEvent *e) Q_DECL_OVERRIDE{
        Q_UNUSED(e)
            // 鼠标放开始设置鼠标按下的位置为 null，表示鼠标没有被按下
            d->mousePressedPosition = QPoint();
    }
    void mouseMoveEvent(QMouseEvent *e) Q_DECL_OVERRIDE{
        if (!d->mousePressedPosition.isNull()) {
                // 鼠标按下并且移动时，移动窗口, 相对于鼠标按下时的位置计算，是为了防止误差累积
                QPoint delta = e->globalPos() - d->mousePressedPosition;
                move(d->windowPositionAsDrag + delta);
            }
    }

private:

    void showStatusMessage(const QString &message);
    QMap<int,SensorWidget*> sensorWidgetMap;
    QMap<int,SensorWidget*> sensorWidgetHeaderMap;
    QMap<int,MyChartView*>  myChartViewMap;

    QList<QToolButton*> mButtonList;

    Ui::MainWindow *ui;
    DashboardDialog* dashboardDlg;
    BiaoDingDialog *biaoDingDlg;

    AddRecorder addRecorder;
//    AddRecorder addRecorderLeft;
    QLabel *status;
    Console *console;
    SettingsDialog *settings;
//    int selected_singel_id;


    int selected_1_id;
    int selected_2_id;
//    int jianding_id;
};

#endif // MAINWINDOW_H
