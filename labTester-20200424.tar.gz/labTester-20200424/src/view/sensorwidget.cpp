#include "sensorwidget.h"
#include "ui_sensorwidget.h"
#include "control/masterthread.h"
#include "testermodel.h"
#include <QGraphicsDropShadowEffect>
#include <QtCore/qmath.h>
#include <QPropertyAnimation>
#include <QPainter>
#include <QTimer>
#include <qtmaterialdialog.h>

SensorWidget::SensorWidget(QWidget *parent,int headerType) :
    QWidget(parent),
    ui(new Ui::SensorWidget)
{
    id = 1;
    ui->setupUi(this);

    this->headerType = headerType;
    ui->comboBox->setHidden(headerType==SONSOR_WIDGET_BOARD);
    ui->pushButton_yincang->setHidden(headerType!=SONSOR_WIDGET_BOARD);

    connect(ui->pushButton,&QPushButton::clicked,[=](){
        qDebug()<< "onclickedd" << this->getId();
        int i = getId()-1;
        TesterModel::getInstance()->clearValue(i);
        onQingLing();

        //onDataUpdated(this->getId());
    });

    connect(ui->comboBox_2,&QComboBox::currentTextChanged,[=](QString f){
        onDataUpdated(this->getId());
        ui->label_danwei2->setText( f);

        mCurrentDanWei = f;
        emit onChangedDanWei(f);
    });
    QObject::connect(ui->comboBox,SIGNAL(currentIndexChanged(int)),this,SLOT(onChangedIndex(int)));

    //    ui->comboBox->setEnabled(false);
    ui->pushButton->setEnabled(false);
    ui->comboBox_2->setEnabled(false);

    onReset();


    connect(ui->pushButton_yincang,&QPushButton::clicked,[=](){
        TesterModel::getInstance()->setSensorShow(this->id,false);
        emit onChangedShow(false);

    });

    connect(MasterThread::getInstance().get(),&MasterThread::addSensorEvent,[=](int id){
//        if(id == this->getId())
//            refreshCombobox();
    });
    connect(MasterThread::getInstance().get(),&MasterThread::saveInfoEvent,[=](int id){
        if(id == this->getId())
            refreshCombobox();
    });


    //    //设置窗体透明
    //        this->setAttribute(Qt::WA_TranslucentBackground, true);

    //    this->setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    //实例阴影shadow
    //            QGraphicsDropShadowEffect *shadow = new QGraphicsDropShadowEffect(this);
    //            //设置阴影距离
    //            shadow->setOffset(0, 3);
    //            //设置阴影颜色
    //            shadow->setColor(QColor("#444444"));
    //            //设置阴影圆角
    //            shadow->setBlurRadius(30);
    //            //给嵌套QWidget设置阴影
    //            this->setGraphicsEffect(shadow);
    //        //给垂直布局器设置边距(此步很重要, 设置宽度为阴影的宽度)
    //        ui->verticalLayout->setMargin(24);


    connect(MasterThread::getInstance().get(),SIGNAL(updatedEvent(int)),this, SLOT(onDataUpdated(int)));
    connect(MasterThread::getInstance().get(),SIGNAL(updatedADEvent(int)),this, SLOT(onDataUpdated(int)));

    QGraphicsDropShadowEffect *shadow = new QGraphicsDropShadowEffect(this);
    //设置阴影距离
    shadow->setOffset(0, 3);
    //设置阴影颜色
    shadow->setColor(QColor("#444444"));
    //设置阴影圆角
    shadow->setBlurRadius(30);


    this->setObjectName("contentWidget");
 //   this->setStyleSheet("#contentWidget{background: lightgray; border-radius: 24px;}" // 定制圆角 );


    //    ui->frame->setGraphicsEffect(NULL);

    //    ui->frame->setParent(this->parentWidget());
    //    this->setGraphicsEffect(shadow);
//    ui->widget_shadow->setGraphicsEffect(shadow);
//    ui->widget_shadow->setGeometry(this->geometry());

//    QGraphicsOpacityEffect * effect = new QGraphicsOpacityEffect();
//    effect->setOpacity(0.5);
//  //  this->setGraphicsEffect(effect);

//    ui->frame->raise();


    //    shadow->setFiltersChildEvents(false);

    //给嵌套QWidget设置阴影
    // ui->frame->setGraphicsEffect(shadow);


    //  onDataUpdated(id);

    //    QVBoxLayout *layout = new QVBoxLayout;
    //  //  this->setLayout(layout);

    //    stackLayout   = new QStackedLayout;
    //    setLayout(stackLayout);

    //    this->setGraphicsEffect(shadow);
    //    stackLayout->addWidget(widget);
    //    stackLayout->setAlignment(widget, Qt::AlignCenter);

    //    this->setAttribute(Qt::WA_TransparentForMouseEvents);
    //    stackLayout->addWidget(widget);

    //    proxyStack->setCurrentIndex(1);



    //    initAnimation();

    refreshCombobox();
}

SensorWidget::~SensorWidget()
{
    disconnect(MasterThread::getInstance().get(),0);
    delete ui;
}

void SensorWidget::setModelId(int headerType,int id)
{
    this->headerType = headerType;
    this->id = id;
    onDataUpdated(id);

    if(id>0 && id < MAX_SENSOR_COUNT)
        ui->comboBox->setCurrentIndex(id-1);


}

QString SensorWidget::getCurrentValue()
{
    //    return QString("%1").arg(ui->label_lizhi->value());
    return ui->label_lizhi->text();
}

void SensorWidget::doRefresh()
{
    onDataUpdated(this->id);
}

void SensorWidget::onChangedIndex(int index)
{

#ifdef CHANNEL6
    this->id = ui->comboBox->currentIndex()+1;

    if(this->headerType == HEAD_SONSOR_WIDGET_RIGHT)
        this->id = ui->comboBox->currentIndex()+1+3;

    onChangedId2DanWei(this->id);
    onDataUpdated(this->id);
    emit onChangedId(this->headerType,this->id);
    qDebug()<< "changed id: "<< this->id;
#else
    this->id = ui->comboBox->currentIndex()+1;
    onChangedId2DanWei(this->id);
    onDataUpdated(this->id);
    emit onChangedId(this->headerType,this->id);
    qDebug()<< "changed id: "<< this->id;
#endif


}


void SensorWidget::onDataUpdated(int id)
{
    if(this->getId() == id)
    {
        SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);
        if(!model|| !model->enabled){
            // qDebug()<<"error: id data not found" << id << __FUNCTION__;
            ui->widget_baner->setStyleSheet("background-color:#606060");
            ui->label_lizhi->setStyleSheet("color:#606060");
            ui->label_fengzhi->setStyleSheet("color:#606060");

            onReset();
            return ;
        }



//        model->Operator.DanWei = ui->comboBox_2->currentText();

//        ui->comboBox_2->setEnabled(model->DanWei!="N.m" && model->enabled);

        ui->pushButton_yincang->setVisible(model->show&&this->headerType==SONSOR_WIDGET_BOARD);

        //        ui->comboBox->setEnabled(model->enabled);
       // ui->comboBox_2->setEnabled(model->enabled);
        ui->pushButton->setEnabled(model->enabled);

        ui->label_xinghao->setText( model->XingHao);
        ui->label_bianhao->setText( model->BianHao);
        ui->label_fanwei->setText( QString("%1%2").arg(model->CeLiangFanWei).arg(model->DanWei));


        ui->label_12->setVisible(TesterModel::getInstance()->getMode());
        ui->comboBox_2->setVisible(TesterModel::getInstance()->getMode());
        ui->label_fengzhi->setVisible(TesterModel::getInstance()->getMode());


        QPalette palette = ui->widget_baner->palette();

        if(!model->enabled){
            //    palette.setColor(QPalette::Window, Qt::lightGray);  //改变控件背景色
            ui->widget_baner->setStyleSheet("background-color:#606060");
            ui->label_lizhi->setStyleSheet("color:#606060");
            ui->label_fengzhi->setStyleSheet("color:#606060");
            // qDebug()<<" set gray color ." << id << __FUNCTION__;

        }else{
            //   palette.setColor(QPalette::Window, Qt::blue);  //改变控件背景色
            // qDebug()<<" set blue value color" << id << __FUNCTION__;
            ui->widget_baner->setStyleSheet("background-color: #4c46ff; color: rgb(255, 255, 255);");
            //            ui->widget_baner->setStyleSheet("background-color: rgb(0, 85, 255); color: rgb(255, 255, 255);");
            ui->label_lizhi->setStyleSheet("color:#0000ff");
            ui->label_fengzhi->setStyleSheet("color:#ff0000");
        }

        // 显示灵敏度
        if(!TesterModel::getInstance()->getMode()){
            QString strLiZhi = QString("%1").arg(model->AD,0,'r',5);
//            if(strLiZhi!=ui->label_lizhi->text()){
//                QFont font = ui->label_lizhi->font();
//                int fontSize = font.pointSize();
//                font.setPointSize(fontSize+1);
//                ui->label_lizhi->setFont(font);
//                QTimer::singleShot(300,[=,fontSize](){
//                    QFont font = ui->label_lizhi->font();
//                    font.setPointSize(fontSize);
//                    ui->label_lizhi->setFont(font);
//                });
//            }
            ui->label_lizhi->setText(strLiZhi);
            ui->label_fengzhi->setText(QString("%1").arg(model->FengZhi));
            ui->label_danwei2->setText("mV/V");

        }else{
            // 显示力值
            if(model->DanWei == "N.m"){
                ui->label_lizhi->setText(QString("%1").arg(model->LiZhi,0,'r',model->XiaoShu));
                ui->label_fengzhi->setText(QString("%1").arg(model->FengZhi,0,'r',model->XiaoShu));
                model->CurrentValue = model->LiZhi;
                ui->label_danwei2->setText("N.m");
                ui->comboBox_2->setCurrentText("N.m");
            }
            else
            {
                    QString real_lizhi = danWeiZhi(model->LiZhi,id);
                    QString real_fengzhi = danWeiZhi(model->FengZhi,id);

//                    if(real_lizhi!=ui->label_lizhi->text())
//                    {
//                        QFont font = ui->label_lizhi->font();
//                        int fontSize = font.pointSize();
//                        font.setPointSize(fontSize+1);
//                        ui->label_lizhi->setFont(font);
//                        QTimer::singleShot(500,[=,fontSize](){
//                            QFont font = ui->label_lizhi->font();
//                            font.setPointSize(fontSize);
//                            ui->label_lizhi->setFont(font);
//                        });
//                    }

                    ui->label_lizhi->setText(real_lizhi);


                    model->CurrentValue = real_lizhi.toFloat();
                    ui->label_fengzhi->setText(real_fengzhi);

                    ui->label_danwei2->setText(ui->comboBox_2->currentText());
            }
        }
    }
}

void SensorWidget::refreshCombobox()
{

#ifdef CHANNEL6
    //disconnect(ui->comboBox,0);

    ui->comboBox->blockSignals(true);
    ui->comboBox->clear();
    for(int i=0;i< MAX_SENSOR_COUNT;i++){
        //左边显示1~3 ,右边 显示456
        if(this->headerType == HEAD_SONSOR_WIDGET_LEFT && i>2)
            break;
        else if(this->headerType == HEAD_SONSOR_WIDGET_RIGHT && i<3)
            continue;
        int id = i+1;
        SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);
        if(!model){
            //  ui->comboBox->addItem(QString("%1路(%2)").arg(i+1).arg("空"),i+1);
        }else{
            if(ui->comboBox->count() < id)
               ui->comboBox->addItem(QString("%1路(%2)").arg(model->id).arg(model->BianHao),model->id);
            else
               ui->comboBox->setItemText(i,QString("%1路(%2)").arg(model->id).arg(model->BianHao));
        }
    }
    if(ui->comboBox->count()>0){
        onDataUpdated(this->id);

    }
    if(this->headerType == HEAD_SONSOR_WIDGET_LEFT )
        ui->comboBox->setCurrentIndex(this->id-1);
   else if(this->headerType == HEAD_SONSOR_WIDGET_RIGHT)
        ui->comboBox->setCurrentIndex(this->id-1-3);
//    QObject::connect(ui->comboBox,SIGNAL(currentIndexChanged(int)),this,SLOT(onChangedIndex(int)));
    ui->comboBox->blockSignals(false);
#else

//    disconnect(ui->comboBox,0);
    ui->comboBox->blockSignals(true);
     ui->comboBox->clear();
    for(int i=0;i< MAX_SENSOR_COUNT;i++){
        int id = i +1;
        SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);
        if(!model){
            //  ui->comboBox->addItem(QString("%1路(%2)").arg(i+1).arg("空"),i+1);
        }else{
            if(ui->comboBox->count() < id)
               ui->comboBox->addItem(QString("%1路(%2)").arg(model->id).arg(model->BianHao),model->id);
            else
               ui->comboBox->setItemText(i,QString("%1路(%2)").arg(model->id).arg(model->BianHao));
        }
    }
    if(ui->comboBox->count()>0){
        onDataUpdated(this->id);

    }

    ui->comboBox->setCurrentIndex(this->id-1);
    ui->comboBox->blockSignals(false);
//    QObject::connect(ui->comboBox,SIGNAL(currentIndexChanged(int)),this,SLOT(onChangedIndex(int)));
#endif
}


/*
void SensorWidget::initAnimation()
{
    QGraphicsDropShadowEffect *shadow = new QGraphicsDropShadowEffect(this);
    //设置阴影距离
    shadow->setOffset(0, 3);
    //设置阴影颜色
    shadow->setColor(QColor("#444444"));
    //设置阴影圆角
    shadow->setBlurRadius(30);
    //给嵌套QWidget设置阴影
    this->setGraphicsEffect(shadow);

    QState *hiddenState = new QState;
    QState *visibleState = new QState;


    stateMachine = new QStateMachine(this);

    stateMachine->addState(hiddenState);
    stateMachine->addState(visibleState);
    stateMachine->setInitialState(hiddenState);

    QtMaterialStateTransition *transition;

    transition = new QtMaterialStateTransition(DialogShowTransition);
    transition->setTargetState(visibleState);
    hiddenState->addTransition(transition);

    transition = new QtMaterialStateTransition(DialogHideTransition);
    transition->setTargetState(hiddenState);
    visibleState->addTransition(transition);

    visibleState->assignProperty(this, "opacity", 1);
 //   visibleState->assignProperty(shadow, "color", QColor(0, 0, 0, 200));
 //   visibleState->assignProperty(this, "offset", 0);
    hiddenState->assignProperty(this, "opacity", 0);
  //  hiddenState->assignProperty(shadow, "color", QColor(0, 0, 0, 0));
 //   hiddenState->assignProperty(this, "offset", 200);

    QPropertyAnimation *animation;

    animation = new QPropertyAnimation(this, "opacity", this);
    animation->setDuration(280);
    stateMachine->addDefaultAnimation(animation);

    animation = new QPropertyAnimation(shadow, "color", this);
    animation->setDuration(280);
 //   stateMachine->addDefaultAnimation(animation);

    animation = new QPropertyAnimation(this, "offset", this);
    animation->setDuration(280);
    animation->setEasingCurve(QEasingCurve::OutCirc);
 //   stateMachine->addDefaultAnimation(animation);

    QObject::connect(visibleState,  &QState::propertiesAssigned,
            [=](){
        m_opacity = 1.0;
        m_mode = Opaque;
        update();

    });
    QObject::connect(hiddenState, &QState::propertiesAssigned,
                     [=](){
        m_opacity = 0.0;
        m_mode = Transparent;
        update();
    });

    stateMachine->start();
    QCoreApplication::processEvents();
}
*/
QString SensorWidget::danWeiZhi(LIZHI_TYPE lizhi,int id)
{
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);

    if(!model){
        qDebug()<<"error: id data not found" << id << __FUNCTION__;
        return "---";
    }

    QString text ="---";
    //    LIZHI_TYPE lizhi = TesterModel::getInstance()->getSensorDataById(id-1)->LiZhi;
    short xiaoshu = model->XiaoShu;
    QString danwei = model->DanWei;
    float g = model->ZhongLiJiaShuDu;

//    float real_lizhi = lizhi/qPow(10,xiaoshu);
    float real_lizhi = lizhi;
    ui->label_fengzhi->setText(QString("%1").arg(TesterModel::getInstance()->getSensorDataById(id)->FengZhi));

    QString selectDanWei = ui->comboBox_2->currentText();
    if(model->DanWei=="kgf"){
        if(selectDanWei=="N"){
            real_lizhi = real_lizhi/g;
        }
        else if(selectDanWei=="kN"){
            real_lizhi = real_lizhi/g/1000;

        }
        else if(selectDanWei=="MN"){
            real_lizhi = real_lizhi/g/1000/1000;
        }
        else if(selectDanWei=="tf"){
            real_lizhi = real_lizhi/1000;
        }

        text = QString("%1").arg(real_lizhi,0,'r',6);

    }else if(model->DanWei=="N"){
        if(selectDanWei=="N"){
            text = QString("%1").arg(real_lizhi,0,'r',xiaoshu);
        }
        else if(selectDanWei=="kN"){

            real_lizhi = real_lizhi/1000;
            text = QString("%1").arg(real_lizhi,0,'r',7);
        }
        else if(selectDanWei=="MN"){
            real_lizhi = real_lizhi/1000/1000.0;
            text = QString("%1").arg(real_lizhi,0,'r',8);
        }
        else if(selectDanWei=="tf"){
            real_lizhi = real_lizhi/g/1000;
            text = QString("%1").arg(real_lizhi,0,'r',8);
        }
        else if(selectDanWei=="kgf"){
            real_lizhi = real_lizhi/g;
            text = QString("%1").arg(real_lizhi,0,'r',5);
        }else{
            // ui->radioButton_n->setChecked(true);
        }


        //1kgf = 1*G N
    }else if(model->DanWei=="kN"){
        if(selectDanWei=="N"){
            real_lizhi = real_lizhi*1000;
            text = QString("%1").arg(real_lizhi,0,'r',0);
        }
        else if(selectDanWei=="kN"){

            //               real_lizhi = real_lizhi/1000;
            text = QString("%1").arg(real_lizhi,0,'r',xiaoshu);

        }
        else if(selectDanWei=="MN"){
            real_lizhi = real_lizhi/1000;
            text = QString("%1").arg(real_lizhi,0,'r',2);
        }
        else if(selectDanWei=="tf"){
            real_lizhi = real_lizhi/g/1000/1000;
            text = QString("%1").arg(real_lizhi,0,'r',6);
        }
        else if(selectDanWei=="kgf"){
            real_lizhi = real_lizhi/1000/g;
            text = QString("%1").arg(real_lizhi,0,'r',6);

        }else{
            //ui->radioButton_kn->setChecked(true);
        }

        //text = QString("%1").arg(real_lizhi,0,'r',xiaoshu);

    }else if(model->DanWei=="MN"){
        if(selectDanWei=="N"){
            real_lizhi = real_lizhi*1000*1000;
            text = QString("%1").arg(real_lizhi,0,'r',6);
        }
        else if(selectDanWei=="kN"){

            real_lizhi = real_lizhi*1000;
            text = QString("%1").arg(real_lizhi,0,'r',6);

        }
        else if(selectDanWei=="MN"){
            //real_lizhi = real_lizhi/1000;
            text = QString("%1").arg(real_lizhi,0,'r',xiaoshu);
        }
        else if(selectDanWei=="tf"){
            real_lizhi = real_lizhi*1000/g;
        }
        else if(selectDanWei=="kgf"){
            real_lizhi = real_lizhi*1000*1000/g;
            text = QString("%1").arg(real_lizhi,0,'r',6);
        }else{
            // ui->radioButton_mn->setChecked(true);
            text = QString("%1").arg(real_lizhi,0,'r',6);
        }
    }
    else if(model->DanWei=="tf"){
        if(selectDanWei=="N"){
            real_lizhi = real_lizhi*1000/g;
        }
        else if(selectDanWei=="kN"){

            real_lizhi = real_lizhi/g;

        }
        else if(selectDanWei=="MN"){
            real_lizhi = real_lizhi*1000/g;
        }
        else if(selectDanWei=="tf"){
            //                real_lizhi = real_lizhi*g;
        }
        else if(selectDanWei=="kgf"){
            real_lizhi = real_lizhi*1000;
        }else{
            //ui->radioButton_tf->setChecked(true);
        }
        text = QString("%1").arg(real_lizhi,0,'r',6);
    }else{
        qDebug() << "unknown danwei :" << model->DanWei;
    }


    return   text;


}

void SensorWidget::onChangedId2DanWei(int id)
{
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);

    if(!model){
        qDebug()<<"error: id data not found" << id << __FUNCTION__;
        return;
    }

    model->Operator.DanWei = ui->comboBox_2->currentText();
    ui->comboBox_2->setCurrentText(model->DanWei);
    ui->comboBox_2->setEnabled(model->DanWei!="N.m" && model->enabled);



}

void SensorWidget::onQingLing()
{
    //    ui->label_lizhi->display("--");
    ui->label_lizhi->setText("--");
    ui->label_fengzhi->setText("--");

    MasterThread::getInstance()->cmdQingLing(this->id);
}

void SensorWidget::onReset()
{
    ui->label_lizhi->setText("--");
    //    ui->label_lizhi->display("--");
    ui->label_fengzhi->setText("--");
    ui->label_bianhao->setText("--");
    ui->label_xinghao->setText("--");
    ui->label_fanwei->setText("--");


}

void SensorWidget::showEvent(QShowEvent *event)
{
    // if(stateMachine)
    // stateMachine->postEvent(new QtMaterialStateTransitionEvent(DialogShowTransition));
}

void SensorWidget::paintEvent(QPaintEvent *event)
{

    QPainterPath path;
    path.setFillRule(Qt::WindingFill);
    path.addRect(10, 10, this->width() - 20, this->height() - 20);

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);
    painter.fillPath(path, QBrush(Qt::white));

//    QColor color(0, 0, 0, 50);
    QColor color("#444444");
    for (int i = 0; i < 10; i++)
    {
        QPainterPath path;
        path.setFillRule(Qt::WindingFill);
        path.addRect(10 - i, 10 - i, this->width() - (10 - i) * 2, this->height() - (10 - i) * 2);
        color.setAlpha(150 - qSqrt(i) * 50);
        painter.setPen(color);
        painter.drawPath(path);
    }

}

