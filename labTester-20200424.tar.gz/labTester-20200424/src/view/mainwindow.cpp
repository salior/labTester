/****************************************************************************
**
** Copyright (C) 2012 Denis Shienkov <denis.shienkov@gmail.com>
** Copyright (C) 2012 Laszlo Papp <lpapp@kde.org>
** Contact: https://www.qt.io/licensing/
**
** This file is part of the QtSerialPort module of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include "mainwindow.h"

#include "console.h"
#include "settingsdialog.h"

#include <QMessageBox>
#include <QLabel>
#include <QtSerialPort/QSerialPort>
#include "masterthread.h"
#include "xlsl.h"
#include "sensorwidget.h"
#include "testcontrol.h"
#include "testermodel.h"
#include "logger.h"
#include <QTextCodec>
#include <QtSerialPort/QSerialPortInfo>
#include <QIntValidator>
#include <QDesktopWidget>
#include <QToolButton>
#include <QSpacerItem>
#include <QtWidgets/QGraphicsDropShadowEffect>


#include <qtmaterialappbar.h>
#include <qtmaterialiconbutton.h>
#include <qtmaterialflatbutton.h>
#include <lib/qtmaterialtheme.h>
#include <qtmaterialfab.h>
#include <qtmaterialavatar.h>

//! [0]
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)

{
    sensorWidgetHeaderMap.clear();
    Logger::getInstance()->history();
    qInfo()  << "APPLICATION START. 开始";
    ui->setupUi(this);

    status = new QLabel;
    ui->statusBar->addWidget(status);
    //  selected_1_id = 1;
#ifdef CHANNEL6
    selected_1_id = 1;
    selected_2_id = 4;
#else
    selected_1_id = 1;
    selected_2_id = 2;
#endif

    dashboardDlg = NULL;
    biaoDingDlg = NULL;

    // TestControl::getInstance()->start();


    initMenus();
    initDashboard();

    initDualHeader();

    initJianDingTableWidget();
    initChart();
    initActionsConnections();

    refreshSensorWidgets();

    connect(MasterThread::getInstance().get(),SIGNAL(updatedEvent(int)),this,SLOT(onUpdatedLiZhi(int)));
    connect(MasterThread::getInstance().get(),SIGNAL(updatedADEvent(int)),this,SLOT(onUpdatedAD(int)));




    QDesktopWidget* desktop = QApplication::desktop(); // =qApp->desktop();也可以
    move((desktop->width() - this->width())/2, (desktop->height() - this->height())/2);



    QGraphicsDropShadowEffect *shadow = new QGraphicsDropShadowEffect(this);
    //设置阴影距离
    shadow->setOffset(0, 0);
    //设置阴影颜色
    shadow->setColor(QColor("#fefefe"));
    //设置阴影圆角
    shadow->setBlurRadius(30);
    //给嵌套QWidget设置阴影
    ui->widget_toolbar->setGraphicsEffect(shadow);

    ui->mainToolBar->setGraphicsEffect(shadow);

    d = new FramelessWindowPrivate(this);
    ui->menuBar->setVisible(false);

    initAppBar();
    doStart();


}

MainWindow::~MainWindow()
{
    // delete settings;
    delete ui;
}
void MainWindow::about()
{
    QString d = __DATE__;
    QString t = __TIME__;
    QMessageBox::information(this,"About",QString("build %1, %2").arg(d).arg(t));

}
//选择id变化后的动作
void MainWindow::onChangedId(int headerType, int id)
{
    if(headerType == HEAD_SONSOR_WIDGET_LEFT){
        selected_1_id = id;
        updateJianDingInfo(id);
        SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);
        if(!model){
            qDebug()<<"error: id data not found" <<  id << __FUNCTION__;
            return;
        }
        if(myChartViewMap[HEAD_SONSOR_WIDGET_LEFT])
            myChartViewMap[HEAD_SONSOR_WIDGET_LEFT]->changedId(model->CurveList,model->CeLiangFanWei/std::pow(10,model->XiaoShu));
    }else if(headerType == HEAD_SONSOR_WIDGET_RIGHT){
        selected_2_id = id;
        qDebug()<<"header 2 id " <<  id;
        SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);
        if(!model){
            qDebug()<<"error: id data not found";
            return;
        }
        if(myChartViewMap[HEAD_SONSOR_WIDGET_RIGHT])
            myChartViewMap[HEAD_SONSOR_WIDGET_RIGHT]->changedId(model->CurveList,model->CeLiangFanWei/std::pow(10,model->XiaoShu));
    }
}
//表格数据有变化后再数据处理
void MainWindow::onCellChanged(int row, int col)
{
    if(row>1 && row < 13 && col < 8){
        //        calculateDianShu(row);
        calculateJianDingTable(selected_1_id);
    }else{
        qDebug() << "out of table edited.";
    }
}

//void MainWindow::onCellChanged2(int row, int col)
//{
//    if(row>1 && col>0 && row < 13 && col < 7){
//        calculateBiaoDingTable(selected_1_id);
//    }else{
//        qDebug() << "out of table edited.";
//    }
//}
//检定更新过来的数据
void MainWindow::onUpdatedLiZhi(int id)
{
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);
    if(!model){
        qDebug()<<"error: id data not found " << id;
        return;
    }

    if(id==selected_1_id){
        if(myChartViewMap[HEAD_SONSOR_WIDGET_LEFT])
            myChartViewMap[HEAD_SONSOR_WIDGET_LEFT]->onUpatedData(model->CurveList.back());
    }else if(id == selected_2_id){
        if(myChartViewMap[HEAD_SONSOR_WIDGET_RIGHT])
            myChartViewMap[HEAD_SONSOR_WIDGET_RIGHT]->onUpatedData(model->CurveList.back());
    }
}
//标定过来的AD值
void MainWindow::onUpdatedAD(int id)
{

}

void MainWindow::initMenus()
{
    QString description;
    QString manufacturer;
    QString serialNumber;
    const auto infos = QSerialPortInfo::availablePorts();
    for (const QSerialPortInfo &info : infos) {
        QStringList list;
        description = info.description();
        manufacturer = info.manufacturer();
        serialNumber = info.serialNumber();

        QString portName = info.portName();

        QAction *action;

        action = new QAction(info.portName(), this);
        connect(action, &QAction::triggered, [this,portName](){
            if(MasterThread::getInstance()->openSerial(portName)){
                MasterThread::getInstance()->init();
            }else{
                QMessageBox::information(this,"串口","打开串口失败!,请选择串口再次打开");
            }
        });
        ui->menuCalls->insertAction(ui->actionQuit,action);

        qInfo()<<"com :" << portName;

    }

    //   QAction* action = new QAction("d000", this);

    //    action->setCheckable(true);

    //    ui->menuCalls->insertAction(ui->actionQuit,action);


}

void MainWindow::onTestChangedIndex(int index)
{

    switch (index) {
    case 0:
        MasterThread::getInstance()->cmdStop();
        break;
    case 1:
        MasterThread::getInstance()->cmdGetInfomation();
        break;
    case 2:
        MasterThread::getInstance()->cmdDeleteSensor(1);
        break;
    case 3:
        MasterThread::getInstance()->cmdSelectSensorById(1);
        break;
    case 4:
        MasterThread::getInstance()->cmdSaveXiShu(1,"100000+0.01+200000+0.01+300000+0.01+400000+0.01+500000+0.01+600000+0.01+700000+0.01+800000+0.01");
        break;
    case 5:
        //        MasterThread::getInstance()->cmdSaveInfomation(1,"1+10kn+007+9.8+1000+N+2+20181024+GUANZHOU+0.5+007+21181024");
    {
        QString a = " 10kn+007+9.8+1000+N+2+2018年10月24日+广州数控+0.5级+007+2118年10月24日 ";
        MasterThread::getInstance()->cmdSaveInfomation(1,a);
    }       break;
    case 6:
        MasterThread::getInstance()->cmdBiaoDing();
        break;
    case 7:
        MasterThread::getInstance()->cmdJianDing();
        break;
    case 8:
        MasterThread::getInstance()->cmdQingLing();
        break;
    case 9:
        MasterThread::getInstance()->cmdGengGaiLingMinDu(0.000001);
        break;
    case 10:
        MasterThread::getInstance()->cmdGengGaiLanYa("lanymingddddd");
        break;
    case 11:
        MasterThread::getInstance()->cmdGetInfomation();
        break;
    default:
        break;
    }
}
static float getCellValue(QTableWidgetItem *item){
    if(item==NULL) return 0;
    float r =  item->text().length()==0?0:item->text().toFloat();
    return r;
}
static float getCellValue(QString text){
    float r =  text.length()==0?0:text.toFloat();
    return r;
}

static int addValid(QString text){
    int count = text.length()==0?0:1;
    return count;
}
void MainWindow::calculateJianDingTable(int id)
{
    try{
        readJianDingTableData(id);

        fillJianDingTableData(id);
    }catch(const std::exception& e) {
        std::cerr << " failed: " << e.what() << '\n';

    }
}
//计算输入时候的行数
void MainWindow::calculateDianShu(int row)
{
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(selected_1_id);
    if(!model){
        qDebug()<<"error: id data not found";
        return;
    }

    model->Operator.DianShu = std::max(model->Operator.DianShu,row-2);
    model->Operator.DianShu = std::max(model->Operator.DianShu,10);

}
void MainWindow::initActionsConnections()
{

    connect(ui->actionBoard, &QAction::triggered, [=](){

        //        if(dashboardDlg==NULL)
        //            dashboardDlg = new DashboardDialog(this);
        //        dashboardDlg->show();
        ui->tabWidget_main->setCurrentIndex(0);
    });

    connect(ui->actionJianDing, &QAction::triggered, [=](){
        ui->tabWidget_main->setCurrentIndex(1);
        ui->tabWidget_changgui->setCurrentIndex(0);
    });

    connect(ui->actionCurve, &QAction::triggered, [=](){
        ui->tabWidget_main->setCurrentIndex(1);
        ui->tabWidget_changgui->setCurrentIndex(1);

    });
    connect(ui->actionBiaoDing, &QAction::triggered, [=](){
        if(biaoDingDlg==NULL){
            biaoDingDlg = new BiaoDingDialog(this);
        }
        biaoDingDlg->setFocus();
        biaoDingDlg->show();
    });
    connect(ui->actionQuit, &QAction::triggered, [=](){
        QMessageBox msgBox;
        msgBox.setText(QString("您确定要退出吗？"));
        msgBox.setStandardButtons( QMessageBox::Yes | QMessageBox::Cancel);
        msgBox.setDefaultButton(QMessageBox::Yes);
        int ret = msgBox.exec();
        if(ret == QMessageBox::Yes){
            QApplication::quit();
        }
    });
    connect(ui->actionDebug, &QAction::triggered, [=](){
        bool f = Logger::getInstance()->switchTurn();

        QMessageBox msgBox;
        msgBox.setText(f?QString("调试信息已开启"):QString("调试信息已关闭"));
        msgBox.setStandardButtons( QMessageBox::Ok);
        msgBox.exec();

    });
    connect(ui->actionAbout, &QAction::triggered, this, &MainWindow::about);
    connect(ui->actionAboutQt, &QAction::triggered, qApp, &QApplication::aboutQt);


    QActionGroup* d = new QActionGroup(this);
    d->addAction(ui->actionBoard);
    d->addAction(ui->actionCurve);
    d->addAction(ui->actionJianDing);
    d->addAction(ui->actionBiaoDing);
    d->addAction(ui->actionDebug);
    d->setExclusive(true);

#ifdef CHANNEL6
    ui->mainToolBar->removeAction(ui->actionBoard);
#endif

}
//初始化看板列表
void MainWindow::initDashboard()
{

    ui->tabWidget_main->setCurrentIndex(1);


    // 去掉点数,默认10点
    ui->radioButton_5dian->setVisible(false);
    ui->radioButton_8dian->setVisible(false);
    ui->radioButton_10dian->setVisible(false);
    ui->radioButton_qita->setVisible(false);
    ui->lineEdit_qitadian->setVisible(false);
    ui->label_14->setVisible(false);
    ui->actionJianDing->activate(QAction::Trigger);

    refreshButtonList();
    refreshSensorWidgets();

    connect(MasterThread::getInstance().get(),&MasterThread::addSensorEvent,[=](int id){
        QTimer::singleShot(2000,[=,id](){
            qDebug()<<"on fresh dashboard.";
            refreshButtonList();
            refreshSensorWidgets();
            sensorWidgetHeaderMap[HEAD_SONSOR_WIDGET_LEFT]->refreshCombobox();
            sensorWidgetHeaderMap[HEAD_SONSOR_WIDGET_RIGHT]->refreshCombobox();

        });

        if(id==selected_1_id){
            updateJianDingInfo(id);
        }
    });

}

void MainWindow::refreshSensorWidgets()
{

#ifdef USEQML
    refreshSensorQMLItems();
#else


    int colSpacing = 2;
    int rowSpacing = 2;
    int col = 3;
    int row = 3;
    int viewHeight=1,viewWidth=1;




    qDebug()<<"refreshSensorWidgets " ;
    QList<QGridLayout*> btns = ui->widget_dashboard->findChildren<QGridLayout*>();
    foreach (QGridLayout* btn, btns) {   delete btn;  }

    QGridLayout * gridLayout = new QGridLayout(ui->widget_dashboard);



    int count =0;
    for(int i=0;i<MAX_SENSOR_COUNT;i++){

        if(sensorWidgetMap[i]){
            delete sensorWidgetMap[i];
            sensorWidgetMap[i]=NULL;
        }

        SENSOR_DATA_T* model = TesterModel::getInstance()->getSensorDataByIndex(i);
        if(!model || !model->show)
        {
            // gridLayout->addWidget(new QWidget(ui->widget_dashboard),(i/col),(i)%col);
            continue;
        }


        sensorWidgetMap[count] = new SensorWidget(ui->widget_dashboard);
//        sensorWidgetMap[count]->setSizePolicy(QSizePolicy::Preferred,QSizePolicy::Preferred);
        sensorWidgetMap[count]->setModelId(SONSOR_WIDGET_BOARD,model->id);
        sensorWidgetMap[count]->doRefresh();
        sensorWidgetMap[count]->setMaximumSize(428,199);

        gridLayout->addWidget(sensorWidgetMap[count],(count/col),count%col);

        connect(sensorWidgetMap[count],&SensorWidget::onChangedShow,[=](bool f){
            refreshButtonList();
            refreshSensorWidgets();
        });
        count++;
    }

    for(int i=count;i<MAX_SENSOR_COUNT;i++){
        gridLayout->addWidget(new QWidget(ui->widget_dashboard),i/col,i%col);
    }



#endif

}




void MainWindow::initAppBar()
{
    //    m_appBar = new QtMaterialAppBar;
    m_appBar = new QtMaterialAppBar();
    QLabel *label = new QLabel("力值专业测量系统v1.0");
    label->setAttribute(Qt::WA_TranslucentBackground);
    label->setForegroundRole(QPalette::Foreground);
    label->setContentsMargins(6, 0, 0, 0);

    QPalette palette = label->palette();
    palette.setColor(label->foregroundRole(), Qt::white);
    label->setPalette(palette);

    label->setFont(QFont("Roboto", 18, QFont::Normal));

    //    QtMaterialIconButton *button = new QtMaterialIconButton(QtMaterialTheme::icon("navigation", "close"));
    //    button->setIconSize(QSize(24, 24));

    QtMaterialFlatButton *button = new QtMaterialFlatButton("关闭");
    button->setIcon(QtMaterialTheme::icon("navigation","close"));
    button->setRole(Material::Primary);
    //  button->setIconSize(QSize(24, 24));
    button->applyPreset(Material::FlatPreset);
    button->setBackgroundMode(Qt::OpaqueMode);
    button->setBackgroundColor(Qt::blue);
    button->setFixedWidth(80);

    QtMaterialAvatar  *avatar = new QtMaterialAvatar(QChar('X'));
    avatar->setIcon(QtMaterialTheme::icon("hardware", "developer_board"));

    QtMaterialIconButton *menuButton = new QtMaterialIconButton(QtMaterialTheme::icon("navigation", "menu"));
    menuButton->setIconSize(QSize(24, 24));
    menuButton->setColor(Qt::white);
    menuButton->setFixedWidth(42);


    m_appBar->appBarLayout()->addWidget(avatar);
    m_appBar->appBarLayout()->addWidget(menuButton);
    m_appBar->appBarLayout()->addWidget(label);
    m_appBar->appBarLayout()->addStretch(1);
    //    m_appBar->appBarLayout()->addWidget(button,Qt::AlignRight);


    QtMaterialFloatingActionButton       *fab = new QtMaterialFloatingActionButton(QtMaterialTheme::icon("navigation", "close"));

    fab->setRole(Material::Secondary);
    fab->setRippleStyle(Material::CenteredRipple);
    fab->setCorner(Qt::TopRightCorner);
    fab->setOffset(5,5);
    fab->setParent(this);
    fab->setMini(true);
    //   m_appBar->appBarLayout()->addWidget(fab,Qt::AlignRight);

    m_appBar->setFixedHeight(60);
    ui->widget_appbar->setFixedHeight(60);

    m_appBar->appBarLayout()->setAlignment(button,Qt::AlignRight);

    //    button->setColor(Qt::white);
    //  button->setFixedWidth(42);

    QVBoxLayout * layout = new QVBoxLayout;
    layout->addWidget(m_appBar);
    layout->addStretch(1);
    layout->setMargin(0);
    ui->widget_appbar->setLayout(layout);

    connect(fab, &QPushButton::clicked, [=](){

        QMessageBox msgBox;
        msgBox.setText(QString("您确定要退出吗？"));
        msgBox.setStandardButtons( QMessageBox::Yes | QMessageBox::Cancel);
        msgBox.setDefaultButton(QMessageBox::Yes);
        int ret = msgBox.exec();
        if(ret == QMessageBox::Yes){
            qInfo()  << "APPLICATION EXIT.";
            QApplication::quit();

        }
    });


    connect(menuButton, &QPushButton::clicked, [=](){
        if(ui->menuBar->isVisible())
            ui->menuBar->setVisible(false);
        else
            ui->menuBar->setVisible(true);

    });

    ui->mainToolBar->setParent(ui->widget_leftpanel);

    m_appBar->setBackgroundColor(QColor::fromRgb(0x4c,0x46,0xff));


    palette = ui->centralWidget->palette();
    palette.setColor(ui->centralWidget->backgroundRole(), QColor::fromRgb(0x4c,0x46,0xff));

    ui->centralWidget->setPalette(palette);
}

#ifdef USEQML
#include <QtQuickWidgets/QQuickWidget>
void MainWindow::refreshSensorQMLItems()
{
    QList<QQuickWidget*> btns = ui->widget_dashboard->findChildren<QQuickWidget*>();
    foreach (QQuickWidget* btn, btns) {   delete btn;  }

    QQuickWidget *w = new QQuickWidget(ui->widget_dashboard);
    w->setResizeMode(QQuickWidget::SizeRootObjectToView);
    w->setSource(QUrl("qrc:/qml/ContentView/MainBoard/SensorListView.qml"));

}

#endif

void MainWindow::refreshButtonList()
{
    int buttonHeight = 56;
    int buttonWidth = 80;

    QList<QHBoxLayout*> btns = ui->widget_toolbar->findChildren<QHBoxLayout*>();
    foreach (QHBoxLayout* btn, btns) {   delete btn;  }

    foreach (QToolButton* btn, mButtonList) {  delete btn;  }
    mButtonList.clear();

    QHBoxLayout * layout = new QHBoxLayout(ui->widget_toolbar);
    for(int i=0;i<MAX_SENSOR_COUNT;i++){
        SENSOR_DATA_T* model = TesterModel::getInstance()->getSensorDataByIndex(i);
        QToolButton *  button = new QToolButton(ui->widget_toolbar);
        // button->setDefaultAction(ui->action232);


        //button->setStyleSheet("QToolButton{  \
        min-width:80px;  \
        min-height:32px;  \
    }  \
    QToolButton{  \
color:#a9b7c6;  \
        min-height:20;  \
        border-style:solid;  \
        border-top-left-radius:2px;  \
        border-top-right-radius:2px;  \
        background-color: #1e1d23);  \
border:1px;  \
        border-radius:5px;padding:2px 4px;/*border-radius控制圆角大小*/ \
    }  \
QToolButton:hover{  /*鼠标放上后*/  \
color:rgb(255, 255, 255);  \
        min-height:20;  \
        border-style:solid;  \
        border-top-left-radius:2px;  \
        border-top-right-radius:2px;  \
background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop:0 rgb(226,236,241),   \
                            stop: 0.3 rgb(160,160,160),  \
                            stop: 1 rgb(120,120,120));  \
border:1px;  \
        border-radius:5px;padding:2px 4px;  \
    }  \
QToolButton:pressed{ /*按下按钮后*/  \
color:rgb(255, 255, 255);  \
        min-height:20;  \
        border-style:solid;  \
        border-top-left-radius:2px;  \
        border-top-right-radius:2px;  \
background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop:0 rgb(226,236,241),   \
                            stop: 0.3 rgb(190,190,190),  \
                            stop: 1 rgb(160,160,160));  \
border:1px;  \
        border-radius:5px;padding:2px 4px;  \
    }  \
QToolButton:checked{    /*选中后*/  \
color:rgb(255, 255, 255);  \
        min-height:20;  \
        border-style:solid;  \
        border-top-left-radius:2px;  \
        border-top-right-radius:2px;  \
background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop:0 rgb(226,236,241),   \
                            stop: 0.3 rgb(190,190,190),  \
                            stop: 1 rgb(160,160,160));  \
border:1px;  \
        border-radius:5px;padding:2px 4px;  \
    } ");


    button->setStyleSheet(
                "QToolButton\
    {\
                    background-color: #606060;\
                    min-width: 80px;\
                    border-radius: 4px;\
                    padding: 5px;\
                }\
                QToolButton::flat \
    { \
                    background-color: transparent; \
                    border: none; \
                    color: #000; \
                } \
                QToolButton::disabled \
    { \
                    background-color: #606060; \
                    color: #606060; \
                    border-color: #606060; \
                } \
                QToolButton::hover \
    { \
                    background-color: #bd5355; \
                    border: 1px solid #bd5355; \
                    \
                } \
                \
                \
                \
                QToolButton::pressed \
    { \
                    background-color: #2385b4; \
                    border: 1px solid #46a2da; \
                }\
                QToolButton::checked \
    {\
                    background-color: #4c46ff;\
                    color: #ffffff;\
                }");
                button->setCheckable(true);
            button->setParent(ui->widget_toolbar);
    button->setText(QString(" %1路 ").arg(i+1));
    button->setMinimumHeight(40);
    //  button->setGeometry(buttonWidth*(i),0,buttonWidth,buttonHeight);

    connect(button,&QToolButton::clicked,[this,i](bool check){
        TesterModel::getInstance()->setSLItemShow(i,check);
        refreshSensorWidgets();
        //qDebug()<<"refresh ";
    });
    layout->setMargin(2);
    layout->setStretch(i,0);
    layout->addWidget(button,0,Qt::AlignLeft);
    button->setChecked(model->show);

    if(model->enabled){
        button->setText(QString("%1路(%2)").arg(model->id).arg(model->BianHao));
        button->setToolTip(QString("%1路(%2)").arg(model->id).arg(model->BianHao));
    }else{
        button->setText(QString(" %1路(%2)").arg(model->id).arg("--"));
        button->setToolTip(QString("%1路(%2)").arg(model->id).arg("--"));
    }
    //button->setUserData(1,model);
    mButtonList.append(button);
}
layout->addItem(new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum));

}

void MainWindow::initDualHeader()
{

    sensorWidgetHeaderMap[HEAD_SONSOR_WIDGET_LEFT] = new SensorWidget(ui->widget_left,HEAD_SONSOR_WIDGET_LEFT);
    sensorWidgetHeaderMap[HEAD_SONSOR_WIDGET_LEFT]->setModelId(HEAD_SONSOR_WIDGET_LEFT,selected_1_id);
    sensorWidgetHeaderMap[HEAD_SONSOR_WIDGET_RIGHT] = new SensorWidget(ui->widget_right,HEAD_SONSOR_WIDGET_RIGHT);
    sensorWidgetHeaderMap[HEAD_SONSOR_WIDGET_RIGHT]->setModelId(HEAD_SONSOR_WIDGET_RIGHT,selected_2_id);



    connect(sensorWidgetHeaderMap[HEAD_SONSOR_WIDGET_LEFT],SIGNAL(onChangedId(int,int)),this,SLOT(onChangedId(int,int)));


    connect(sensorWidgetHeaderMap[HEAD_SONSOR_WIDGET_LEFT],&SensorWidget::onChangedDanWei,[=](QString danwei){
        ui->tableWidget->setItem(0, 0, new QTableWidgetItem(QString("输入值(%1)").arg(danwei)));
        ui->tableWidget->setItem(0, 1, new QTableWidgetItem(QString("理论输入值(%1)").arg(danwei)));
        ui->tableWidget->setItem(0, 2, new QTableWidgetItem(QString("实际输出值(%1)").arg(danwei)));
    });

}
//初始化表格界面
void MainWindow::initJianDingTableWidget()
{

    ui->widget_gr->setEnabled(false);
    ui->tableWidget->setShowGrid(true);

    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->horizontalHeader()->setVisible(false);
    ui->tableWidget->setRowCount(14);
    ui->tableWidget->setColumnCount(8);

    for(int i=0;i<14;i++){
        ui->tableWidget->setRowHeight(i,16);

    }
    ui->tableWidget->setColumnWidth(0,136);


    ui->tableWidget->setSpan(0,0,2,1);
    ui->tableWidget->setSpan(0,1,2,1);

    ui->tableWidget->setItem(0, 0, new QTableWidgetItem(QString("输入值(%1)").arg("N.m")));
    ui->tableWidget->setItem(0, 1, new QTableWidgetItem(QString("理论输出值(%1)").arg("N.m")));
    ui->tableWidget->setItem(0, 2, new QTableWidgetItem(QString("实际输出值(%1)").arg("N.m")));

    ui->tableWidget->setSpan(0,2,1,3);
    ui->tableWidget->setItem(1, 2, new QTableWidgetItem("1"));
    ui->tableWidget->setItem(1, 3, new QTableWidgetItem("2"));
    ui->tableWidget->setItem(1, 4, new QTableWidgetItem("3"));
    ui->tableWidget->setSpan(0,5,2,1);
    ui->tableWidget->setItem(0, 5, new QTableWidgetItem(" 平均值 "));

    ui->tableWidget->setSpan(0,6,2,1);
    ui->tableWidget->setItem(0, 6, new QTableWidgetItem(" 误差% "));

    ui->tableWidget->setSpan(0,7,2,1);
    ui->tableWidget->setItem(0, 7, new QTableWidgetItem("重复性%"));

    QTableWidgetItem * a = new QTableWidgetItem("标称扭矩放大系数");
    ui->tableWidget->setItem(13, 0, a);


    ui->tableWidget->setSpan(13,1,1,4);

    ui->tableWidget->setItem(13, 5, new QTableWidgetItem("零点漂移"));

    for(int i=0;i<MAX_RECORD_COUNT;i++){
        for(int j=0;j<8;j++)
            ui->tableWidget->setItem(i+2, j, new QTableWidgetItem(""));
    }

    connect(ui->tableWidget, SIGNAL(cellChanged(int,int)), this, SLOT(onCellChanged(int,int)));
    //connect(ui->tableWidget, SIGNAL(cell(int,int)), this, SLOT(onCellChanged(int,int)));
    connect(ui->tableWidget, &QTableWidget::cellClicked, [this](int r,int c){
        addRecorder.setItemFocus(ui->tableWidget->currentItem());
    });

    ui->pushButton_kaishijianding->setCheckable(true);
    //开始检定按钮事件
    connect(ui->pushButton_kaishijianding,&QPushButton::clicked,[=](){
        //发送检定命令到设备
        if(!ui->pushButton_kaishijianding->isChecked()){
            onJianDingAction(false);
        }else{
            onJianDingAction(true);
        }

        ui->widget_gr->setEnabled(ui->pushButton_kaishijianding->isChecked());
    });
    connect(ui->pushButton_jilu,&QPushButton::clicked,[=](){
        if(!ui->pushButton_kaishijianding->isChecked())
        {
            showStatusMessage(" 未开始检定，请按开始检定按钮开始 ");
            return;
        }
        SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(selected_2_id);
        if(!model){
            qDebug()<<"error: id data not found";
            return;
        }
        if(sensorWidgetHeaderMap[HEAD_SONSOR_WIDGET_RIGHT]){
            qDebug() << "current 2 data: "<< sensorWidgetHeaderMap[HEAD_SONSOR_WIDGET_RIGHT]->getCurrentValue();

            addRecorder.onAddRecord(QString("%1").arg(sensorWidgetHeaderMap[HEAD_SONSOR_WIDGET_RIGHT]->getCurrentValue()));
        }


    });
    connect(ui->pushButton_daochu,&QPushButton::clicked,[=](){

        SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(selected_1_id);
        if(!model){
            qDebug()<<"error: id data not found";
            return;
        }

        //QString preset = QString("%1-%2-%3-%4.xls").arg(ui->lineEdit_kehumingcheng->text()).arg(model->XingHao).arg(model->BianHao).arg(model->Operator.JiaoZhunriQi);
        readJianDingTableData(selected_1_id);
        model->Operator.WeiTuoDanJuHao = ui->lineEdit_danjuhao->text();
        model->SCChangJia = ui->lineEdit_shengchangchuangjia->text();
        model->XingHao = ui->lineEdit_xinghao->text();
        model->ChuChangBiaoHao = ui->lineEdit_chuchangbianhao->text();
        model->Operator.JiaoZunHuangJing = QString("%1℃/%2%").arg(ui->lineEdit_wendu->text()).arg(ui->lineEdit_shidu->text());
        //    model->Operator.JiaoZunHuangJing =
        model->Operator.ZhengShuDanWei = ui->lineEdit_kehumingcheng->text();
        model->Operator.ZhengShuDanWei = ui->lineEdit_kehumingcheng->text();
        model->WenDu = ui->lineEdit_wendu->text().toInt();
        model->ShiDu = ui->lineEdit_shidu->text().toInt();

        model->Operator.DanJuHao = ui->lineEdit_danjuhao->text();
        model->Operator.YiQiMingCheng = ui->lineEdit_yiqimingcheng->text();

        model->Operator.JiaoZhunYuan = ui->lineEdit_jiandingyuan->text();
        model->Operator.JianYanYuan = ui->lineEdit_jiaoyanyuan->text();
        model->Operator.JiaoZhuDiDian = ui->lineEdit_jiandingdidian->text();
        model->Operator.JiaoZhunriQi = ui->lineEdit_jiandingriqi->text();

        model->Operator.BiaoZhunQiMingCheng = ui->lineEdit_biaozhunqimingcheng->text();
        model->Operator.BiaoZhunQiBianHao = ui->lineEdit_biaozhunqibianhao ->text();
        model->Operator.CeLiangFanWei = ui->lineEdit_celiangfanwei->text();
        model->Operator.ZhengShuYouXiaoRiQi = ui->lineEdit_zhengshuyouxiaoqi->text();
        model->Operator.BiaoZhunQiXingHao = ui->lineEdit_biaozhunqixinghao->text();
        model->Operator.JiShuZhiBiao = ui->lineEdit_jishuzhibiao->text();

        qDebug() << " \n" << model->Operator.WeiTuoDanJuHao
                 << " \n" << model->SCChangJia
                 << " \n" << model->XingHao
                 << " \n" << model->ChuChangBiaoHao
                 << " \n" << model->Operator.JiaoZunHuangJing
                 << " \n" << model->Operator.ZhengShuDanWei
                 << " \n" << model->Operator.WeiTuoDanJuHao
                 << " \n" << model->WenDu
                 << " \n" << model->ShiDu
                 << " \n" << model->Operator.DanJuHao
                 << " \n" << model->Operator.YiQiMingCheng
                 << " \n" << model->Operator.JiaoZhunYuan
                 << " \n" << model->Operator.JianYanYuan
                 << " \n" << model->Operator.JiaoZhuDiDian
                 << " \n" << model->Operator.JiaoZhunriQi
                 << " \n" << model->Operator.BiaoZhunQiMingCheng
                 << " \n" << model->Operator.BiaoZhunQiBianHao
                 << " \n" << model->Operator.CeLiangFanWei
                 << " \n" << model->Operator.ZhengShuYouXiaoRiQi
                 << " \n" << model->Operator.BiaoZhunQiXingHao
                 << " \n" << model->Operator.JiShuZhiBiao;


#ifdef DEVELOPMENT

        if(XLSL::getInstance()->exportCeLiang2(model,"")){
            QMessageBox::information(this, "保存", "导出成功");
        }
        else
            QMessageBox::information(this, "保存", "导出失败");

#else
        QString preset = QString("%1-%2-%3-%4.xls").arg(ui->lineEdit_kehumingcheng->text()).arg(model->XingHao).arg(model->BianHao).arg(model->Operator.JiaoZhunriQi);
        QString filepath = QFileDialog::getSaveFileName(this,"保存",preset,"Excel(*.xls)");
        if (filepath.length() > 0)
        {
            readJianDingTableData(selected_1_id);
            if(XLSL::getInstance()->exportCeLiang2(model,filepath)){
                QMessageBox::information(this, "保存", "导出成功");
            }
            else
                QMessageBox::information(this, "保存", "导出失败");
        }
#endif
    });

    connect(ui->pushButton_qingkong,&QPushButton::clicked,[=](){
        int d = 10;
        if(ui->radioButton_5dian->isChecked()){
            d = 5;
        }
        else if(ui->radioButton_8dian->isChecked()){
            d = 8;
        }
        else if(ui->radioButton_10dian->isChecked()){
            d=10;
        }else{
            d = ui->lineEdit_qitadian->text().toInt();
        }
        clearJianDingTable(d);
    });

    connect(ui->radioButton_5dian,&QPushButton::clicked,[=](){
        calculateJianDingTable(selected_1_id);
    }
    );
    connect(ui->radioButton_8dian,&QPushButton::clicked,[=](){
        calculateJianDingTable(selected_1_id);
    }
    );
    connect(ui->radioButton_10dian,&QPushButton::clicked,[=](){
        calculateJianDingTable(selected_1_id);
    }
    );

    connect(ui->radioButton_qita,&QPushButton::clicked,[=](){
        int d = ui->lineEdit_qitadian->text().toInt();
        if(d< MAX_RECORD_COUNT && d >0){
            calculateJianDingTable(selected_1_id);
        }
    }
    );

    connect(ui->lineEdit_qitadian,&QLineEdit::textChanged,[=](const QString t){
        int d = t.toInt();
        if(d< MAX_RECORD_COUNT && d >0 && ui->radioButton_qita->isChecked()){
            calculateJianDingTable(selected_1_id);
        }
    }
    );



    connect(ui->radioButton_lizhi,&QPushButton::clicked,[=](){
        TesterModel::getInstance()->switchMode(true);
        MasterThread::getInstance()->cmdJianDing();

    }
    );
    connect(ui->radioButton_lingmindu,&QPushButton::clicked,[=](){
        TesterModel::getInstance()->switchMode(false);
        MasterThread::getInstance()->cmdBiaoDing();
    }
    );

}


//初始化曲线图表界面
void MainWindow::initChart()
{

    myChartViewMap[0] = new MyChartView(ui,ui->pushButton_baocun1,ui->pushButton_qingchu1,ui->widget_curve_1);
    myChartViewMap[1] = new MyChartView(ui,ui->pushButton_baocun2,ui->pushButton_qingchu2,ui->widget_curve_2);

    connect(myChartViewMap[0],&MyChartView::onSaveClicked,[=](){
        QString fileName = QDateTime::currentDateTime().toString("ddhhmmss")+".png";
        QString filepath = QFileDialog::getSaveFileName(this,"保存",fileName,"输出曲线(*.png)");
        if (filepath.length() > 0)
        {
            QPixmap p = QPixmap::grabWidget(myChartViewMap[0]->getChartView());
            QImage image = p.toImage();
            image.save(filepath);
            qDebug()<<"export out png successed.";
            showStatusMessage("输出曲线图成功！");
        }
    }
    );
    connect(myChartViewMap[1],&MyChartView::onSaveClicked,[=](){
        QString fileName = QDateTime::currentDateTime().toString("ddhhmmss")+".png";
        QString filepath = QFileDialog::getSaveFileName(this,"保存",fileName,"输出曲线(*.png)");
        if (filepath.length() > 0)
        {
            QPixmap p = QPixmap::grabWidget(myChartViewMap[1]->getChartView());
            QImage image = p.toImage();
            image.save(filepath);
            qDebug()<<"export out png successed.";
            showStatusMessage("输出曲线图成功！");
        }
    }
    );
    connect(myChartViewMap[0],&MyChartView::onClearClicked,[=](){
        TesterModel::getInstance()->clearCurve(selected_1_id);
        QList<UPDATE_DATA_T> list;
        myChartViewMap[0]->changedId(list,selected_1_id);
        showStatusMessage(" 清除曲线1 数据已清除 ");
    }
    );
    connect(myChartViewMap[1],&MyChartView::onClearClicked,[=](){
        QList<UPDATE_DATA_T> list;
        TesterModel::getInstance()->clearCurve(selected_2_id);
        myChartViewMap[1]->changedId(list,selected_2_id);
        showStatusMessage(" 清除曲线2 数据已清除 ");
    }
    );

}
//把表格里面的数据输出到变量列表
void MainWindow::exportTableData(int id,bool jianDing)
{
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);
    if(!model){
        qDebug()<<"error: id data not found " << id;
        return;
    }
    if(ui->radioButton_1wei->isChecked()){
        model->Operator.BaoLiuXiaoShu = 1;
    }else {
        model->Operator.BaoLiuXiaoShu = 2;
    }

    if(ui->radioButton_laxiang){
        model->Operator.YaXiang = false;
    }else {
        model->Operator.YaXiang = true;
    }

    calculateJianDingTable(id);

}

static QString getCellText(float v,int d=6){
    QString r =QString("%1").arg(v);
    //    QString r = v==0?"":QString("%1").arg(v);
    //    QString r = QString("%1").arg(v,0,'f',d);
    return r;
}

//把变量的数据填入数据表格
void MainWindow::fillJianDingTableData(int id)
{
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);
    if(!model){
        qDebug()<<"error: id data not found";
        return;
    }

    int dianshu = model->Operator.DianShu;
    for(int i=0;i<MAX_RECORD_COUNT-1;i++){
        if(i>=dianshu){
            ui->tableWidget->item(i+2,0)->setText("");
            ui->tableWidget->item(i+2,1)->setText("");
            ui->tableWidget->item(i+2,2)->setText("");
            ui->tableWidget->item(i+2,3)->setText("");
            ui->tableWidget->item(i+2,4)->setText("");
            ui->tableWidget->item(i+2,5)->setText("");
            ui->tableWidget->item(i+2,6)->setText("");
            ui->tableWidget->item(i+2,7)->setText("");

        }else{
            if(!model->JianDingList[i].valid) continue;
            ui->tableWidget->item(i+2,0)->setText(getCellText(model->JianDingList[i].SHIYANLI,model->XiaoShu));
            ui->tableWidget->item(i+2,1)->setText(getCellText(model->JianDingList[i].LILUNZHI));
            ui->tableWidget->item(i+2,2)->setText(getCellText(model->JianDingList[i].JINCHENG1,model->XiaoShu));
            ui->tableWidget->item(i+2,3)->setText(getCellText(model->JianDingList[i].JINCHENG2,model->XiaoShu));
            ui->tableWidget->item(i+2,4)->setText(getCellText(model->JianDingList[i].JINCHENG3,model->XiaoShu));
            ui->tableWidget->item(i+2,5)->setText(getCellText(model->JianDingList[i].JINCHENG_AVERAGE,model->XiaoShu));
            int weishu = std::max(1,model->Operator.BaoLiuXiaoShu);
            weishu = std::min(weishu,2);
            ui->tableWidget->item(i+2,6)->setText(QString("%1%").arg(model->JianDingList[i].XIANDUIWUCHAI,0,'r',weishu));
            ui->tableWidget->item(i+2,7)->setText(QString("%1%").arg(model->JianDingList[i].CHONGFUXING,0,'r',weishu));

        }
    }

}

//读取表格里面的数据,写到公共变量里面 ,同时计算好平均值

void MainWindow::readJianDingTableData(int id)
{
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);
    if(!model){
        qDebug()<<"error: id data not found";
        return;
    }


    int dianshu = 0;

    if(ui->radioButton_5dian->isChecked()){
        dianshu =5;

    }else if(ui->radioButton_8dian->isChecked()){
        dianshu =8;
    }else if(ui->radioButton_10dian->isChecked()){
        dianshu = 10;
    }else if(ui->radioButton_qita->isChecked()){
        dianshu = ui->lineEdit_qitadian->text().toInt();
    }

    if(ui->radioButton_1wei->isChecked()){
        model->Operator.BaoLiuXiaoShu =  1;
    }else{
        model->Operator.BaoLiuXiaoShu = 2;
    }

    if(ui->radioButton_laxiang->isChecked()){
        model->Operator.YaXiang = true;
    }
    else
        model->Operator.YaXiang = false;

    model->Operator.DianShu = dianshu;
#ifdef OLD_OPERATOR
    model->Operator.ShouJianDanWei = ui->lineEdit_kehumingcheng->text();
    model->Operator.WeiTuoDanJuHao = ui->lineEdit_danjuhao->text();
    model->BiaoZhunQiMingCheng = ui->lineEdit_biaozhunqimingcheng->text();
    model->JianDingYiJu = ui->comboBox_jiandingyiju->currentText();
#else
    model->Operator.NiuJuFangDaBeiShu =  getCellValue(ui->tableWidget->item(13,1));
#endif

    for(int i=0;i<MAX_RECORD_COUNT-1;i++){
        model->JianDingList[i].valid = false;
        for(int j=0;j<5;j++){
            if(ui->tableWidget->item(i+2,j)->text().length()>0){
                model->JianDingList[i].valid = true;
                break;
            }
        }
        if(model->JianDingList[i].valid){
            model->Operator.DianShu = i+1;
        }
        else{
            continue;
        }


        model->JianDingList[i].SHIYANLI = getCellValue(ui->tableWidget->item(i+2,0)->text());
        model->JianDingList[i].LILUNZHI = model->Operator.NiuJuFangDaBeiShu * model->JianDingList[i].SHIYANLI;
        model->JianDingList[i].JINCHENG1 = getCellValue(ui->tableWidget->item(i+2,2)->text());
        model->JianDingList[i].JINCHENG2 = getCellValue(ui->tableWidget->item(i+2,3)->text());
        model->JianDingList[i].JINCHENG3 = getCellValue(ui->tableWidget->item(i+2,4)->text());

        int validCount = 0;
        validCount += addValid(ui->tableWidget->item(i+2,2)->text());
        validCount += addValid(ui->tableWidget->item(i+2,3)->text());
        validCount += addValid(ui->tableWidget->item(i+2,4)->text());
        validCount = std::max(validCount,1);
        model->JianDingList[i].JINCHENG_AVERAGE = (model->JianDingList[i].JINCHENG1+model->JianDingList[i].JINCHENG2+
                                                   model->JianDingList[i].JINCHENG3)/validCount;
        float maxf = std::max(model->JianDingList[i].JINCHENG1,model->JianDingList[i].JINCHENG2);
        maxf = std::max(maxf,model->JianDingList[i].JINCHENG3);

        float minf = std::min(model->JianDingList[i].JINCHENG1,float(999999.99));
        minf = std::min(minf,model->JianDingList[i].JINCHENG2==0?9999999:model->JianDingList[i].JINCHENG2);
        minf = std::min(minf,model->JianDingList[i].JINCHENG3==0?9999999:model->JianDingList[i].JINCHENG3);

        if(model->JianDingList[i].JINCHENG_AVERAGE==0){
            model->JianDingList[i].XIANDUIWUCHAI = 0;
            model->JianDingList[i].CHONGFUXING = 0;
        }else{
            // model->JianDingList[i].XIANDUIWUCHAI = (model->JianDingList[i].SHIYANLI-model->JianDingList[i].JINCHENG_AVERAGE)*100/model->JianDingList[i].JINCHENG_AVERAGE;
            //  model->JianDingList[i].CHONGFUXING = (maxf -minf)*100/model->JianDingList[i].JINCHENG_AVERAGE;;
            model->JianDingList[i].XIANDUIWUCHAI = (model->JianDingList[i].JINCHENG_AVERAGE-model->JianDingList[i].LILUNZHI)*100/model->JianDingList[i].JINCHENG_AVERAGE;
            model->JianDingList[i].CHONGFUXING = (maxf -minf)*100/model->JianDingList[i].JINCHENG_AVERAGE;;
        }
    }

    qDebug()<< "end read table data.";
}
//更新数据到检定表输入框
void MainWindow::updateJianDingInfo(int id)
{
    SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(id);
    if(!model){
        qDebug()<<"error: id data not found";
        return;
    }

    //    ui->lineEdit_biaozhunqimingcheng->setText(model->BiaoZhunQiMingCheng);

    ui->tableWidget->setItem(0, 0, new QTableWidgetItem(QString("输入值(%1)").arg(model->DanWei)));
    ui->tableWidget->setItem(0, 1, new QTableWidgetItem(QString("理论输出值(%1)").arg(model->DanWei)));
    ui->tableWidget->setItem(0, 2, new QTableWidgetItem(QString("实际输出值(%1)").arg(model->DanWei)));



#ifdef OLD_OPERATOR
    ui->lineEdit_jiandingriqi->setText(model->Operator.JiaoZhunriQi);
    ui->lineEdit_jiandingyuan->setText(model->Operator.JiaoZhunYuan);
    ui->lineEdit_jiaoyanyuan->setText(model->Operator.JianYanYuan);

#else

#endif


//    ui->lineEdit_jishuzhibiao->setText(model->JiShuZhiBiao);
    ui->lineEdit_kehumingcheng->setText("");
    ui->lineEdit_shidu->setText(QString("%1").arg(60));
    ui->lineEdit_wendu-> setText(QString("%1").arg(20,0,'r',1));
    ui->lineEdit_jiandingriqi->setText(QDate::currentDate().toString("yyyy.MM.dd"));

//    ui->lineEdit_liangcheng->setText(QString("%1").arg(model->CeLiangFanWei));
//    ui->lineEdit_shengchangchuangjia->setText(model->SCChangJia);
//    ui->lineEdit_xinghao->setText(model->XingHao);
//    ui->lineEdit_yiqimingcheng->setText(model->BiaoZhunQiMingCheng);
//    ui->lineEdit_zhengshuyouxiaoqi->setText(model->ZhengShuYouXiaoRiQi);
//    ui->lineEdit_jiandingriqi->setText(model->Operator.JiaoZhunriQi);
//    ui->lineEdit_biaozhunqimingcheng->setText(QString("%1(%2)").arg(model->CeLiangFanWei).arg(model->BianHao));
//    ui->lineEdit_celiangfanwei->setText(QString("%1").arg(model->CeLiangFanWei));
//    ui->lineEdit_chuchangbianhao->setText(model->ChuChangBiaoHao);
//    ui->lineEdit_biaozhunqixinghao->setText(model->XingHao);
//    ui->lineEdit_biaozhunqibianhao->setText(model->BianHao);
//    ui->lineEdit_jiandingdidian->setText(model->JianDingDiDian);
}

void MainWindow::clearJianDingTable(int dianshu)
{

    ui->tableWidget->blockSignals(true);

    for(int i=0;i<MAX_RECORD_COUNT-1;i++){
        ui->tableWidget->item(i+2,0)->setText("");
        ui->tableWidget->item(i+2,1)->setText("");
        ui->tableWidget->item(i+2,2)->setText("");
        ui->tableWidget->item(i+2,3)->setText("");
        ui->tableWidget->item(i+2,4)->setText("");
        ui->tableWidget->item(i+2,5)->setText("");
        ui->tableWidget->item(i+2,6)->setText("");
        ui->tableWidget->item(i+2,7)->setText("");
    }
    ui->tableWidget->blockSignals(false);
}// 开始检定

void MainWindow::onTableWidgetStandby(int d,QTableWidget *tw)
{



    //清空要记录的格子,并加入列表
    addRecorder.clearList();

    for(int i=0;i<d;i++){
        addRecorder.pushItem(tw->item(i+2,2));
    }
    for(int i=0;i<d;i++){
        addRecorder.pushItem(tw->item(i+2,3));
    }
    for(int i=0;i<d;i++){
        addRecorder.pushItem(tw->item(i+2,4));
    }


    //addRecorderLeft.clearList();
    //    for(int i=0;i<d;i++){
    //        addRecorderLeft.pushItem(tw->item(i+2,0));
    //    }
}

void MainWindow::onStartBiaoDing(int id)
{

}

void MainWindow::onJianDingAction(bool f)
{

    ui->pushButton_jilu->setEnabled(f);



    if(f){
        int d = 0;
        if(ui->radioButton_5dian->isChecked()){
            d = 5;
        }
        else if(ui->radioButton_8dian->isChecked()){
            d = 8;
        }
        else if(ui->radioButton_10dian->isChecked()){
            d=10;
        }else{

        }
        ui->pushButton_kaishijianding->setText(" 停止检定 ");
        MasterThread::getInstance()->cmdJianDing();
        onTableWidgetStandby(d,ui->tableWidget);
        calculateJianDingTable(selected_1_id);

        addRecorder.setItemFocus(ui->tableWidget->item(2,2));
        showStatusMessage(" 开始检定 ");

        const SENSOR_DATA_T * model =  TesterModel::getInstance()->getSensorDataById(selected_1_id);
        if(!model){
            qDebug()<<"error: id data not found";
            return;
        }

        myChartViewMap[0]->changedId(model->CurveList, model->CeLiangFanWei/std::pow(10,model->XiaoShu));

        model =  TesterModel::getInstance()->getSensorDataById(selected_2_id);
        if(!model){
            qDebug()<<"error: id data not found";
            return;
        }

        myChartViewMap[1]->changedId(model->CurveList,model->CeLiangFanWei/std::pow(10,model->XiaoShu));


    }else{
        ui->pushButton_kaishijianding->setText(tr(" 开始检定 "));
        MasterThread::getInstance()->cmdStop();
        showStatusMessage(" 停止检定 ");


    }
}

void MainWindow::doStart()
{

    if(MasterThread::getInstance()->openSerial()){
        MasterThread::getInstance()->init();
        updateJianDingInfo(selected_1_id);
    }else{
        QMessageBox::information(this,"串口","打开串口失败!,请选择串口再次打开");
    }
}

void MainWindow::showEvent(QShowEvent *event)
{
}



void MainWindow::showStatusMessage(const QString &message)
{
    status->setText(message);
}
