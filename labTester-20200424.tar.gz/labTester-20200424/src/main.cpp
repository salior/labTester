/****************************************************************************
**
** Copyright (C) 2012 Denis Shienkov <denis.shienkov@gmail.com>
** Copyright (C) 2012 Laszlo Papp <lpapp@kde.org>
** Contact: https://www.qt.io/licensing/
**
** This file is part of the QtSerialPort module of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include <QApplication>

#include "mainwindow.h"
#include "logger.h"
#ifdef USEQML
#include <QQmlApplicationEngine>
#include <QtQml>

#include <QtQuick/QQuickView>
#include <QtQml/QQmlEngine>

#include <qml/sensoritem.h>
class QMLControl{
public:
    DECLARE_SINGLETON_0BJCE(QMLControl)
    explicit QMLControl(){

    }
    void init(){
        qmlRegisterType<SensorItem>("SensorItem", 1, 0, "SensorItem");
    }
};

#else
#endif
#include <QGuiApplication>
#include "masterthread.h"
#include "testcontrol.h"
#include <QTextCodec>
#include <QException>
#include <QDebug>

int main(int argc, char *argv[])
{



#if (QT_VERSION >= QT_VERSION_CHECK(5, 6, 0))
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif

    QApplication a(argc, argv);
    Logger::getInstance();
    TestControl::getInstance()->start();
#ifndef USEQML

    QTextCodec *codec = QTextCodec::codecForName("UTF-8");//情况2


    QFont font = a.font();
    //     font.setPointSize(12);//字体大小
    font.setFamily("Roboto");
    a.setFont(font);

//    FontManager::setFont(&a);
    //     QTextCodec::setCodecForTr(codec);


    Q_INIT_RESOURCE(resources);
    QTextCodec::setCodecForLocale(codec);
    //     QTextCodec::setCodecForCStrings(codec);
    MainWindow w;
    w.setWindowOpacity(1);
    w.setWindowFlags(Qt::FramelessWindowHint);
    w.setAttribute(Qt::WA_TranslucentBackground);

    w.show();
#else

    //     QObject::connect(MasterThread::getInstance().get(),&MasterThread::updated,[=](int id) {
    //                 qDebug()<<"on item update..";

    //             });

    QMLControl::getInstance()->init();
    qmlRegisterType<SensorItem>("SensorItem", 1, 0, "SensorItem");
    //      QQmlApplicationEngine engine;


    //      engine.load(QUrl(QStringLiteral("qrc:/qml/app.qml")));

    const QString mainQmlApp = QStringLiteral("qrc:/qml/app.qml");
    QQuickView view;
    view.setSource(QUrl(mainQmlApp));
    view.setResizeMode(QQuickView::SizeRootObjectToView);
    // Qt.quit() called in embedded .qml by default only emits
    // quit() signal, so do this (optionally use Qt.exit()).
    QObject::connect(view.engine(), SIGNAL(quit()), qApp, SLOT(quit()));
    // view.setGeometry(QRect(100, 100, 360, 640));
    view.show();

#endif
    int ret;
    try {
        ret = a.exec();
    } catch (const QException &e)
    {

        qCritical()<< QString(" 出错啦~ [%1]").arg(e.what());

        return EXIT_FAILURE; // exit the application
    }
    return ret;
}
