#include "testcontrol.h"
#include "testermodel.h"
#include "xlsl.h"
#include "masterthread.h"
#include <thread>
#include <QThread>

static QString addSomething(int index,QString a){
    return QString("***%1---%2").arg(index).arg(a);
}

TestControl::TestControl()
{

}



void TestControl::start()
{

    if(TesterModel::getInstance()->getSensorCount() ==MAX_SENSOR_COUNT ){
        qDebug()<< "has init data ...";
        return ;
    }
    for(int i=0;i<MAX_SENSOR_COUNT;i++){
        SENSOR_DATA_T t1;
        t1.enabled = false;
        t1.BianHao = "--";
        t1.BiaoDingRiQi="";
        t1.BiaoZhunQiMingCheng = "--";
        t1.CeLiangFanWei = 100;
        t1.ChuChangBiaoHao= "--";
        t1.DanWei ="N";
        t1.FengZhi =0;
        t1.AD = 0;
        t1.id = 1+i;
        t1.show = true;
        //    t1.JianDingDian = "guangdonghaobangshou";
        t1.JianDingDiDian = "";
        t1.JianDingYiJu = "";
        t1.JiShuZhiBiao = "";
        t1.LingMinDu = 0.2;
        t1.LiZhi =0;
        t1.SCChangJia = "";
        t1.ShiDu = 0;
        t1.WenDu = 0;
        t1.XiaoShu = 4;
        t1.XingHao = "--";
        t1.ZhengShuHao="";
        t1.ZhengShuYouXiaoRiQi = "";
        t1.ZhongLiJiaShuDu=9.7883;
        t1.Operator.JiaoZhunriQi = QDate::currentDate().toString("yyyy.MM.dd");
#ifdef OLD_OPERATOR

        t1.Operator.JiaoZhunYuan = "";
        t1.Operator.YouXiaoRiQi = "";
#else

        t1.Operator.NiuJuFangDaBeiShu = 0.2;
        t1.Operator.JiaoZhuDiDian ="力学实验室";
#endif

        for(int j=0;j<MAX_RECORD_COUNT;j++){
            t1.BiaoDingList[j].BIAODINGDIAN = (0.0*j);
            t1.BiaoDingList[j].BIAODINGZHI1 = (0.0*j);
            t1.BiaoDingList[j].BIAODINGZHI2 = (0.0*j);
            t1.BiaoDingList[j].BIAODINGZHI3 = (0.0*j);
            t1.BiaoDingList[j].BIAODINGZHI_AVERAGE = (t1.BiaoDingList[j].BIAODINGZHI1+
                                                      t1.BiaoDingList[j].BIAODINGZHI2+
                                                      t1.BiaoDingList[j].BIAODINGZHI3/3);

        }

        for(int j=0;j<MAX_RECORD_COUNT;j++){
            t1.JianDingList[j].LILUNZHI = 0.0*j;
            t1.JianDingList[j].CHONGFUXING = 0.0*j;
            t1.JianDingList[j].HUICHENG =0.0;
            t1.JianDingList[j].SHIYANLI = 0.0*j;
            t1.JianDingList[j].XIANDUIWUCHAI = 0.0*j;
            t1.JianDingList[j].HUICHENG = 0.0*j;
            t1.JianDingList[j].JINCHENG1 = 0.0*j;
            t1.JianDingList[j].JINCHENG2 = 0.0*j;
            t1.JianDingList[j].JINCHENG3 = 0.0*j;
            t1.JianDingList[j].JINCHENG_AVERAGE = (t1.JianDingList[j].JINCHENG1+
                                                   t1.JianDingList[j].JINCHENG2+
                                                   t1.JianDingList[j].JINCHENG3)/3;


            t1.BiaoDingList[j].BIAODINGZHI_AVERAGE =(t1.BiaoDingList[j].BIAODINGZHI1+
                                                      t1.BiaoDingList[j].BIAODINGZHI2+
                                                      t1.BiaoDingList[j].BIAODINGZHI3)/3;

        }


        TesterModel::getInstance()->addSensor(&t1);
    }


   // output();
   // MasterThread::getInstance()->init();

//    std::thread t([this]{
//        int id = 1;

//        while(true){
//            MasterThread::getInstance()->cmdGetInfomation();
//            QThread::sleep(1);
//            MasterThread::getInstance()->cmdSelectSensorById(id);
//            QThread::sleep(5);
//            //        MasterThread::getInstance()->cmdJiaoZhun();
//            QThread::sleep(5);
//            MasterThread::getInstance()->cmdGengGaiLingMinDu(0.6555);
//            QThread::sleep(5);
//            MasterThread::getInstance()->cmdSaveXiShu("0.3232");
//            QThread::sleep(5);
//            MasterThread::getInstance()->cmdJianDing();
//            QThread::sleep(5);

//            id++;
//            if(id>=MAX_SENSOR_COUNT){
//                id =1;
//            }
//        }
//    });

//    t.detach();
}

void TestControl::start2()
{

    if(TesterModel::getInstance()->getSensorCount() ==MAX_SENSOR_COUNT ){
        qDebug()<< "has init data ...";
        return ;
    }
    for(int i=0;i<MAX_SENSOR_COUNT;i++){
        SENSOR_DATA_T t1;
        t1.enabled = false;
        t1.BianHao = addSomething(i,"bianhao1") ;
        t1.BiaoDingRiQi="20150405";
        t1.BiaoZhunQiMingCheng = addSomething(i,"biaodchenn");
        t1.CeLiangFanWei = 100;
        t1.ChuChangBiaoHao= "chuchangbiao22333";
        t1.DanWei ="N";
        t1.FengZhi =222;
        t1.AD = 10;
        t1.id = 1+i;
        t1.show = true;
        //    t1.JianDingDian = "guangdonghaobangshou";
        t1.JianDingDiDian = addSomething(i,"JianDingDiDian");
        t1.JianDingYiJu = "JJG139-2014ddssddsd";
        t1.JiShuZhiBiao = addSomething(i,"jishuzhibiao");
        t1.LingMinDu = 3322.2;
        t1.LiZhi =339932;
        t1.SCChangJia = addSomething(i,"SCChangJia");
        t1.ShiDu = 15.2;
        t1.WenDu = 45;
        t1.XiaoShu = 4;
        t1.XingHao = addSomething(i,"xinghao");
        t1.ZhengShuHao=addSomething(i,"zhengshuhao");
        t1.ZhengShuYouXiaoRiQi = "20190607";
        t1.ZhongLiJiaShuDu=9.7883;

#ifdef OLD_OPERATOR
        t1.Operator.JianYanYuan = "";
        t1.Operator.JiaoZhunriQi = QDate::currentDate().toString("yyyy.MM.dd");
        t1.Operator.JiaoZhunYuan = "";
        t1.Operator.YouXiaoRiQi = "";
#else
#endif

        for(int j=0;j<MAX_RECORD_COUNT;j++){
            t1.BiaoDingList[j].BIAODINGDIAN = (0.1111*j);
            t1.BiaoDingList[j].BIAODINGZHI1 = (0.1311*j);
            t1.BiaoDingList[j].BIAODINGZHI2 = (0.1131*j);
            t1.BiaoDingList[j].BIAODINGZHI3 = (0.1331*j);
            t1.BiaoDingList[j].BIAODINGZHI_AVERAGE = (t1.BiaoDingList[j].BIAODINGZHI1+
                                                      t1.BiaoDingList[j].BIAODINGZHI2+
                                                      t1.BiaoDingList[j].BIAODINGZHI3/3);

        }

        for(int j=0;j<MAX_RECORD_COUNT;j++){
            t1.JianDingList[j].CHONGFUXING = 0.1111*j;
            t1.JianDingList[j].HUICHENG =0.32333;
            t1.JianDingList[j].SHIYANLI = 3322.32*j;
            t1.JianDingList[j].XIANDUIWUCHAI = 233.23*j;
            t1.JianDingList[j].HUICHENG = 0.33111*j;
            t1.JianDingList[j].JINCHENG1 = 0.1111*j;
            t1.JianDingList[j].JINCHENG2 = 0.1111*j;
            t1.JianDingList[j].JINCHENG3 = 0.1111*j;
            t1.JianDingList[j].JINCHENG_AVERAGE = (t1.JianDingList[j].JINCHENG1+
                                                   t1.JianDingList[j].JINCHENG2+
                                                   t1.JianDingList[j].JINCHENG3)/3;


            t1.BiaoDingList[j].BIAODINGZHI_AVERAGE =(t1.BiaoDingList[j].BIAODINGZHI1+
                                                     t1.BiaoDingList[j].BIAODINGZHI2+
                                                     t1.BiaoDingList[j].BIAODINGZHI3)/3;

        }


        TesterModel::getInstance()->addSensor(&t1);
    }


    // output();
    // MasterThread::getInstance()->init();

    //    std::thread t([this]{
    //        int id = 1;

    //        while(true){
    //            MasterThread::getInstance()->cmdGetInfomation();
    //            QThread::sleep(1);
    //            MasterThread::getInstance()->cmdSelectSensorById(id);
    //            QThread::sleep(5);
    //            //        MasterThread::getInstance()->cmdJiaoZhun();
    //            QThread::sleep(5);
    //            MasterThread::getInstance()->cmdGengGaiLingMinDu(0.6555);
    //            QThread::sleep(5);
    //            MasterThread::getInstance()->cmdSaveXiShu("0.3232");
    //            QThread::sleep(5);
    //            MasterThread::getInstance()->cmdJianDing();
    //            QThread::sleep(5);

    //            id++;
    //            if(id>=MAX_SENSOR_COUNT){
    //                id =1;
    //            }
    //        }
    //    });

    //    t.detach();
}

void TestControl::output()
{
    XLSL::getInstance()->exportBiaoDing2(TesterModel::getInstance()->getSensorDataById(3),"");

    XLSL::getInstance()->exportCeLiang2(TesterModel::getInstance()->getSensorDataById(1),"");
}
