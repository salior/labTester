#include "xlsl.h"
#include <QDebug>

#include <QCoreApplication>

XLSL::XLSL()
{

}

bool XLSL::exportCeLiang(const SENSOR_DATA_T *data,QList<JIANDING_DATA_T> &list, OPERATOR_T &op, QString saveName)
{

    QString fileName = CELIANG_MOBAN;
    qDebug() << "start load  " << QCoreApplication::applicationDirPath()+"/template/"+fileName;
    QXlsx::Document xlsx(QCoreApplication::applicationDirPath()+"/template/"+fileName);

    if(xlsx.load()){
        //    qDebug() << "[debug] success to load xlsx file.";
        //    changeValue(&xlsx,1,1,"changed value");
        //    changeValue(&xlsx,2,2,"changed value2");
        //    changeValue(&xlsx,2,3,3.256555,3);

        changeCeLiangSheet(&xlsx,data,list,op);
        xlsx.saveAs(QCoreApplication::applicationDirPath()+"/template/"+saveName);

    }else{
        qDebug()<< "load fail.";
        return false;
    }
    return true;
}

bool XLSL::exportCeLiang2(const SENSOR_DATA_T *data, QString saveName)
{
    QString fileName = CELIANG_MOBAN;
    qDebug() << "start load  " << QCoreApplication::applicationDirPath()+"/template/"+fileName;
    QXlsx::Document xlsx(QCoreApplication::applicationDirPath()+"/template/"+fileName);

    if(xlsx.load()){
        //    qDebug() << "[debug] success to load xlsx file.";
        //    changeValue(&xlsx,1,1,"changed value");
        //    changeValue(&xlsx,2,2,"changed value2");
        //    changeValue(&xlsx,2,3,3.256555,3);

        changeCeLiangSheet2(&xlsx,data);
        if(saveName.length()==0)
            return xlsx.saveAs(QCoreApplication::applicationDirPath()+"/test-jianding.xls");
        else
           return xlsx.saveAs(saveName);

        qDebug()<< "save xls name: " << saveName;
    }else{
        qDebug()<< "load fail.";
        return false;
    }
    return true;
}

bool XLSL::exportBiaoDing(const SENSOR_DATA_T *data,QList<BIAODING_DATA_T> &list,QString saveName)
{
    QString fileName = BIAODING_MOBAN;
    qDebug() << "start load  " << QCoreApplication::applicationDirPath()+"/template/"+fileName;
    QXlsx::Document xlsx(QCoreApplication::applicationDirPath()+"/template/"+fileName);

    if(xlsx.load()){
        changeBiaoDingSheet(&xlsx,data,list);
        xlsx.saveAs(QCoreApplication::applicationDirPath()+"/template/"+saveName);

    }else{
        qDebug()<< "load fail.";
        return false;
    }
    return true;
}

bool XLSL::exportBiaoDing2(const SENSOR_DATA_T *data, QString saveName)
{
    QString fileName = BIAODING_MOBAN;
    qDebug() << "start load  " << QCoreApplication::applicationDirPath()+"/template/"+fileName;
    QXlsx::Document xlsx(QCoreApplication::applicationDirPath()+"/template/"+fileName);

    if(xlsx.load()){
        changeBiaoDingSheet2(&xlsx,data);

        if(saveName.length()==0)
            return xlsx.saveAs(QCoreApplication::applicationDirPath()+"/test-biaoding.xls");
        else
           return  xlsx.saveAs(saveName);
    }else{
        qDebug()<< "load fail.";
        return false;
    }
    return true;
}

QString readText(Document*xlsx,int row,int col){
    QString str ="";
    Cell* cell = xlsx->cellAt(row, col); // get cell pointer.
    if ( cell != NULL )
    {
       str = cell->readValue().toString();
       qDebug() << "read << "<< row << "col: "<<col << "value:"<< str;
    }

    return str;

}

bool XLSL::loadBiaoDing(SENSOR_DATA_T* &data, QString fileName)
{
    QXlsx::Document xlsx(fileName);
    if(xlsx.load()){
        for(int i=0;i<MAX_RECORD_COUNT;i++){
            QString v = readText(&xlsx,7+i,1);
            if(v.length()>0){
                data->BiaoDingList[i].BIAODINGDIAN = v.length()==0?0:v.toFloat();
                 v = readText(&xlsx,7+i,2);
                data->BiaoDingList[i].BIAODINGZHI1 = v.length()==0?0:v.toFloat();
                 qDebug()<<" ddd d " << data->BiaoDingList[i].BIAODINGZHI1 << " " <<data;
                 v = readText(&xlsx,7+i,3);
                data->BiaoDingList[i].BIAODINGZHI2 = v.length()==0?0:v.toFloat();
                 v = readText(&xlsx,7+i,4);
                data->BiaoDingList[i].BIAODINGZHI3 = v.length()==0?0:v.toFloat();
                v = readText(&xlsx,7+i,5);
                data->BiaoDingList[i].BIAODINGZHI_AVERAGE = v.length()==0?0:v.toFloat();
            }else{
                data->Operator.DianShu = i;
                qDebug()<<" dianshu is: " << i;
                break;
            }
        }
        return data->Operator.DianShu>0;
    }

    return false;
}


QString XLSL::changeValue(Document *xlsx, int row, int col, QString value)
{
    QString changed = value;
    Cell* cell = xlsx->cellAt(row, col); // get cell pointer.
    if ( cell != NULL )
    {
        QString var = cell->readValue().toString();
        if(var.contains("%1")||var.contains("%2")){
            changed = QString(var).arg(value);

        }
        qDebug() << " row:" << row << " col:"<< col << "-" << var << " to :" << changed; // Display value. It is 'Hello Qt!'.

        xlsx->write(row,col,changed); // write "Hello Qt!" to cell(A,1). it's shared string.
    }
    else
    {
        qDebug() << "[debug][error] is not set. row:" << row  << "col:" << col;
    }

    return changed;
}

QString XLSL::changeValue(Document *xlsx, int row, int col, float value)
{
    QString changed = QString("%1").arg(value);
    return changeValue(xlsx,row,col,changed);
}
QString XLSL::changeValue(Document *xlsx, int row, int col, int value)
{
    QString changed = QString("%1").arg(value);
    return changeValue(xlsx,row,col,changed);
}

QString XLSL::changeValue(Document *xlsx, int row, int col, float value,int dotNum)
{
    QString changed = QString("%1").arg(value,0, 'r',dotNum);
    return changeValue(xlsx,row,col,changed);
}

void XLSL::changeBiaoDingSheet(Document *xlsx,const  SENSOR_DATA_T *data,QList<BIAODING_DATA_T> &list)
{
    changeValue(xlsx,2,2,data->XingHao);
    changeValue(xlsx,2,5,data->BianHao);

    changeValue(xlsx,3,2,data->CeLiangFanWei,data->XiaoShu);
    changeValue(xlsx,3,5,data->BiaoDingRiQi);

    changeValue(xlsx,4,2,data->DanWei);
    changeValue(xlsx,4,5,data->XiaoShu);


    for(int i=0;i<10;i++){
        if(i<list.size()){
            changeValue(xlsx,7+i,1,list.at(i).BIAODINGDIAN);
            changeValue(xlsx,7+i,2,list.at(i).BIAODINGZHI1);
            changeValue(xlsx,7+i,3,list.at(i).BIAODINGZHI2);
            changeValue(xlsx,7+i,4,list.at(i).BIAODINGZHI3);
            changeValue(xlsx,7+i,5,list.at(i).BIAODINGZHI_AVERAGE);
        }

    }


}

void XLSL::changeBiaoDingSheet2(Document *xlsx,const SENSOR_DATA_T *data)
{

    changeValue(xlsx,2,2,data->XingHao);
    changeValue(xlsx,2,5,data->BianHao);

    changeValue(xlsx,3,2,data->CeLiangFanWei,data->XiaoShu);
    changeValue(xlsx,3,5,data->BiaoDingRiQi);

    changeValue(xlsx,4,2,data->DanWei);
    changeValue(xlsx,4,5,data->XiaoShu);


    for(int i=0;i<MAX_RECORD_COUNT;i++){
        if(i<data->Operator.DianShu){
            changeValue(xlsx,7+i,1,data->BiaoDingList[i].BIAODINGDIAN);
            changeValue(xlsx,7+i,2,data->BiaoDingList[i].BIAODINGZHI1);
            changeValue(xlsx,7+i,3,data->BiaoDingList[i].BIAODINGZHI2);
            changeValue(xlsx,7+i,4,data->BiaoDingList[i].BIAODINGZHI3);
            changeValue(xlsx,7+i,5,data->BiaoDingList[i].BIAODINGZHI_AVERAGE);
        }else{
            xlsx->write(7+i,1,"");
            xlsx->write(7+i,2,"");
            xlsx->write(7+i,3,"");
            xlsx->write(7+i,4,"");
            xlsx->write(7+i,5,"");
        }

    }




}

void XLSL::changeCeLiangSheet(Document *xlsx,const SENSOR_DATA_T *data,QList<JIANDING_DATA_T> &list, OPERATOR_T &op)
{

}


void XLSL::changeCeLiangSheet2(Document *xlsx,const  SENSOR_DATA_T *data)
{
   #ifdef OLD_OPERATOR
    changeValue(xlsx,3,3,data->Operator.WeiTuoDanJuHao);
//    changeValue(xlsx,3,9,data->Operator.YuanShiJilu);
    changeValue(xlsx,3,12,data->ZhengShuHao);

    changeValue(xlsx,4,3,data->Operator.DanJuHao);
    changeValue(xlsx,4,10,data->Operator.YiQiMingCheng);

    changeValue(xlsx,5,3,data->XingHao);
    changeValue(xlsx,5,10,data->BianHao);

    changeValue(xlsx,6,3,data->SCChangJia);
    changeValue(xlsx,6,10,data->WenDu);
    changeValue(xlsx,6,12,data->ShiDu);

    changeValue(xlsx,7,3,data->JianDingYiJu);
    changeValue(xlsx,7,10,data->JianDingDiDian);


    changeValue(xlsx,9,10,data->XingHao+"/"+data->BianHao);

    changeValue(xlsx,10,3,data->ZhengShuHao);
    changeValue(xlsx,10,7,data->ZhengShuYouXiaoRiQi);
    changeValue(xlsx,10,11,data->JiShuZhiBiao);

    changeValue(xlsx,12,2,data->DanWei);
    changeValue(xlsx,12,3,data->DanWei);
    changeValue(xlsx,12,7,data->DanWei);

    changeValue(xlsx,24,12,data->Operator.JiaoZhunriQi);

    changeValue(xlsx,25,3,data->Operator.JiaoZhunYuan);
    changeValue(xlsx,25,8,data->Operator.JianYanYuan);
  //  changeValue(xlsx,25,12,data->Operator.YouXiaoRiQi);


    for(int i=0;i<MAX_RECORD_COUNT;i++){
        if(i<data->Operator.DianShu){
            changeValue(xlsx,14+i,2,data->JianDingList[i].SHIYANLI);
            changeValue(xlsx,14+i,3,data->JianDingList[i].JINCHENG1);
            changeValue(xlsx,14+i,4,data->JianDingList[i].JINCHENG2);
            changeValue(xlsx,14+i,5,data->JianDingList[i].JINCHENG3);
            changeValue(xlsx,14+i,6,data->JianDingList[i].JINCHENG_AVERAGE);
            changeValue(xlsx,14+i,7,data->JianDingList[i].HUICHENG);
            changeValue(xlsx,14+i,8,data->JianDingList[i].XIANDUIWUCHAI);
            changeValue(xlsx,14+i,10,data->JianDingList[i].CHONGFUXING);
        }else{
            xlsx->write(14+i,2,"");
            xlsx->write(14+i,3,"");
            xlsx->write(14+i,4,"");
            xlsx->write(14+i,5,"");
            xlsx->write(14+i,6,"");
            xlsx->write(14+i,7,"");
            xlsx->write(14+i,8,"");
            xlsx->write(14+i,10,"");
        }
    }
#else


    changeValue(xlsx,2,2,data->Operator.WeiTuoDanJuHao);
    changeValue(xlsx,2,3,data->Operator.JiLuHao);
//    changeValue(xlsx,2,7,data->ZhengShuHao);

    changeValue(xlsx,3,2,data->Operator.ZhengShuDanWei);
    changeValue(xlsx,4,2,data->XingHao);
    changeValue(xlsx,5,2,data->SCChangJia);

    changeValue(xlsx,6,2,data->ChuChangBiaoHao);
    changeValue(xlsx,6,5,data->Operator.GuangLiHao);

    changeValue(xlsx,7,2,data->Operator.JiaoZunHuangJing);
    changeValue(xlsx,8,3,data->Operator.NiuJuFangDaBeiShu);

    changeValue(xlsx,9,1,data->Operator.DanWei);
    changeValue(xlsx,9,2,data->Operator.DanWei);
    changeValue(xlsx,9,3,data->Operator.DanWei);
    changeValue(xlsx,9,6,data->Operator.DanWei);

    changeValue(xlsx,23,3,data->Operator.BiaoZhunQiBianHao);
    changeValue(xlsx,23,5,data->Operator.ZhengShuYouXiaoRiQi);
    changeValue(xlsx,23,7,data->Operator.JiShuZhiBiao);

    changeValue(xlsx,25,2,data->Operator.JiaoZhuDiDian);
    changeValue(xlsx,25,7,data->Operator.JiaoZhunriQi);


    for(int i=0;i<MAX_RECORD_COUNT;i++){
        if(i<data->Operator.DianShu){

            if(!data->JianDingList[i].valid) continue;
            changeValue(xlsx,11+i,1,data->JianDingList[i].SHIYANLI);
            changeValue(xlsx,11+i,2,data->JianDingList[i].LILUNZHI);
            changeValue(xlsx,11+i,3,data->JianDingList[i].JINCHENG1);
            changeValue(xlsx,11+i,4,data->JianDingList[i].JINCHENG2);
            changeValue(xlsx,11+i,5,data->JianDingList[i].JINCHENG3);
            changeValue(xlsx,11+i,6,data->JianDingList[i].JINCHENG_AVERAGE);
          //  changeValue(xlsx,11+i,7,data->JianDingList[i].HUICHENG);
            changeValue(xlsx,11+i,7,QString("%1").arg(data->JianDingList[i].XIANDUIWUCHAI,0,'r',data->Operator.BaoLiuXiaoShu));
            changeValue(xlsx,11+i,8,QString("%1").arg(data->JianDingList[i].CHONGFUXING,0,'r',data->Operator.BaoLiuXiaoShu));
        }else{
            xlsx->write(11+i,1,"");
            xlsx->write(11+i,2,"");
            xlsx->write(11+i,3,"");
            xlsx->write(11+i,4,"");
            xlsx->write(11+i,5,"");
            xlsx->write(11+i,6,"");
            xlsx->write(11+i,7,"");
            xlsx->write(11+i,8,"");
            xlsx->write(11+i,10,"");
        }
    }


#endif
}
