#ifndef XLSL_H
#define XLSL_H
#include "xlsxdocument.h"
#include "xlsxchartsheet.h"
#include "xlsxcellrange.h"
#include "xlsxchart.h"
#include "xlsxrichstring.h"
#include "xlsxworkbook.h"

#include "sensormodel.h"
#include "singleton.h"



using namespace QXlsx;

class XLSL
{
public:
    XLSL();
    DECLARE_SINGLETON_0BJCE(XLSL)

    bool exportCeLiang(const SENSOR_DATA_T *data,QList<JIANDING_DATA_T> &list, OPERATOR_T &op,  QString saveName);
    bool exportCeLiang2(const SENSOR_DATA_T *data,QString saveName="");
    bool exportBiaoDing(const SENSOR_DATA_T *data,QList<BIAODING_DATA_T> &list,QString saveName);
    bool exportBiaoDing2(const SENSOR_DATA_T *data,QString saveName="");

    bool loadBiaoDing(SENSOR_DATA_T* & data,QString fileName);

private:
    QString  changeValue(QXlsx::Document *xlsx,int row,int col,QString value);
    QString  changeValue(QXlsx::Document *xlsx,int row,int col,int value);
    QString  changeValue(QXlsx::Document *xlsx,int row,int col,float value);
    QString  changeValue(QXlsx::Document *xlsx,int row,int col,float value,int dotNum);

    void changeBiaoDingSheet(QXlsx::Document *xlsx,const SENSOR_DATA_T *data,QList<BIAODING_DATA_T> &list);
    void changeBiaoDingSheet2(QXlsx::Document *xlsx,const SENSOR_DATA_T *data);

    void changeCeLiangSheet(QXlsx::Document *xlsx,const SENSOR_DATA_T *data,QList<JIANDING_DATA_T> &list, OPERATOR_T &op);
    void changeCeLiangSheet2(QXlsx::Document *xlsx,const SENSOR_DATA_T *data);
};

#endif // XLSL_H
