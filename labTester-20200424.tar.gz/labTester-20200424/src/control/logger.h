#ifndef LOGGER_H
#define LOGGER_H
#include <QFile>
#include <QMessageLogger>
#include <qlogging.h>
#include <QFile>
#include <QTextStream>
#include <QDateTime>
#include <QTextCodec>

#include <singleton.h>
class Logger
{
public:
    Logger();
    DECLARE_SINGLETON_0BJCE(Logger)
    void MessageOutput(QtMsgType type, const QMessageLogContext &context, const QString &msg);
    bool switchTurn(){
        mOpenDebug = !mOpenDebug;
        return mOpenDebug;
    }
   void history();
private:
   void init();


   QFile *mFileLog;
   QTextCodec *codec;
   QMessageLogger *mLog;
   bool mOpenDebug;

};

#endif // LOGGER_H
