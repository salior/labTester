/****************************************************************************
**
** Copyright (C) 2012 Denis Shienkov <denis.shienkov@gmail.com>
** Contact: https://www.qt.io/licensing/
**
** This file is part of the QtSerialPort module of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#ifndef MASTERTHREAD_H
#define MASTERTHREAD_H

#include <QThread>
#include <QMutex>
#include <QWaitCondition>
#include <singleton.h>

#include <QtSerialPort/QSerialPort>
#include "sensormodel.h"
/*
获取所有传感器基本信息
2:

删除传感器
3:id值

选择传感器
4:id值(新传感器为0)
4:0

获取某个传感器的系数
5:id值

保存系数
8:100000+0.01+200000+0.01+300000+0.01+400000+0.01+500000+0.01+600000+0.01+700000+0.01+800000+0.01

保存基本信息
9:1+10kn+007+9.8+1000+N+2+2018年10月24日+广州数控+0.5级+007+2118年10月24日

校准测量
12:

检定测量
7:

清零：
18:

更改灵敏度：
19:0.000001(限制长度10个字符)

更改设备蓝牙名称：
20:lanyamingcheng(限制17个字符长度)

*/



class MasterThread : public QObject
{
    Q_OBJECT
public:
    void cmdGetInfomation(){
        writeCommand(QString("%1:").arg(CMD_INFO));
    }
    void cmdStop(){
        writeCommand(QString("%1:").arg(COM_STOP));
    }

    void cmdDeleteSensor(int id){
        writeCommand(QString("%1:%2").arg(CMD_DELETE).arg(id));
    }

    void cmdSelectSensorById(int id){
        if(writeCommand (QString("%1:%2").arg(CMD_SELECT).arg(id))){
            mCurrentSensorId = id;
        }
    }
    void cmdNewSensor(){
        if(writeCommand (QString("%1:%2").arg(CMD_SELECT).arg(0))){
        }
    }

    void cmdReadXiShu(int id){
        writeCommand (QString("%1:%2").arg(CMD_READ_XI_SHU).arg(id));
    }

    void cmdSaveXiShu(int id,QString str){
        writeCommand (QString("%1:%2").arg(CMD_SAVE_XI_SHU).arg(str));
//        writeCommand (QString("%1:%2+%3").arg(CMD_SAVE_XI_SHU).arg(id).arg(str));
    }

    void cmdSaveInfomation(int id,QString str){
        //QString utf8 = GBK2UTF8(str);
        QTextCodec *codec = QTextCodec::codecForName("utf-8");
//        QString content = codec->toUnicode(str.toLocal8Bit());
        QString content = str;

        if(id ==0){ // delete one sensor
            writeCommand (QString("%1:%2").arg(CMD_SAVE_INFOMATION).arg(id));
        }
        else
        writeCommand (QString("%1:%2+%3").arg(CMD_SAVE_INFOMATION).arg(id).arg(content));
    }

    void cmdBiaoDing(){
        writeCommand (QString("%1:").arg(CMD_BIAODING));
    }

    void cmdJianDing(){
        writeCommand (QString("%1:").arg(CMD_JIAN_DING));
    }

    void cmdQingLing(int id=100){
        writeCommand(QString("%1:%2").arg(CMD_QINGLING).arg(id));
    }

    void cmdGengGaiLingMinDu(float lingMinDu){
        writeCommand(QString("%1:%2").arg(CMD_GAI_LING_MING_DU).arg(lingMinDu, 0, 'r',5));
    }
    void cmdGengGaiLanYa(QString str){
        writeCommand(QString("%1:%2").arg(20).arg(str));
    }

public:
    DECLARE_SINGLETON_0BJCE(MasterThread)
    explicit MasterThread(QObject *parent = nullptr);
    ~MasterThread();

    bool init();
    //    void run() Q_DECL_OVERRIDE;


    QSerialPort *getSerial(){
        return this->serial;
    }



    bool openSerial(QString portName=""){
        if (serial->isOpen()){
            serial->close();
        }

        QString a = portName;

        if(portName.length()==0){
            a=  loadIniConfig();
        }

        serial->setPortName(a);
        serial->setBaudRate(19200);

        bool f = serial->open(QIODevice::ReadWrite);

        if(f){
            saveConfig(a);
        }
        return f;
    }

    bool closeSerial(){
        if (serial->isOpen()){
            serial->close();
            return true;
        }
        return false;
    }
private:
    bool writeCommand(QString req);
    void response(const QString &s);

    QString loadIniConfig();
    void saveConfig(QString portName);

signals:
    void updatedEvent(int id);
    void updatedADEvent(int id);
    void saveInfoEvent(bool flag);
    void openComportEvent(bool f);
    void saveXiShuEvent(bool flag);
    void addSensorEvent(int id);
    void deleteSensorEvent(int id);
//    void readXiShuEvent(int id,QString str);
    void readXiShuEvent(QString str);
    void qingLingEvent(bool flag);

    void error(const QString &s);
    void timeout(const QString &s);

private:
    QSerialPort *serial;
    QString portName;
    int waitTimeout;
    QMutex mutex;
    QWaitCondition cond;
    bool quit;
    QString mCurrentSensorId;
    QString responseText;

};

#endif // MASTERTHREAD_H
