#ifndef TESTCONTROL_H
#define TESTCONTROL_H

#include "singleton.h"
class TestControl
{
public:
    TestControl();
    DECLARE_SINGLETON_0BJCE(TestControl)

public:
    void start();
    void start2();
    void output();
private:

};

#endif // TESTCONTROL_H
