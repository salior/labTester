/****************************************************************************
**
** Copyright (C) 2012 Denis Shienkov <denis.shienkov@gmail.com>
** Contact: https://www.qt.io/licensing/
**
** This file is part of the QtSerialPort module of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include "masterthread.h"

#include <QtSerialPort/QSerialPort>

#include <QTime>
#include <QDebug>
#include <QSettings>
#include <QCoreApplication>
#include <QByteArray>
#include "testermodel.h"
#include "testcontrol.h"



QT_USE_NAMESPACE

MasterThread::MasterThread(QObject *parent)    
{
    serial = new QSerialPort(parent);
}

MasterThread::~MasterThread()
{
    if(serial->isOpen())
        serial->close();
    delete serial;
}
bool MasterThread::init()
{
#ifdef DEVELOPMENT

#endif

    if(serial->isOpen()){

        connect(serial,&QSerialPort::readyRead,[=](){
            QByteArray responseData = serial->readAll();
            this->responseText += responseData;
            qDebug() << "recv raw data:  " << responseData;
            if(this->responseText.contains('\n')){
                int pos = this->responseText.indexOf('\n');
                while(pos>0){
                    QString text = this->responseText.left(pos+1);
                    this->response(text);
                    this->responseText = this->responseText.remove(0,pos+1);
                    pos = this->responseText.indexOf('\n');
                }

//                this->responseText  = this->responseText.section ('\n',this->responseText.indexOf('\n'));
//                if(text.endsWith('\n'))

            }
            else this->responseText  = this->responseText.section ('\n',this->responseText.indexOf('\n'));
            //            qDebug() << "section after . " << responseText;

        });
        qInfo()<< "open serial port Successed.";
        cmdStop();


        cmdGetInfomation();
//        for(int i=0;i<MAX_SENSOR_COUNT;i++){
//            cmdSelectSensorById(i+1);
//            cmdGetInfomation();
//        }

        return true;
    }
    else{
        qCritical()<< "open serial port fail.";
    }

    return false;

}


bool MasterThread::writeCommand(QString request)
{

    if(!serial->isOpen()) return false;
    request.append('\n');
    QByteArray requestData = request.toUtf8();
//    QByteArray requestData = request.toLatin1();
    //    qDebug() << " write data:" << requestData.toHex();
    qInfo() << "write string:" << request;
    serial->write(requestData);
    if (!serial->waitForBytesWritten(0)) {
        return false;
    }

    return true;


}

void MasterThread::response(const QString &s)
{

    qDebug() << "recv " << s;
    QStringList cmdList = s.split(QRegExp("[\n]"));
    foreach (QString str,cmdList){
        QStringList sections = str.split(QRegExp("[:]"));
        //         qDebug() << "dsdd"<< sections;
        if (sections.size() >1 )
        {
            int cmd = sections[0].toInt();
            switch (cmd) {

            //传感器id值+传感器型号+传感器编号+传感器检定时的当地重力系数+传感器量程+单位+传感器小数位+本次标定日期+生产厂家+技术指标+证书号+证书有效日期\n

            case CMD_INFO:{
                qInfo() << "recv CMD_INFO:" <<(sections[1]);
                QString text =(sections[1]);
                QStringList frs =  text.split(QRegExp("[+]"));
                if(frs.size()>11){
                    SENSOR_DATA_T * sensor = new SENSOR_DATA_T;
                    sensor->reset();
                    int i=0;
                    sensor->id = frs[i++].toInt();
                    sensor->XingHao = frs[i++];
                    sensor->BianHao = frs[i++];
                    sensor->ZhongLiJiaShuDu = frs[i++].toFloat();
                    sensor->CeLiangFanWei = frs[i++].toInt();
                    sensor->DanWei = frs[i++];
                    sensor->XiaoShu = frs[i++].toShort();
                    sensor->BiaoDingRiQi = frs[i++];
                    sensor->SCChangJia =(frs[i++]);

//                    sensor->SCChangJia = GBK2UTF8(frs[i++]);
                    sensor->JiShuZhiBiao = frs[i++];
                    sensor->ZhengShuHao = frs[i++];
                    sensor->ZhengShuYouXiaoRiQi = frs[i++];
                    sensor->WenDu = 0;
                    sensor->ShiDu = 0;
                    sensor->show = true;
                    sensor->enabled = true;
                    //                  qDebug() << "current sensor ";

                    sensor->dumpmy();
                    TesterModel::getInstance()->addSensor(sensor);
                    int id = sensor->id;
                    delete sensor;
                    emit addSensorEvent(id);

                }else{
                    qCritical()<<"error information string : " << text;
                }
            }

                break;

            case CMD_DELETE:{
                 qInfo() << "recv CMD_DELETE:" <<(sections[1]);

//                 emit deleteSensorEvent();
            }break;
                //12:拉压力值\n 注意: 拉压力值为浮点数的字符串。
            case CMD_JIAN_DING:{
                UPDATE_DATA_T data;
                data.id = sections[1].toInt();
                data.LiZhi = sections[2].toFloat();
                data.time = QDateTime::currentDateTime().toMSecsSinceEpoch();
                qDebug()<< "jianding data:" <<QString("id: %1 - lizhi:%2 ").arg(data.id).arg(data.LiZhi);
                TesterModel::getInstance()->onSensorDataUpdated(&data);
                emit updatedEvent(data.id);
            }

                break;
                //2.3 测力仪发送的标定值数据格式 数据格式：7:AD值\n
            case CMD_BIAODING:{
               // static int count =0;
                UPDATE_AD_DATA_T data;
                data.id = sections[1].toInt();
//                data.AD = QString("0.00002").toFloat();
                data.AD = sections[2].toFloat();
                qDebug()<< "biaoding data " <<QString("id: %1 - ad :%2 ").arg(data.id).arg(data.AD);
                TesterModel::getInstance()->onSensorDataADUpdated(&data);
                emit updatedADEvent(data.id);
                }

                break;

            case CMD_SAVE_INFOMATION:
                if(sections[1].contains("true")){
                    qInfo()<< "save info successed";
                    emit saveInfoEvent(true);
                }else{
                    qWarning()<< "save info fail.";
                }
                break;


            case CMD_SELECT:
                qInfo()<< "recv CMD_SELECT sucessed :"  << sections[1];
                if(sections[1].contains("true")){

                    // emit saveXiShuEvent(true);
                }
            case CMD_READ_XI_SHU:
                qInfo()<< "recv CMD_READ_XI_SHU STR:" << sections[1];

                emit readXiShuEvent(sections[1]);

                break;

            case CMD_SAVE_XI_SHU:
                if(sections[1].contains("true")){
                    qInfo()<< "save xi shu sucessed :" << sections[1] ;
                    emit saveXiShuEvent(true);
                }else{
                    // qDebug()<< "save xi shu fail.:" << sections[1] ;;
                    //emit saveXiShuEvent(false);
                }
                break;
            case CMD_QINGLING:
                qInfo () << "recv CMD_QINGLING successed.";
                emit qingLingEvent(true);
                break;
            default:
                qWarning()<< s <<  " -- unknown cmd: " << cmd;
                break;
            }
        }
    }

}

QString MasterThread::loadIniConfig()
{

    QSettings settings(QCoreApplication::applicationDirPath()+"config.ini",
                       QSettings::IniFormat);

    settings.beginGroup("port");
    QString name  = settings.value("name","COM3").toString();
    int baudrate = settings.value("baudrate",19200).toInt();
    qInfo()<< "name:" <<name <<"baudrate :"<<baudrate;

    this->serial->setBaudRate(baudrate);
    this->serial->setPortName(name);

    return name;

}

void MasterThread::saveConfig(QString portName)
{
    QSettings settings(QCoreApplication::applicationDirPath()+"config.ini",
                       QSettings::IniFormat);

    settings.beginGroup("port");

    settings.setValue("name",portName);
    settings.setValue("baudrate",19200);


    settings.sync();
}






