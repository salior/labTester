#include "logger.h"
#include <QString>
#include <QCoreApplication>
#include <QDir>
#include <QDebug>
char *msgHead[] = {
    "Debug ",
    "Warning ",
    "Critical",
    "Fatal ",
    "Info "
};


void myMessageOutput(QtMsgType type, const QMessageLogContext &context, const QString &msg)
{
    Logger::getInstance()->MessageOutput(type,context,msg);
}


Logger::Logger()
{
    mFileLog =NULL;
    mOpenDebug =false;
    init();
}

void Logger::init()
{
#ifndef DEVELOPMENT

    QString path= QCoreApplication::applicationDirPath()+"\\log\\";
    if(!QDir(path).exists())
        QDir().mkdir(path);

    QString filePath = path+QDateTime::currentDateTime().toString("yyyy-MM-dd")+".log";
    mFileLog = new QFile(filePath);
    if (!mFileLog->open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Append)){
        return;
    }
#endif
    //初始化自定义日志处理函数myMessageOutput
    qInstallMessageHandler(myMessageOutput);
    //gMLog 这个类不要也可以，执行的时候只能看一下效果。
    mLog = new QMessageLogger(__FILE__, __LINE__, Q_FUNC_INFO);
}

void Logger::MessageOutput(QtMsgType type, const QMessageLogContext &context, const QString &msg)
{
    QByteArray localMsg = msg.toLocal8Bit();
    QString current_date_time = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss:zzz");

    if(mFileLog){
        if(!mOpenDebug && type == QtDebugMsg) return;
        QTextStream tWrite(mFileLog);
        tWrite.setCodec(QTextCodec::codecForName("utf-8"));
        QString msgText="%1 | %6 | %2:%3, %4 | %5\n";
        msgText = msgText.arg(msgHead[type]).arg(context.file).arg(context.line).arg(context.function).arg(localMsg.constData()).arg(current_date_time);
        tWrite << msgText;


    }else{
        fprintf(stderr, "%s | %s | %s:%u, %s | %s\n", msgHead[type], current_date_time.toLocal8Bit().constData(), context.file, context.line, context.function, localMsg.constData());
    }
}


void Logger::history()
{
    QString d = __DATE__;
    QString t = __TIME__;
    qInfo()<< " 编译日期" << d << " " << t;
    qInfo() << "修改日期[20200417]";
    qInfo()<< "１. 修改了峰值的问题" ;
    qInfo()<< "２. 修改了导出ＥＸＣｅｌ缺少问题" ;
    qInfo()<< "３. 修改了不需要发命令８去保存传感器信息" ;
    qInfo() << "修改日期[20200421]";
    qInfo()<< "１. 修改了保存传感器信息后不刷新信息的问题" ;
    qInfo()<< "２. 增加了6路传感器版本" ;
    qInfo()<< "３. 修改了不能纪录到表里的问题" ;
    qInfo() << "修改日期[20200421-2]";
    qInfo()<< "１. 修改了保存传感器信息中文乱码问题" ;
    qInfo() << "修改日期[20200422]";
    qInfo()<< "1. 检定表输出默认值问题" ;
    qInfo()<< "2. 屏蔽当sensor单位是N.m的单位切换" ;
    qInfo()<< "3. 根据单位输出Excel表中的单位" ;
    qInfo() << "修改日期[20200422-2]";
    qInfo()<< "1. 修改最小分辨率适应768 高" ;
    qInfo() << "修改日期[20200423]";
    qInfo()<< "1. 更改力值显示问题" ;
    qInfo()<< "2. 调整了排版问题" ;

}

